-- Canonical schema for the optional Postgres analytics store (DATABASE_URL).
-- No migration framework is used in this repo (psycopg only, no ORM) — this
-- file is the single source of truth and is safe to re-run (idempotent).
--
-- Apply with:
--   psql "$DATABASE_URL" -f db/schema.sql

CREATE TABLE IF NOT EXISTS sets (
    set_id   SERIAL PRIMARY KEY,
    set_name TEXT NOT NULL,
    set_type TEXT NOT NULL   -- 'multiple' | 'topic'
);

CREATE TABLE IF NOT EXISTS test_sets (
    question_id SERIAL PRIMARY KEY,
    set_id      INTEGER NOT NULL REFERENCES sets(set_id) ON DELETE CASCADE,
    question    TEXT NOT NULL,
    topic       TEXT,               -- required (app-level) when the parent set's type is 'topic'
    criteria    TEXT NOT NULL,
    location    TEXT NOT NULL       -- 'eu' | 'us', per-question default
);
CREATE INDEX IF NOT EXISTS idx_test_sets_set_id ON test_sets(set_id);

CREATE TABLE IF NOT EXISTS analysis_runs (
    id                  SERIAL PRIMARY KEY,
    set_id              INTEGER REFERENCES sets(set_id),
    analysis_type       TEXT,       -- "multiple" or "topic"
    replicas            INTEGER,
    threads             INTEGER,
    total_count         INTEGER,
    avg_score           NUMERIC,
    avg_time_ms         NUMERIC,
    invalid_count       INTEGER,
    score_distribution  JSONB,
    intent_stats        JSONB,
    run_date            TIMESTAMP DEFAULT now(),
    created_at          TIMESTAMP DEFAULT now(),
    chat_version_basis  TEXT,       -- from GET /health "version"
    feature_name        TEXT        -- user-editable, pre-filled from GET /health "env"
);

CREATE TABLE IF NOT EXISTS analysis_results (
    id                      SERIAL PRIMARY KEY,
    run_id                  INTEGER REFERENCES analysis_runs(id),
    question_id             INTEGER REFERENCES test_sets(question_id),
    set_id                  INTEGER REFERENCES sets(set_id),
    question                TEXT,
    topic                   TEXT,
    location                TEXT,
    replica                 INTEGER,
    score                   NUMERIC,
    reason                  TEXT,
    context_precision       NUMERIC,
    context_recall          NUMERIC,
    context_entities_recall NUMERIC,
    noise_sensitivity       NUMERIC,
    response_relavancy      NUMERIC,
    faithfulness            NUMERIC,
    response_time_ms        NUMERIC,
    answer                  TEXT,
    intents                 TEXT[]
);
CREATE INDEX IF NOT EXISTS idx_analysis_results_run_id ON analysis_results(run_id);
CREATE INDEX IF NOT EXISTS idx_analysis_runs_set_id ON analysis_runs(set_id);

-- Self-heal: RunResult.intents is a Python list[str], but this column was
-- originally created as scalar TEXT, which either fails on insert or corrupts
-- reads (intents gets read back as a string and iterated character-by-character
-- upstream). Upgrade it to TEXT[] on any pre-existing database.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'analysis_results' AND column_name = 'intents' AND data_type = 'text'
    ) THEN
        ALTER TABLE analysis_results ALTER COLUMN intents TYPE TEXT[] USING
            CASE WHEN intents IS NULL OR intents = '' THEN ARRAY[]::TEXT[] ELSE string_to_array(intents, ',') END;
    END IF;
END $$;

-- Default sets shown in the UI (set_id=1 for Multiple Analysis, set_id=2 for
-- Topic Analysis — one set_type per set means a single id can't serve both).
INSERT INTO sets (set_id, set_name, set_type) VALUES
  (1, 'Default', 'multiple'),
  (2, 'Default', 'topic')
ON CONFLICT (set_id) DO NOTHING;
SELECT setval('sets_set_id_seq', GREATEST((SELECT MAX(set_id) FROM sets), 2));
