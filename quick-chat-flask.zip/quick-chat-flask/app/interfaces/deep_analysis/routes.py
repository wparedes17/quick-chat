from datetime import date

from flask import Blueprint, current_app, render_template, request

from app.domain.evaluation.aggregator import (
    build_danger_list,
    build_intent_stats,
    build_metric_averages,
    build_summary,
    build_topic_stats,
    count_invalid,
    run_results_to_metric_rows,
)
from app.domain.evaluation.entities import RunResult
from app.domain.shared import EvaluationResult

deep_analysis_bp = Blueprint("deep_analysis", __name__)


def _repo():
    return current_app.config.get("ANALYSIS_REPO")


def _unavailable():
    return {"error": "Database not configured (DATABASE_URL is unset)"}, 503


@deep_analysis_bp.route("/deep-analysis")
def index():
    return render_template("deep_analysis/index.html")


@deep_analysis_bp.route("/deep-analysis/set-names")
def set_names():
    repo = _repo()
    if not repo:
        return _unavailable()
    return {"set_names": repo.list_set_names_with_runs()}


@deep_analysis_bp.route("/deep-analysis/runs")
def runs():
    repo = _repo()
    if not repo:
        return _unavailable()
    set_name = request.args.get("set_name", "")
    date_str = request.args.get("date", "")
    if not set_name or not date_str:
        return {"error": "set_name and date are required"}, 400
    try:
        run_date = date.fromisoformat(date_str)
    except ValueError:
        return {"error": "date must be YYYY-MM-DD"}, 400
    return {"runs": repo.list_runs_for_set_and_date(set_name, run_date)}


def _rows_to_run_results(rows: list[dict]) -> list[RunResult]:
    """Reconstructs RunResult objects from persisted DB rows so historical
    dashboards can reuse the same aggregator functions as live runs
    (build_summary, build_topic_stats, build_intent_stats, count_invalid)."""
    return [
        RunResult(
            result_id=str(i),
            question=row["question"],
            replica=row["replica"],
            evaluation=EvaluationResult(
                score=int(row["score"]) if row["score"] is not None else 0,
                reason=row["reason"] or "",
                context_precision=row["context_precision"],
                context_recall=row["context_recall"],
                context_entities_recall=row["context_entities_recall"],
                noise_sensitivity=row["noise_sensitivity"],
                response_relavancy=row["response_relavancy"],
                faithfulness=row["faithfulness"],
            ),
            response_time_ms=row["response_time_ms"] or 0.0,
            topic=row["topic"],
            answer=row["answer"] or "",
            intents=row["intents"] or [],
            location=row["location"],
        )
        for i, row in enumerate(rows)
    ]


@deep_analysis_bp.route("/deep-analysis/<int:run_id>")
def dashboard(run_id):
    repo = _repo()
    if not repo:
        return _unavailable()

    run = repo.get_run(run_id)
    if not run:
        return {"error": "run not found"}, 404

    result_rows = repo.get_run_results(run_id)
    results = _rows_to_run_results(result_rows)

    summary = build_summary(results)
    trend = repo.get_score_trend(run["set_id"], run["analysis_type"], run_id)
    topic_stats = build_topic_stats(results) if run["analysis_type"] == "topic" else []

    current_metric_rows = run_results_to_metric_rows(results)
    metric_averages = build_metric_averages(current_metric_rows)

    prev = repo.get_previous_run(run["set_id"], run["analysis_type"], exclude_run_id=run_id)
    danger = []
    previous_metric_averages = {}
    if prev:
        prev_results = repo.get_previous_run_results(
            run["set_id"], run["analysis_type"], exclude_run_id=run_id
        )
        danger = build_danger_list(current_metric_rows, prev_results)
        previous_metric_averages = build_metric_averages(prev_results)

    return {
        "run": run,
        "results": result_rows,
        "summary": {
            **summary,
            "invalid_count": count_invalid(results),
            "intent_stats": build_intent_stats(results),
        },
        "trend": trend,
        "topic_stats": topic_stats,
        "previous_run": prev,
        "danger": danger,
        "metric_averages": metric_averages,
        "previous_metric_averages": previous_metric_averages,
    }
