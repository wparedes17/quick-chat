import json

from flask import Blueprint, Response, current_app, render_template, request, stream_with_context

from app.domain.evaluation.aggregator import (
    build_danger_list,
    build_intent_stats,
    build_summary,
    build_topic_stats,
    count_invalid,
    run_results_to_metric_rows,
)
from app.domain.shared import Location

evaluation_bp = Blueprint("evaluation", __name__)

DEFAULT_SET_ID = {"multiple": 1, "topic": 2}


def _location(value: str) -> Location:
    return Location.US if value == "us" else Location.EU


def _load_rows(set_id: int, require_topic: bool):
    sets_repo = current_app.config.get("SETS_REPO")
    if not sets_repo:
        raise ValueError("Database not configured (DATABASE_URL is unset) — Sets require a database.")
    rows = sets_repo.get_test_set_rows(set_id)
    if not rows:
        raise ValueError("Selected set has no questions.")
    if require_topic and any(not row.topic for row in rows):
        raise ValueError("Every question in a topic set must have a topic.")
    return rows


@evaluation_bp.route("/single")
def single():
    return render_template("evaluation/single.html")


@evaluation_bp.route("/single/run", methods=["POST"])
def single_run():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    criteria = (data.get("criteria") or "").strip()
    location = _location(data.get("location", "eu"))
    base_url = (data.get("base_url") or "").strip() or None

    if not question or not criteria:
        return {"error": "question and criteria are required"}, 400

    service = current_app.config["EVALUATION_SERVICE"]
    try:
        result = service.run_single(question, criteria, location, base_url)
    except Exception as e:
        return {"error": str(e)}, 502

    return {
        "answer": result.answer,
        "score": result.evaluation.score,
        "reason": result.evaluation.reason,
    }


@evaluation_bp.route("/multiple")
def multiple():
    return render_template("evaluation/multiple.html")


@evaluation_bp.route("/multiple/run", methods=["POST"])
def multiple_run():
    set_id = int(request.form.get("set_id") or DEFAULT_SET_ID["multiple"])
    location = _location(request.form.get("location", "eu"))
    replicas = max(1, min(20, int(request.form.get("replicas", 1) or 1)))
    threads = max(1, min(10, int(request.form.get("threads", 1) or 1)))
    base_url = (request.form.get("base_url") or "").strip() or None

    try:
        rows = _load_rows(set_id, require_topic=False)
    except ValueError as e:
        return {"error": str(e)}, 400

    service = current_app.config["EVALUATION_SERVICE"]
    stop_flag = [False]
    feature_name_input = (request.form.get("feature_name") or "").strip()

    def generate():
        health = service.health(base_url)
        chat_version_basis = health.get("version")
        feature_name = feature_name_input or health.get("env")

        yield f"data: {json.dumps({'type': 'meta', 'data': {'total_count': len(rows) * replicas}})}\n\n"

        results = []
        for result in service.run_batch(rows, replicas, location, stop_flag, threads=threads, base_url=base_url):
            results.append(result)
            row_data = {
                "question": result.question,
                "replica": result.replica,
                "score": result.evaluation.score,
                "reason": result.evaluation.reason,
                "response_time_ms": result.response_time_ms,
                "intents": result.intents,
                "rewritten_question": result.rewritten_question,
                "is_invalid": result.is_invalid,
                "context_precision": result.evaluation.context_precision,
                "context_recall": result.evaluation.context_recall,
                "context_entities_recall": result.evaluation.context_entities_recall,
                "noise_sensitivity": result.evaluation.noise_sensitivity,
                "response_relavancy": result.evaluation.response_relavancy,
                "faithfulness": result.evaluation.faithfulness,
            }
            yield f"data: {json.dumps({'type': 'result', 'data': row_data})}\n\n"
        summary = build_summary(results)
        invalid_count = count_invalid(results)
        intent_stats = build_intent_stats(results)
        stats_payload = {
            **summary,
            "invalid_count": invalid_count,
            "invalid_rate": round(invalid_count / len(results), 4) if results else 0,
            "intent_stats": intent_stats,
        }
        yield f"data: {json.dumps({'type': 'stats', 'data': stats_payload})}\n\n"
        repo = current_app.config.get("ANALYSIS_REPO")
        if repo:
            try:
                run_id = repo.save_run(
                    set_id=set_id,
                    analysis_type="multiple",
                    replicas=replicas,
                    threads=threads,
                    results=results,
                    chat_version_basis=chat_version_basis,
                    feature_name=feature_name,
                )
                prev = repo.get_previous_run(set_id=set_id, analysis_type="multiple", exclude_run_id=run_id)
                if prev:
                    prev_results = repo.get_previous_run_results(
                        set_id=set_id, analysis_type="multiple", exclude_run_id=run_id
                    )
                    prev["danger"] = build_danger_list(run_results_to_metric_rows(results), prev_results)
                    yield f"data: {json.dumps({'type': 'comparison', 'data': prev})}\n\n"
            except Exception:
                pass
        yield "data: [DONE]\n\n"

    return Response(
        stream_with_context(generate()),
        content_type="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
    )


@evaluation_bp.route("/topic")
def topic():
    return render_template("evaluation/topic.html")


@evaluation_bp.route("/topic/run", methods=["POST"])
def topic_run():
    set_id = int(request.form.get("set_id") or DEFAULT_SET_ID["topic"])
    location = _location(request.form.get("location", "eu"))
    replicas = max(1, min(20, int(request.form.get("replicas", 1) or 1)))
    threads = max(1, min(10, int(request.form.get("threads", 1) or 1)))
    base_url = (request.form.get("base_url") or "").strip() or None

    try:
        rows = _load_rows(set_id, require_topic=True)
    except ValueError as e:
        return {"error": str(e)}, 400

    service = current_app.config["EVALUATION_SERVICE"]
    stop_flag = [False]
    feature_name_input = (request.form.get("feature_name") or "").strip()

    def generate():
        health = service.health(base_url)
        chat_version_basis = health.get("version")
        feature_name = feature_name_input or health.get("env")

        yield f"data: {json.dumps({'type': 'meta', 'data': {'total_count': len(rows) * replicas}})}\n\n"

        results = []
        for result in service.run_batch(rows, replicas, location, stop_flag, threads=threads, base_url=base_url):
            results.append(result)
            row_data = {
                "question": result.question,
                "topic": result.topic,
                "replica": result.replica,
                "score": result.evaluation.score,
                "reason": result.evaluation.reason,
                "response_time_ms": result.response_time_ms,
                "intents": result.intents,
                "rewritten_question": result.rewritten_question,
                "is_invalid": result.is_invalid,
                "context_precision": result.evaluation.context_precision,
                "context_recall": result.evaluation.context_recall,
                "context_entities_recall": result.evaluation.context_entities_recall,
                "noise_sensitivity": result.evaluation.noise_sensitivity,
                "response_relavancy": result.evaluation.response_relavancy,
                "faithfulness": result.evaluation.faithfulness,
            }
            yield f"data: {json.dumps({'type': 'result', 'data': row_data})}\n\n"
        summary = build_summary(results)
        invalid_count = count_invalid(results)
        intent_stats = build_intent_stats(results)
        topic_stats = build_topic_stats(results)
        stats_payload = {
            **summary,
            "invalid_count": invalid_count,
            "invalid_rate": round(invalid_count / len(results), 4) if results else 0,
            "intent_stats": intent_stats,
        }
        yield f"data: {json.dumps({'type': 'stats', 'data': stats_payload, 'topic_stats': topic_stats})}\n\n"
        repo = current_app.config.get("ANALYSIS_REPO")
        if repo:
            try:
                run_id = repo.save_run(
                    set_id=set_id,
                    analysis_type="topic",
                    replicas=replicas,
                    threads=threads,
                    results=results,
                    chat_version_basis=chat_version_basis,
                    feature_name=feature_name,
                )
                prev = repo.get_previous_run(set_id=set_id, analysis_type="topic", exclude_run_id=run_id)
                if prev:
                    prev_results = repo.get_previous_run_results(
                        set_id=set_id, analysis_type="topic", exclude_run_id=run_id
                    )
                    prev["danger"] = build_danger_list(run_results_to_metric_rows(results), prev_results)
                    yield f"data: {json.dumps({'type': 'comparison', 'data': prev})}\n\n"
            except Exception:
                pass
        yield "data: [DONE]\n\n"

    return Response(
        stream_with_context(generate()),
        content_type="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
    )
