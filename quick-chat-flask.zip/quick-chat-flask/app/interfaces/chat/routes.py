import json
import uuid

from flask import Blueprint, Response, current_app, render_template, request, stream_with_context

from app.domain.shared import Location

chat_bp = Blueprint("chat", __name__)


def _location(value: str) -> Location:
    return Location.US if value == "us" else Location.EU


@chat_bp.route("/")
def index():
    return render_template("chat/chat.html")


@chat_bp.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    location = _location(data.get("location", "eu"))
    session_id = data.get("session_id") or str(uuid.uuid4())
    user_id = data.get("user_id") or str(uuid.uuid4())
    base_url = (data.get("base_url") or "").strip() or None

    if not question:
        return {"error": "question is required"}, 400

    service = current_app.config["CHAT_SERVICE"]
    try:
        result = service.ask(question, location, session_id, user_id, base_url)
    except Exception as e:
        return {"error": str(e)}, 502

    return {"answer": result.answer, "intents": result.intents, "rewritten_question": result.rewritten_question}


@chat_bp.route("/ask/stream", methods=["POST"])
def ask_stream():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    location = _location(data.get("location", "eu"))
    session_id = data.get("session_id") or str(uuid.uuid4())
    user_id = data.get("user_id") or str(uuid.uuid4())
    base_url = (data.get("base_url") or "").strip() or None

    if not question:
        return {"error": "question is required"}, 400

    service = current_app.config["CHAT_SERVICE"]

    def generate():
        try:
            for event in service.ask_stream(question, location, session_id, user_id, base_url):
                if event.kind == "chunk":
                    yield f"data: {json.dumps({'chunk': event.payload})}\n\n"
                elif event.kind == "intents":
                    yield f"data: {json.dumps({'intents': event.payload})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        yield "data: [DONE]\n\n"

    return Response(
        stream_with_context(generate()),
        content_type="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
    )
