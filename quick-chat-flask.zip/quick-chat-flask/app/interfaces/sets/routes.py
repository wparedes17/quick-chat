from flask import Blueprint, current_app, jsonify, render_template, request

sets_bp = Blueprint("sets", __name__)


def _service():
    return current_app.config.get("SETS_SERVICE")


def _unavailable():
    return {"error": "Database not configured (DATABASE_URL is unset)"}, 503


@sets_bp.route("/sets")
def list_sets_page():
    return render_template("sets/list.html")


@sets_bp.route("/sets/api")
def list_sets_api():
    service = _service()
    if not service:
        return _unavailable()
    return jsonify(service.list_sets(request.args.get("type")))


@sets_bp.route("/sets", methods=["POST"])
def create_set():
    service = _service()
    if not service:
        return _unavailable()
    data = request.get_json(silent=True) or {}
    try:
        result = service.create_set(data.get("set_name", ""), data.get("set_type", ""))
    except ValueError as e:
        return {"error": str(e)}, 400
    return jsonify(result), 201


@sets_bp.route("/sets/<int:set_id>")
def set_detail_page(set_id):
    return render_template("sets/detail.html", set_id=set_id)


@sets_bp.route("/sets/<int:set_id>/api")
def set_detail_api(set_id):
    service = _service()
    if not service:
        return _unavailable()
    detail = service.get_set_detail(set_id)
    if not detail:
        return {"error": "set not found"}, 404
    return jsonify(detail)


@sets_bp.route("/sets/<int:set_id>", methods=["PUT"])
def update_set(set_id):
    service = _service()
    if not service:
        return _unavailable()
    data = request.get_json(silent=True) or {}
    try:
        service.update_set(set_id, data.get("set_name", ""), data.get("set_type", ""))
    except ValueError as e:
        return {"error": str(e)}, 400
    return {"ok": True}


@sets_bp.route("/sets/<int:set_id>", methods=["DELETE"])
def delete_set(set_id):
    service = _service()
    if not service:
        return _unavailable()
    service.delete_set(set_id)
    return {"ok": True}


@sets_bp.route("/sets/<int:set_id>/questions", methods=["POST"])
def create_question(set_id):
    service = _service()
    if not service:
        return _unavailable()
    data = request.get_json(silent=True) or {}
    try:
        result = service.create_question(
            set_id,
            data.get("question", ""),
            data.get("criteria", ""),
            data.get("location", "eu"),
            data.get("topic"),
        )
    except ValueError as e:
        return {"error": str(e)}, 400
    return jsonify(result), 201


@sets_bp.route("/sets/<int:set_id>/questions/<int:question_id>", methods=["PUT"])
def update_question(set_id, question_id):
    service = _service()
    if not service:
        return _unavailable()
    data = request.get_json(silent=True) or {}
    try:
        service.update_question(
            set_id,
            question_id,
            data.get("question", ""),
            data.get("criteria", ""),
            data.get("location", "eu"),
            data.get("topic"),
        )
    except ValueError as e:
        return {"error": str(e)}, 400
    return {"ok": True}


@sets_bp.route("/sets/<int:set_id>/questions/<int:question_id>", methods=["DELETE"])
def delete_question(set_id, question_id):
    service = _service()
    if not service:
        return _unavailable()
    service.delete_question(question_id)
    return {"ok": True}
