import json

from flask import Blueprint, Response, current_app, render_template, request, stream_with_context

from app.application.conversation_service import DEFAULT_CRITERIA
from app.domain.shared import Location

conversation_bp = Blueprint("conversation", __name__)


def _location(value: str) -> Location:
    return Location.US if value == "us" else Location.EU


@conversation_bp.route("/")
def index():
    return render_template("conversation/conversation.html", default_criteria=DEFAULT_CRITERIA)


@conversation_bp.route("/run", methods=["POST"])
def run():
    data = request.get_json(silent=True) or {}
    initial_question = (data.get("initial_question") or "").strip()
    num_turns = max(1, min(10, int(data.get("num_turns", 2) or 2)))
    location = _location(data.get("location", "eu"))

    if not initial_question:
        return {"error": "initial_question is required"}, 400

    service = current_app.config["CONVERSATION_SERVICE"]
    stop_flag = [False]

    def generate():
        for event in service.run_conversation(initial_question, num_turns, location, stop_flag):
            if event.kind == "turn_complete" and event.turn:
                turn_data = {
                    "turn_number": event.turn.turn_number,
                    "user_message": event.turn.user_message,
                    "system_response": event.turn.system_response,
                }
                yield f"data: {json.dumps({'type': 'turn', 'data': turn_data})}\n\n"
            elif event.kind == "status":
                yield f"data: {json.dumps({'type': 'status', 'message': event.message})}\n\n"
            elif event.kind == "error":
                yield f"data: {json.dumps({'type': 'error', 'message': event.message})}\n\n"
        yield "data: [DONE]\n\n"

    return Response(
        stream_with_context(generate()),
        content_type="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
    )


@conversation_bp.route("/evaluate", methods=["POST"])
def evaluate():
    data = request.get_json(silent=True) or {}
    turns = data.get("turns", [])
    criteria = (data.get("criteria") or "").strip()

    if not turns or not criteria:
        return {"error": "turns and criteria are required"}, 400

    service = current_app.config["CONVERSATION_SERVICE"]
    try:
        result = service.evaluate_conversation(turns, criteria)
    except Exception as e:
        return {"error": str(e)}, 502

    return {"score": result.score, "reason": result.reason}
