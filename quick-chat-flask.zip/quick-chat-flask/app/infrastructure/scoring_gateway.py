import json
from typing import Generator

import httpx

from app.domain.chat.entities import ChatAnswer, ChatMetadata, ChatModule, ChatRequest, StreamEvent
from app.domain.shared import EvaluationResult

_HEADERS = {"Content-Type": "application/json", "Accept-Language": "en"}


def _parse_intents(intent: object) -> list[str]:
    if not intent or not isinstance(intent, str):
        return []
    return [s.strip() for s in intent.split(",") if s.strip()]


def _parse_module(raw: object) -> ChatModule | None:
    if not isinstance(raw, dict):
        return None
    return ChatModule(
        module_name=raw.get("module_name", "") if isinstance(raw.get("module_name"), str) else "",
        module_type=raw.get("module_type", "") if isinstance(raw.get("module_type"), str) else "",
        text_response=raw.get("text_response", "") if isinstance(raw.get("text_response"), str) else "",
        raw_input_data=raw.get("raw_input_data", {}) if isinstance(raw.get("raw_input_data"), dict) else {},
        raw_output_data=raw.get("raw_output_data", {}) if isinstance(raw.get("raw_output_data"), dict) else {},
    )


def _parse_metadata(raw: object) -> ChatMetadata | None:
    if not isinstance(raw, dict):
        return None
    intents = raw.get("intents", [])
    modules_raw = raw.get("modules", [])
    return ChatMetadata(
        intents=[s for s in intents if isinstance(s, str)] if isinstance(intents, list) else [],
        modules=[m for m in (_parse_module(r) for r in modules_raw) if m is not None]
        if isinstance(modules_raw, list)
        else [],
    )


class ScoringGateway:
    def __init__(self, base_url: str) -> None:
        self._base_url = base_url.rstrip("/")

    def score(self, request: ChatRequest, base_url: str | None = None) -> ChatAnswer:
        url = (base_url or self._base_url).rstrip("/")
        payload = {
            "id": request.request_id,
            "question": request.question,
            "location": request.location.value,
            "sessionid": request.session_id,
            "userid": request.user_id,
        }
        with httpx.Client(timeout=60.0) as client:
            r = client.post(f"{url}/score", json=payload, headers=_HEADERS)
            r.raise_for_status()
            data = r.json()
        return ChatAnswer(
            answer=data.get("answer", "") if isinstance(data.get("answer"), str) else "",
            intents=_parse_intents(data.get("intent")),
            rewritten_question=data.get("rewritten_question", "") if isinstance(data.get("rewritten_question"), str) else "",
            metadata=_parse_metadata(data.get("metadata")),
        )

    def health(self, base_url: str | None = None) -> dict:
        url = (base_url or self._base_url).rstrip("/")
        try:
            with httpx.Client(timeout=10.0) as client:
                r = client.get(f"{url}/health", headers=_HEADERS)
                r.raise_for_status()
                data = r.json()
        except Exception:
            return {"version": None, "env": None}
        return {
            "version": data.get("version") if isinstance(data.get("version"), str) else None,
            "env": data.get("env") if isinstance(data.get("env"), str) else None,
        }

    def score_stream(
        self, request: ChatRequest, base_url: str | None = None
    ) -> Generator[StreamEvent, None, None]:
        url = (base_url or self._base_url).rstrip("/")
        payload = {
            "id": request.request_id,
            "question": request.question,
            "location": request.location.value,
            "sessionid": request.session_id,
            "userid": request.user_id,
        }
        headers = {**_HEADERS, "Accept": "application/x-ndjson"}
        with httpx.stream(
            "POST", f"{url}/score/stream",
            json=payload, headers=headers, timeout=120.0,
        ) as response:
            response.raise_for_status()
            buffer = ""
            for chunk in response.iter_text():
                buffer += chunk
                lines = buffer.split("\n")
                buffer = lines[-1]
                for line in lines[:-1]:
                    if line.strip():
                        yield from self._parse_line(line)

    def _parse_line(self, raw: str) -> Generator[StreamEvent, None, None]:
        text = raw.strip()
        if not text or text == "[DONE]":
            return
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            return

        if parsed.get("intent"):
            yield StreamEvent(kind="intents", payload=_parse_intents(parsed["intent"]))

        stage = parsed.get("stage")
        if stage == "[DONE]":
            return

        if stage == "answer" and parsed.get("state") == "streaming":
            message = parsed.get("message", "")
            if isinstance(message, str) and message:
                try:
                    inner = json.loads(message)
                    chunk = inner.get("chunk", "")
                    if isinstance(chunk, str) and chunk:
                        yield StreamEvent(kind="chunk", payload=chunk)
                except json.JSONDecodeError:
                    pass
