import json

import psycopg

from app.domain.evaluation.aggregator import build_intent_stats, build_summary, count_invalid
from app.domain.evaluation.entities import RunResult


class AnalysisRepository:
    def __init__(self, dsn: str) -> None:
        self._dsn = dsn

    def save_run(
        self,
        set_id: int,
        analysis_type: str,
        replicas: int,
        threads: int,
        results: list[RunResult],
        chat_version_basis: str | None = None,
        feature_name: str | None = None,
    ) -> int:
        summary = build_summary(results)
        intent_stats = build_intent_stats(results)
        invalid_count = count_invalid(results)
        avg_time_ms = (
            sum(r.response_time_ms for r in results) / len(results) if results else None
        )

        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO analysis_runs
                      (set_id, analysis_type, replicas, threads,
                       total_count, avg_score, avg_time_ms, invalid_count,
                       score_distribution, intent_stats,
                       chat_version_basis, feature_name)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                    """,
                    (
                        set_id,
                        analysis_type,
                        replicas,
                        threads,
                        summary["count"],
                        summary.get("avg_score"),
                        avg_time_ms,
                        invalid_count,
                        json.dumps(summary.get("score_distribution", {})),
                        json.dumps(intent_stats),
                        chat_version_basis,
                        feature_name,
                    ),
                )
                run_id: int = cur.fetchone()[0]

                for r in results:
                    cur.execute(
                        """
                        INSERT INTO analysis_results
                          (run_id, question_id, set_id, question, topic, location,
                           replica, score, reason,
                           context_precision, context_recall, context_entities_recall,
                           noise_sensitivity, response_relavancy, faithfulness,
                           response_time_ms, answer, intents)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """,
                        (
                            run_id,
                            r.question_id,
                            r.set_id,
                            r.question,
                            r.topic,
                            r.location,
                            r.replica,
                            r.evaluation.score,
                            r.evaluation.reason,
                            r.evaluation.context_precision,
                            r.evaluation.context_recall,
                            r.evaluation.context_entities_recall,
                            r.evaluation.noise_sensitivity,
                            r.evaluation.response_relavancy,
                            r.evaluation.faithfulness,
                            r.response_time_ms,
                            r.answer,
                            r.intents,
                        ),
                    )
            conn.commit()
        return run_id

    def get_previous_run(
        self, set_id: int, analysis_type: str, exclude_run_id: int
    ) -> dict | None:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id, run_date, avg_score, invalid_count,
                           score_distribution, intent_stats, total_count
                    FROM analysis_runs
                    WHERE set_id = %s AND analysis_type = %s AND id != %s
                    ORDER BY created_at DESC
                    LIMIT 1
                    """,
                    (set_id, analysis_type, exclude_run_id),
                )
                row = cur.fetchone()

        if not row:
            return None
        return {
            "run_id": row[0],
            "run_date": str(row[1]),
            "avg_score": float(row[2]) if row[2] is not None else None,
            "invalid_count": row[3],
            "score_distribution": row[4],
            "intent_stats": row[5],
            "total_count": row[6],
        }

    def get_previous_run_results(
        self, set_id: int, analysis_type: str, exclude_run_id: int
    ) -> list[dict]:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id FROM analysis_runs
                    WHERE set_id = %s AND analysis_type = %s AND id != %s
                    ORDER BY created_at DESC
                    LIMIT 1
                    """,
                    (set_id, analysis_type, exclude_run_id),
                )
                run_row = cur.fetchone()
                if not run_row:
                    return []

                cur.execute(
                    """
                    SELECT question, topic, score,
                           context_precision, context_recall, context_entities_recall,
                           noise_sensitivity, response_relavancy, faithfulness
                    FROM analysis_results
                    WHERE run_id = %s
                    """,
                    (run_row[0],),
                )
                rows = cur.fetchall()

        return [
            {
                "question": r[0],
                "topic": r[1],
                "score": float(r[2]) if r[2] is not None else None,
                "context_precision": float(r[3]) if r[3] is not None else None,
                "context_recall": float(r[4]) if r[4] is not None else None,
                "context_entities_recall": float(r[5]) if r[5] is not None else None,
                "noise_sensitivity": float(r[6]) if r[6] is not None else None,
                "response_relavancy": float(r[7]) if r[7] is not None else None,
                "faithfulness": float(r[8]) if r[8] is not None else None,
            }
            for r in rows
        ]

    def list_set_names_with_runs(self) -> list[str]:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT DISTINCT s.set_name
                    FROM sets s
                    JOIN analysis_runs ar ON ar.set_id = s.set_id
                    ORDER BY s.set_name
                    """
                )
                rows = cur.fetchall()
        return [r[0] for r in rows]

    def list_runs_for_set_and_date(self, set_name: str, run_date) -> list[dict]:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT ar.id, ar.analysis_type, ar.run_date, ar.avg_score,
                           ar.total_count, ar.chat_version_basis, ar.feature_name
                    FROM analysis_runs ar
                    JOIN sets s ON s.set_id = ar.set_id
                    WHERE s.set_name = %s AND ar.run_date::date = %s
                    ORDER BY ar.run_date DESC
                    """,
                    (set_name, run_date),
                )
                rows = cur.fetchall()
        return [
            {
                "run_id": r[0],
                "analysis_type": r[1],
                "run_date": str(r[2]),
                "avg_score": float(r[3]) if r[3] is not None else None,
                "total_count": r[4],
                "chat_version_basis": r[5],
                "feature_name": r[6],
            }
            for r in rows
        ]

    def get_run(self, run_id: int) -> dict | None:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT ar.id, ar.set_id, s.set_name, ar.analysis_type, ar.replicas, ar.threads,
                           ar.total_count, ar.avg_score, ar.avg_time_ms, ar.invalid_count,
                           ar.run_date, ar.chat_version_basis, ar.feature_name
                    FROM analysis_runs ar
                    JOIN sets s ON s.set_id = ar.set_id
                    WHERE ar.id = %s
                    """,
                    (run_id,),
                )
                row = cur.fetchone()
        if not row:
            return None
        return {
            "run_id": row[0],
            "set_id": row[1],
            "set_name": row[2],
            "analysis_type": row[3],
            "replicas": row[4],
            "threads": row[5],
            "total_count": row[6],
            "avg_score": float(row[7]) if row[7] is not None else None,
            "avg_time_ms": float(row[8]) if row[8] is not None else None,
            "invalid_count": row[9],
            "run_date": str(row[10]),
            "chat_version_basis": row[11],
            "feature_name": row[12],
        }

    def get_run_results(self, run_id: int) -> list[dict]:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT question, topic, location, replica, score, reason,
                           context_precision, context_recall, context_entities_recall,
                           noise_sensitivity, response_relavancy, faithfulness,
                           response_time_ms, answer, intents
                    FROM analysis_results
                    WHERE run_id = %s
                    ORDER BY id
                    """,
                    (run_id,),
                )
                rows = cur.fetchall()
        return [
            {
                "question": r[0],
                "topic": r[1],
                "location": r[2],
                "replica": r[3],
                "score": float(r[4]) if r[4] is not None else None,
                "reason": r[5],
                "context_precision": float(r[6]) if r[6] is not None else None,
                "context_recall": float(r[7]) if r[7] is not None else None,
                "context_entities_recall": float(r[8]) if r[8] is not None else None,
                "noise_sensitivity": float(r[9]) if r[9] is not None else None,
                "response_relavancy": float(r[10]) if r[10] is not None else None,
                "faithfulness": float(r[11]) if r[11] is not None else None,
                "response_time_ms": float(r[12]) if r[12] is not None else None,
                "answer": r[13],
                "intents": r[14],
            }
            for r in rows
        ]

    def get_score_trend(
        self, set_id: int, analysis_type: str, run_id: int, limit: int = 10
    ) -> list[dict]:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id, run_date, avg_score
                    FROM analysis_runs
                    WHERE set_id = %s AND analysis_type = %s
                      AND created_at <= (SELECT created_at FROM analysis_runs WHERE id = %s)
                    ORDER BY created_at DESC
                    LIMIT %s
                    """,
                    (set_id, analysis_type, run_id, limit),
                )
                rows = cur.fetchall()
        return [
            {"run_id": r[0], "run_date": str(r[1]), "avg_score": float(r[2]) if r[2] is not None else None}
            for r in reversed(rows)
        ]
