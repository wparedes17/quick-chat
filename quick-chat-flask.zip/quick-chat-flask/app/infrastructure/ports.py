from typing import Generator, Protocol

from app.domain.chat.entities import ChatAnswer, ChatMetadata, ChatRequest, StreamEvent
from app.domain.shared import EvaluationResult


class ScoringGatewayProtocol(Protocol):
    def score(self, request: ChatRequest, base_url: str | None = None) -> ChatAnswer: ...
    def score_stream(
        self, request: ChatRequest, base_url: str | None = None
    ) -> Generator[StreamEvent, None, None]: ...
    def health(self, base_url: str | None = None) -> dict: ...


class EvaluatorGatewayProtocol(Protocol):
    def evaluate(
        self, question: str, answer: str, criteria: str, metadata: ChatMetadata | None = None
    ) -> EvaluationResult: ...


class FollowGatewayProtocol(Protocol):
    def follow(self, last_user_message: str, last_system_response: str) -> str: ...
