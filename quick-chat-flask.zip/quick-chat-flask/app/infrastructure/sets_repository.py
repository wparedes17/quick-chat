import psycopg

from app.domain.evaluation.value_objects import EvaluationRow


class SetsRepository:
    def __init__(self, dsn: str) -> None:
        self._dsn = dsn

    def list_sets(self, set_type: str | None = None) -> list[dict]:
        query = """
            SELECT s.set_id, s.set_name, s.set_type, COUNT(t.question_id)
            FROM sets s
            LEFT JOIN test_sets t ON t.set_id = s.set_id
            {where}
            GROUP BY s.set_id, s.set_name, s.set_type
            ORDER BY s.set_id
        """
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                if set_type:
                    cur.execute(query.format(where="WHERE s.set_type = %s"), (set_type,))
                else:
                    cur.execute(query.format(where=""))
                rows = cur.fetchall()
        return [
            {"set_id": r[0], "set_name": r[1], "set_type": r[2], "question_count": r[3]}
            for r in rows
        ]

    def get_set(self, set_id: int) -> dict | None:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT set_id, set_name, set_type FROM sets WHERE set_id = %s", (set_id,)
                )
                row = cur.fetchone()
        if not row:
            return None
        return {"set_id": row[0], "set_name": row[1], "set_type": row[2]}

    def create_set(self, set_name: str, set_type: str) -> dict:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO sets (set_name, set_type) VALUES (%s, %s) RETURNING set_id",
                    (set_name, set_type),
                )
                set_id = cur.fetchone()[0]
            conn.commit()
        return {"set_id": set_id, "set_name": set_name, "set_type": set_type}

    def update_set(self, set_id: int, set_name: str, set_type: str) -> None:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE sets SET set_name = %s, set_type = %s WHERE set_id = %s",
                    (set_name, set_type, set_id),
                )
            conn.commit()

    def delete_set(self, set_id: int) -> None:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM sets WHERE set_id = %s", (set_id,))
            conn.commit()

    def list_test_sets(self, set_id: int) -> list[dict]:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT question_id, set_id, question, topic, criteria, location
                    FROM test_sets WHERE set_id = %s ORDER BY question_id
                    """,
                    (set_id,),
                )
                rows = cur.fetchall()
        return [
            {
                "question_id": r[0],
                "set_id": r[1],
                "question": r[2],
                "topic": r[3],
                "criteria": r[4],
                "location": r[5],
            }
            for r in rows
        ]

    def create_test_set(
        self, set_id: int, question: str, criteria: str, location: str, topic: str | None = None
    ) -> dict:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO test_sets (set_id, question, topic, criteria, location)
                    VALUES (%s, %s, %s, %s, %s) RETURNING question_id
                    """,
                    (set_id, question, topic, criteria, location),
                )
                question_id = cur.fetchone()[0]
            conn.commit()
        return {
            "question_id": question_id,
            "set_id": set_id,
            "question": question,
            "topic": topic,
            "criteria": criteria,
            "location": location,
        }

    def update_test_set(
        self,
        question_id: int,
        question: str,
        criteria: str,
        location: str,
        topic: str | None = None,
    ) -> None:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE test_sets SET question = %s, topic = %s, criteria = %s, location = %s
                    WHERE question_id = %s
                    """,
                    (question, topic, criteria, location, question_id),
                )
            conn.commit()

    def delete_test_set(self, question_id: int) -> None:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM test_sets WHERE question_id = %s", (question_id,))
            conn.commit()

    def get_test_set_rows(self, set_id: int) -> list[EvaluationRow]:
        with psycopg.connect(self._dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT question_id, set_id, question, topic, criteria, location
                    FROM test_sets WHERE set_id = %s ORDER BY question_id
                    """,
                    (set_id,),
                )
                rows = cur.fetchall()
        return [
            EvaluationRow(
                question=r[2],
                criteria=r[4],
                topic=r[3],
                question_id=r[0],
                set_id=r[1],
                location=r[5],
            )
            for r in rows
        ]
