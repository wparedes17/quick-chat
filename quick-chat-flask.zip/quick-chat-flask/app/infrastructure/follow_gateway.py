import re

import httpx

_HEADERS = {"Content-Type": "application/json", "Accept-Language": "en"}


class FollowGateway:
    def __init__(self, base_url: str) -> None:
        self._base_url = base_url.rstrip("/")

    def follow(self, last_user_message: str, last_system_response: str) -> str:
        payload = {
            "last_message_from_you": last_user_message,
            "last_response_from_system": last_system_response,
        }
        with httpx.Client(timeout=60.0) as client:
            r = client.post(f"{self._base_url}/follow", json=payload, headers=_HEADERS)
            r.raise_for_status()
            data = r.json()
        raw = data.get("new_message", "") if isinstance(data.get("new_message"), str) else ""
        # Normalize escape sequences and whitespace (mirrors chatApi.ts follow())
        raw = re.sub(r"\\[nrt]", " ", raw)
        raw = re.sub(r"[\n\r\t]", " ", raw)
        return re.sub(r"\s+", " ", raw).strip()
