from dataclasses import asdict

import httpx

from app.domain.chat.entities import ChatMetadata
from app.domain.shared import EvaluationResult

_HEADERS = {"Content-Type": "application/json", "Accept-Language": "en"}


def _num_or_none(value: object) -> float | None:
    return float(value) if isinstance(value, (int, float)) else None


class EvaluatorGateway:
    def __init__(self, base_url: str) -> None:
        self._base_url = base_url.rstrip("/")

    def evaluate(
        self,
        question: str,
        answer: str,
        criteria: str,
        metadata: ChatMetadata | None = None,
    ) -> EvaluationResult:
        payload = {"question": question, "answer": answer, "criteria": criteria}
        if metadata is not None:
            payload["metadata"] = asdict(metadata)
        with httpx.Client(timeout=60.0) as client:
            r = client.post(f"{self._base_url}/evaluate", json=payload, headers=_HEADERS)
            r.raise_for_status()
            data = r.json()
        return EvaluationResult(
            score=int(data["score"]) if isinstance(data.get("score"), (int, float)) else 0,
            reason=data.get("reason", "") if isinstance(data.get("reason"), str) else "",
            context_precision=_num_or_none(data.get("context_precision")),
            context_recall=_num_or_none(data.get("context_recall")),
            context_entities_recall=_num_or_none(data.get("context_entities_recall")),
            noise_sensitivity=_num_or_none(data.get("noise_sensitivity")),
            response_relavancy=_num_or_none(data.get("response_relavancy")),
            faithfulness=_num_or_none(data.get("faithfulness")),
        )
