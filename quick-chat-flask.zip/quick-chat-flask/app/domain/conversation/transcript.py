from dataclasses import dataclass

from app.domain.conversation.entities import Conversation


@dataclass(frozen=True)
class ConversationTranscript:
    text: str           # passed as `question` to /evaluate
    last_response: str  # passed as `answer` to /evaluate


class TranscriptFormatter:
    def format(self, conversation: Conversation) -> ConversationTranscript:
        lines = []
        for turn in conversation.turns:
            lines.append(f"USER: {turn.user_message}")
            lines.append(f"SYSTEM: {turn.system_response}")
        last_response = conversation.turns[-1].system_response if conversation.turns else ""
        return ConversationTranscript(text="\n\n".join(lines), last_response=last_response)
