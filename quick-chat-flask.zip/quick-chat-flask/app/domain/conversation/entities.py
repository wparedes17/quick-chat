from dataclasses import dataclass, field
from typing import Literal

from app.domain.shared import EvaluationResult, Location


@dataclass
class Turn:
    turn_number: int
    user_message: str
    system_response: str


@dataclass
class Conversation:
    conversation_id: str
    session_id: str
    user_id: str
    location: Location
    turns: list[Turn] = field(default_factory=list)
    evaluation: EvaluationResult | None = None


@dataclass
class ConversationEvent:
    kind: Literal["turn_complete", "status", "error"]
    turn: Turn | None = None
    message: str = ""
