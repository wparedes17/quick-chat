from dataclasses import dataclass, field
from typing import Literal

from app.domain.shared import Location


@dataclass(frozen=True)
class ChatRequest:
    request_id: str
    question: str
    location: Location
    session_id: str
    user_id: str


@dataclass(frozen=True)
class ChatModule:
    module_name: str
    module_type: str
    text_response: str
    raw_input_data: dict
    raw_output_data: dict


@dataclass(frozen=True)
class ChatMetadata:
    intents: list[str]
    modules: list[ChatModule]


@dataclass(frozen=True)
class ChatAnswer:
    answer: str
    intents: list[str]
    rewritten_question: str = ""
    metadata: ChatMetadata | None = None


@dataclass
class Message:
    message_id: str
    role: Literal["user", "assistant"]
    content: str
    intents: list[str] = field(default_factory=list)
    pending: bool = False


@dataclass
class StreamEvent:
    kind: Literal["chunk", "intents", "done"]
    payload: str | list[str] = ""
