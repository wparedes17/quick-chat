from dataclasses import dataclass, field

from app.domain.shared import EvaluationResult, Location


@dataclass
class RunResult:
    result_id: str
    question: str
    replica: int
    evaluation: EvaluationResult
    response_time_ms: float
    topic: str | None = None
    answer: str = ""
    intents: list[str] = field(default_factory=list)
    rewritten_question: str = ""
    question_id: int | None = None
    set_id: int | None = None
    location: str | None = None

    @property
    def is_invalid(self) -> bool:
        return "INVALID_INPUT" in self.answer
