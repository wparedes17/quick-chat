from dataclasses import dataclass


@dataclass(frozen=True)
class EvaluationRow:
    question: str
    criteria: str
    topic: str | None = None
    question_id: int | None = None
    set_id: int | None = None
    location: str | None = None
