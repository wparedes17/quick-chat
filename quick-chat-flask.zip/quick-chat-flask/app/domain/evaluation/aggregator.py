from collections import Counter
from collections.abc import Sequence

from app.domain.evaluation.entities import RunResult


SCORE_COLORS = ["", "#ef4444", "#f97316", "#eab308", "#84cc16", "#22c55e"]

TOPIC_PALETTE = [
    "#6366f1", "#f59e0b", "#10b981", "#ef4444", "#3b82f6",
    "#8b5cf6", "#f97316", "#06b6d4", "#ec4899", "#14b8a6",
]


def _avg(nums: Sequence[float]) -> float:
    return sum(nums) / len(nums) if nums else 0.0


def _format_ms(ms: float) -> str:
    return f"{ms / 1000:.1f}s" if ms >= 1000 else f"{round(ms)}ms"


def build_score_distribution(results: list[RunResult]) -> dict[int, int]:
    return {s: sum(1 for r in results if r.evaluation.score == s) for s in range(1, 6)}


def build_time_histogram(times: list[float], num_buckets: int = 8) -> list[dict]:
    if not times:
        return []
    lo, hi = min(times), max(times)
    if lo == hi:
        return [{"label": _format_ms(lo), "count": len(times)}]
    width = (hi - lo) / num_buckets
    buckets = []
    for i in range(num_buckets):
        bucket_lo = lo + i * width
        bucket_hi = bucket_lo + width
        count = sum(
            1 for t in times
            if (i == num_buckets - 1 and t <= bucket_hi) or (t >= bucket_lo and t < bucket_hi)
        )
        buckets.append({"label": _format_ms(bucket_lo), "count": count})
    return buckets


def build_summary(results: list[RunResult]) -> dict:
    if not results:
        return {
            "count": 0,
            "avg_score": None,
            "avg_time": None,
            "score_distribution": {},
            "time_histogram": [],
        }
    scores = [r.evaluation.score for r in results]
    times = [r.response_time_ms for r in results]
    return {
        "count": len(results),
        "avg_score": round(_avg(scores), 2),
        "avg_time": _format_ms(_avg(times)),
        "score_distribution": build_score_distribution(results),
        "time_histogram": build_time_histogram(times),
    }


def build_topic_stats(results: list[RunResult]) -> list[dict]:
    topics = sorted({r.topic for r in results if r.topic})
    stats = []
    for i, topic in enumerate(topics):
        tr = [r for r in results if r.topic == topic]
        scores = [r.evaluation.score for r in tr]
        times = [r.response_time_ms for r in tr]
        stats.append({
            "topic": topic,
            "color": TOPIC_PALETTE[i % len(TOPIC_PALETTE)],
            "count": len(tr),
            "avg_score": round(_avg(scores), 2),
            "avg_time_ms": round(_avg(times)),
            "avg_time": _format_ms(_avg(times)),
            "score_distribution": build_score_distribution(tr),
            "intent_stats": build_intent_stats(tr),
            "invalid_count": count_invalid(tr),
        })
    return stats


def build_intent_stats(results: list[RunResult]) -> dict[str, int]:
    counts: Counter = Counter()
    for r in results:
        for intent in r.intents:
            if intent:
                counts[intent] += 1
    return dict(counts.most_common())


def count_invalid(results: list[RunResult]) -> int:
    return sum(1 for r in results if r.is_invalid)


_METRIC_FIELDS = [
    "score",
    "context_precision",
    "context_recall",
    "context_entities_recall",
    "noise_sensitivity",
    "response_relavancy",
    "faithfulness",
]


def _group_avg_by_question(rows: list[dict]) -> dict[tuple[str, str | None], dict[str, float | None]]:
    groups: dict[tuple[str, str | None], list[dict]] = {}
    for row in rows:
        key = (row["question"], row.get("topic"))
        groups.setdefault(key, []).append(row)

    averaged: dict[tuple[str, str | None], dict[str, float | None]] = {}
    for key, group in groups.items():
        avgs: dict[str, float | None] = {}
        for field in _METRIC_FIELDS:
            values = [g[field] for g in group if g.get(field) is not None]
            avgs[field] = round(_avg(values), 3) if values else None
        averaged[key] = avgs
    return averaged


def build_metric_averages(rows: list[dict]) -> dict[str, float | None]:
    """Average of each metric field (score + the 6 optional RAGAS metrics) across
    a list of per-result dicts, skipping missing values. `rows` uses the same
    shape as run_results_to_metric_rows/get_run_results/get_previous_run_results."""
    averages: dict[str, float | None] = {}
    for field in _METRIC_FIELDS:
        values = [r[field] for r in rows if r.get(field) is not None]
        averages[field] = round(_avg(values), 3) if values else None
    return averages


def run_results_to_metric_rows(results: list[RunResult]) -> list[dict]:
    """Flattens RunResult objects into the plain dict shape build_danger_list expects
    (the same shape AnalysisRepository.get_previous_run_results/get_run_results return),
    so live-run and historical-run comparisons share one code path."""
    return [
        {
            "question": r.question,
            "topic": r.topic,
            "score": r.evaluation.score,
            "context_precision": r.evaluation.context_precision,
            "context_recall": r.evaluation.context_recall,
            "context_entities_recall": r.evaluation.context_entities_recall,
            "noise_sensitivity": r.evaluation.noise_sensitivity,
            "response_relavancy": r.evaluation.response_relavancy,
            "faithfulness": r.evaluation.faithfulness,
        }
        for r in results
    ]


def build_question_comparison(current: list[dict], previous: list[dict]) -> list[dict]:
    """Per-question comparison of every metric field vs. the previous run, for every
    question present in `current` — regardless of whether it regressed, improved, or
    is new (unlike build_danger_list, which only reports the regressed subset). Powers
    the expandable-row detail card, which needs previous/current values for a question
    whether or not it's "in danger."

    Both `current` and `previous` are lists of per-result dicts (the shape
    `run_results_to_metric_rows`/`AnalysisRepository.get_previous_run_results`/
    `get_run_results` all produce). Both sides are averaged per (question, topic)
    across replicas before comparing, since a single replica's fluctuation
    shouldn't drive the signal.
    """
    current_by_question = _group_avg_by_question(current)
    previous_by_question = _group_avg_by_question(previous)

    comparison: list[dict] = []
    for (question, topic), cur in current_by_question.items():
        prev = previous_by_question.get((question, topic))
        metrics: dict[str, dict] = {}
        in_danger = False
        for field in _METRIC_FIELDS:
            cur_val = cur.get(field)
            prev_val = prev.get(field) if prev else None
            entry: dict[str, float | None] = {"current": cur_val, "previous": prev_val}
            if cur_val is not None and prev_val is not None:
                entry["delta"] = round(cur_val - prev_val, 3)
                if cur_val < prev_val:
                    in_danger = True
            metrics[field] = entry
        comparison.append({
            "question": question,
            "topic": topic,
            "in_danger": in_danger,
            "metrics": metrics,
        })
    return comparison


def build_danger_list(current: list[dict], previous: list[dict]) -> list[dict]:
    """Questions/topics whose score or an optional metric decreased vs. the previous run.

    A thin filter over build_question_comparison, reshaped to its established
    external shape (only the fields that actually regressed, keyed as "regressions").
    """
    danger: list[dict] = []
    for entry in build_question_comparison(current, previous):
        if not entry["in_danger"]:
            continue
        regressions = {
            field: {"previous": m["previous"], "current": m["current"], "delta": m["delta"]}
            for field, m in entry["metrics"].items()
            if "delta" in m and m["delta"] < 0
        }
        danger.append({"question": entry["question"], "topic": entry["topic"], "regressions": regressions})
    return danger


def _matched_score_gains(current: list[dict], previous: list[dict]) -> list[tuple[str | None, float]]:
    """(topic, gain) for every question present in both runs with a score on both
    sides — the paired per-question score deltas that build_score_gain_significance
    runs its t-test over."""
    current_by_question = _group_avg_by_question(current)
    previous_by_question = _group_avg_by_question(previous)

    gains: list[tuple[str | None, float]] = []
    for (question, topic), cur in current_by_question.items():
        prev = previous_by_question.get((question, topic))
        if prev and cur.get("score") is not None and prev.get("score") is not None:
            gains.append((topic, cur["score"] - prev["score"]))
    return gains


def compute_gain_significance(gains: Sequence[float], confidence: float = 0.95) -> dict | None:
    """Two-sided one-sample t-test of `gains` against H0: mean gain = 0 (no change),
    with a confidence interval for the mean gain. Returns None when there are fewer
    than 2 data points — a t-test is undefined below that, so callers must treat this
    as a distinct "not enough data" state, not an error."""
    if len(gains) < 2:
        return None
    from scipy import stats

    mean_gain = _avg(gains)
    t_result = stats.ttest_1samp(gains, popmean=0.0)
    sem = stats.sem(gains)
    if sem > 0:
        ci_low, ci_high = stats.t.interval(confidence, df=len(gains) - 1, loc=mean_gain, scale=sem)
    else:
        ci_low = ci_high = mean_gain
    return {
        "n": len(gains),
        "mean_gain": round(mean_gain, 3),
        "ci_low": round(float(ci_low), 3),
        "ci_high": round(float(ci_high), 3),
        "p_value": round(float(t_result.pvalue), 4),
        "significant": bool(t_result.pvalue < (1 - confidence)),
    }


def build_score_gain_significance(
    current: list[dict], previous: list[dict], confidence: float = 0.95
) -> dict:
    """Overall + per-topic significance of the average score gain vs. the previous run,
    via a paired two-sided t-test on matched per-question gains (see
    _matched_score_gains/compute_gain_significance)."""
    matched = _matched_score_gains(current, previous)
    overall = compute_gain_significance([g for _, g in matched], confidence)

    by_topic: dict[str, dict] = {}
    topics = sorted({t for t, _ in matched if t})
    for topic in topics:
        topic_gains = [g for t, g in matched if t == topic]
        result = compute_gain_significance(topic_gains, confidence)
        if result:
            by_topic[topic] = result

    return {"overall": overall, "by_topic": by_topic}


def build_score_distribution_from_rows(rows: list[dict]) -> dict[int, int]:
    """Same bucketing as build_score_distribution, but over plain per-result dicts —
    needed for a previous run's distribution, which only exists as dicts from
    AnalysisRepository.get_previous_run_results (no RunResult objects for it)."""
    return {s: sum(1 for r in rows if r.get("score") is not None and int(r["score"]) == s) for s in range(1, 6)}


def compute_trend_significance(trend: list[dict], confidence: float = 0.95) -> dict | None:
    """Is this set's avg_score trend across its historical runs actually improving/
    declining, or just noise? Linear regression of avg_score over run order (oldest
    to newest, as `trend` — e.g. from AnalysisRepository.get_score_trend — is already
    ordered) via scipy.stats.linregress. Returns None below 3 scored runs, since a
    trend line isn't meaningful with fewer points."""
    scored = [t["avg_score"] for t in trend if t.get("avg_score") is not None]
    if len(scored) < 3:
        return None
    from scipy import stats

    result = stats.linregress(range(len(scored)), scored)
    return {
        "slope": round(float(result.slope), 4),
        "intercept": round(float(result.intercept), 4),
        "p_value": round(float(result.pvalue), 4),
        "r_value": round(float(result.rvalue), 4),
        "significant": bool(result.pvalue < (1 - confidence)),
    }


def find_outliers(results: list[RunResult], z_threshold: float = 2.0) -> list[dict]:
    """Flags questions whose score or response time is a statistical outlier
    (|z-score| > z_threshold) within this run's own distribution. Uses a population
    z-score; a field with zero variance across the run reports no outliers for it
    (division by zero would otherwise be undefined, not "everything is an outlier")."""
    def _z_scores(values: list[float]) -> list[float]:
        if not values:
            return []
        mean = _avg(values)
        variance = _avg([(v - mean) ** 2 for v in values])
        stddev = variance ** 0.5
        if stddev == 0:
            return [0.0] * len(values)
        return [(v - mean) / stddev for v in values]

    scores = [r.evaluation.score for r in results]
    times = [r.response_time_ms for r in results]
    score_z = _z_scores(scores)
    time_z = _z_scores(times)

    outliers: list[dict] = []
    for r, sz, tz in zip(results, score_z, time_z):
        if abs(sz) > z_threshold:
            outliers.append({
                "question": r.question, "topic": r.topic, "replica": r.replica,
                "metric": "score", "value": r.evaluation.score, "z_score": round(sz, 2),
            })
        if abs(tz) > z_threshold:
            outliers.append({
                "question": r.question, "topic": r.topic, "replica": r.replica,
                "metric": "response_time_ms", "value": round(r.response_time_ms, 1), "z_score": round(tz, 2),
            })
    return outliers
