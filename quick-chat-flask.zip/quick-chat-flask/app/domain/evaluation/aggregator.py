from collections import Counter
from collections.abc import Sequence

from app.domain.evaluation.entities import RunResult


SCORE_COLORS = ["", "#ef4444", "#f97316", "#eab308", "#84cc16", "#22c55e"]

TOPIC_PALETTE = [
    "#6366f1", "#f59e0b", "#10b981", "#ef4444", "#3b82f6",
    "#8b5cf6", "#f97316", "#06b6d4", "#ec4899", "#14b8a6",
]


def _avg(nums: Sequence[float]) -> float:
    return sum(nums) / len(nums) if nums else 0.0


def _format_ms(ms: float) -> str:
    return f"{ms / 1000:.1f}s" if ms >= 1000 else f"{round(ms)}ms"


def build_score_distribution(results: list[RunResult]) -> dict[int, int]:
    return {s: sum(1 for r in results if r.evaluation.score == s) for s in range(1, 6)}


def build_time_histogram(times: list[float], num_buckets: int = 8) -> list[dict]:
    if not times:
        return []
    lo, hi = min(times), max(times)
    if lo == hi:
        return [{"label": _format_ms(lo), "count": len(times)}]
    width = (hi - lo) / num_buckets
    buckets = []
    for i in range(num_buckets):
        bucket_lo = lo + i * width
        bucket_hi = bucket_lo + width
        count = sum(
            1 for t in times
            if (i == num_buckets - 1 and t <= bucket_hi) or (t >= bucket_lo and t < bucket_hi)
        )
        buckets.append({"label": _format_ms(bucket_lo), "count": count})
    return buckets


def build_summary(results: list[RunResult]) -> dict:
    if not results:
        return {"count": 0, "avg_score": None, "avg_time_ms": None, "failed_count": 0}
    scores = [r.evaluation.score for r in results]
    times = [r.response_time_ms for r in results]
    return {
        "count": len(results),
        "avg_score": round(_avg(scores), 2),
        "avg_time": _format_ms(_avg(times)),
        "score_distribution": build_score_distribution(results),
        "time_histogram": build_time_histogram(times),
    }


def build_topic_stats(results: list[RunResult]) -> list[dict]:
    topics = sorted({r.topic for r in results if r.topic})
    stats = []
    for i, topic in enumerate(topics):
        tr = [r for r in results if r.topic == topic]
        scores = [r.evaluation.score for r in tr]
        times = [r.response_time_ms for r in tr]
        stats.append({
            "topic": topic,
            "color": TOPIC_PALETTE[i % len(TOPIC_PALETTE)],
            "count": len(tr),
            "avg_score": round(_avg(scores), 2),
            "avg_time_ms": round(_avg(times)),
            "avg_time": _format_ms(_avg(times)),
            "score_distribution": build_score_distribution(tr),
            "intent_stats": build_intent_stats(tr),
            "invalid_count": count_invalid(tr),
        })
    return stats


def build_intent_stats(results: list[RunResult]) -> dict[str, int]:
    counts: Counter = Counter()
    for r in results:
        for intent in r.intents:
            if intent:
                counts[intent] += 1
    return dict(counts.most_common())


def count_invalid(results: list[RunResult]) -> int:
    return sum(1 for r in results if r.is_invalid)


_METRIC_FIELDS = [
    "score",
    "context_precision",
    "context_recall",
    "context_entities_recall",
    "noise_sensitivity",
    "response_relavancy",
    "faithfulness",
]


def _group_avg_by_question(rows: list[dict]) -> dict[tuple[str, str | None], dict[str, float | None]]:
    groups: dict[tuple[str, str | None], list[dict]] = {}
    for row in rows:
        key = (row["question"], row.get("topic"))
        groups.setdefault(key, []).append(row)

    averaged: dict[tuple[str, str | None], dict[str, float | None]] = {}
    for key, group in groups.items():
        avgs: dict[str, float | None] = {}
        for field in _METRIC_FIELDS:
            values = [g[field] for g in group if g.get(field) is not None]
            avgs[field] = round(_avg(values), 3) if values else None
        averaged[key] = avgs
    return averaged


def build_metric_averages(rows: list[dict]) -> dict[str, float | None]:
    """Average of each metric field (score + the 6 optional RAGAS metrics) across
    a list of per-result dicts, skipping missing values. `rows` uses the same
    shape as run_results_to_metric_rows/get_run_results/get_previous_run_results."""
    averages: dict[str, float | None] = {}
    for field in _METRIC_FIELDS:
        values = [r[field] for r in rows if r.get(field) is not None]
        averages[field] = round(_avg(values), 3) if values else None
    return averages


def run_results_to_metric_rows(results: list[RunResult]) -> list[dict]:
    """Flattens RunResult objects into the plain dict shape build_danger_list expects
    (the same shape AnalysisRepository.get_previous_run_results/get_run_results return),
    so live-run and historical-run comparisons share one code path."""
    return [
        {
            "question": r.question,
            "topic": r.topic,
            "score": r.evaluation.score,
            "context_precision": r.evaluation.context_precision,
            "context_recall": r.evaluation.context_recall,
            "context_entities_recall": r.evaluation.context_entities_recall,
            "noise_sensitivity": r.evaluation.noise_sensitivity,
            "response_relavancy": r.evaluation.response_relavancy,
            "faithfulness": r.evaluation.faithfulness,
        }
        for r in results
    ]


def build_danger_list(current: list[dict], previous: list[dict]) -> list[dict]:
    """Questions/topics whose score or an optional metric decreased vs. the previous run.

    Both `current` and `previous` are lists of per-result dicts (the shape
    `run_results_to_metric_rows`/`AnalysisRepository.get_previous_run_results`/
    `get_run_results` all produce). Both sides are averaged per (question, topic)
    across replicas before comparing, since a single replica's fluctuation
    shouldn't drive the "in danger" signal.
    """
    current_by_question = _group_avg_by_question(current)
    previous_by_question = _group_avg_by_question(previous)

    danger: list[dict] = []
    for (question, topic), cur in current_by_question.items():
        prev = previous_by_question.get((question, topic))
        if not prev:
            continue
        regressions = {}
        for field in _METRIC_FIELDS:
            cur_val, prev_val = cur.get(field), prev.get(field)
            if cur_val is None or prev_val is None or cur_val >= prev_val:
                continue
            regressions[field] = {
                "previous": prev_val,
                "current": cur_val,
                "delta": round(cur_val - prev_val, 3),
            }
        if regressions:
            danger.append({"question": question, "topic": topic, "regressions": regressions})
    return danger
