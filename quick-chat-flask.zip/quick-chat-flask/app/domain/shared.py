from dataclasses import dataclass
from enum import Enum


class Location(str, Enum):
    US = "us"
    EU = "eu"


class SetType(str, Enum):
    MULTIPLE = "multiple"
    TOPIC = "topic"


@dataclass(frozen=True)
class EvaluationResult:
    score: int    # 1-5
    reason: str
    context_precision: float | None = None
    context_recall: float | None = None
    context_entities_recall: float | None = None
    noise_sensitivity: float | None = None
    response_relavancy: float | None = None
    faithfulness: float | None = None
