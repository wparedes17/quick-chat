from flask import Flask

from config import DATABASE_URL, EVALUATOR_URL, FOLLOW_URL, SCORING_URL
from app.infrastructure.evaluator_gateway import EvaluatorGateway
from app.infrastructure.follow_gateway import FollowGateway
from app.infrastructure.scoring_gateway import ScoringGateway
from app.infrastructure.analysis_repository import AnalysisRepository
from app.infrastructure.sets_repository import SetsRepository
from app.application.chat_service import ChatApplicationService
from app.application.evaluation_service import EvaluationService
from app.application.conversation_service import ConversationService
from app.application.sets_service import SetsService
from app.interfaces.chat.routes import chat_bp
from app.interfaces.evaluation.routes import evaluation_bp
from app.interfaces.conversation.routes import conversation_bp
from app.interfaces.sets.routes import sets_bp
from app.interfaces.deep_analysis.routes import deep_analysis_bp


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")

    scoring_gw   = ScoringGateway(SCORING_URL)
    evaluator_gw = EvaluatorGateway(EVALUATOR_URL)
    follow_gw    = FollowGateway(FOLLOW_URL)
    sets_repo    = SetsRepository(DATABASE_URL) if DATABASE_URL else None

    app.config["CHAT_SERVICE"]         = ChatApplicationService(scoring_gw)
    app.config["EVALUATION_SERVICE"]   = EvaluationService(scoring_gw, evaluator_gw)
    app.config["CONVERSATION_SERVICE"] = ConversationService(scoring_gw, evaluator_gw, follow_gw)
    app.config["ANALYSIS_REPO"]        = AnalysisRepository(DATABASE_URL) if DATABASE_URL else None
    app.config["SETS_REPO"]            = sets_repo
    app.config["SETS_SERVICE"]         = SetsService(sets_repo) if sets_repo else None

    app.register_blueprint(chat_bp)
    app.register_blueprint(evaluation_bp, url_prefix="/evaluation")
    app.register_blueprint(conversation_bp, url_prefix="/conversation")
    app.register_blueprint(sets_bp)
    app.register_blueprint(deep_analysis_bp)

    @app.context_processor
    def inject_default_scoring_url():
        return {"default_scoring_url": SCORING_URL}

    return app
