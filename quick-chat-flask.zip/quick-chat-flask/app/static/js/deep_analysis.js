// Deep Analysis tab

import { formatMs, escHtml, formatMetric, renderDangerRows, renderSignificance, METRIC_LABELS } from './analysis_common.js';

const SCORE_COLORS = ['', '#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e'];
const TOPIC_PALETTE = ['#6366f1','#f59e0b','#10b981','#ef4444','#3b82f6','#8b5cf6','#f97316','#06b6d4','#ec4899','#14b8a6'];
const ACCENT = '#6366f1';
const MUTED = 'hsl(var(--muted-foreground))';

const setNameSelect = document.getElementById('set-name-select');
const runDateInput = document.getElementById('run-date-input');
const runSelect = document.getElementById('run-select');
const selectorError = document.getElementById('selector-error');
const dashboardArea = document.getElementById('dashboard-area');

const perTopicGrid = document.getElementById('per-topic-grid');
const dangerSection = document.getElementById('danger-section');
const dangerTbody = document.getElementById('danger-tbody');
const resultsTbody = document.getElementById('results-tbody');
const metricsChartCard = document.getElementById('metrics-chart-card');
const significanceContent = document.getElementById('significance-content');
const trendSignificanceCaption = document.getElementById('trend-significance-caption');
const outliersSection = document.getElementById('outliers-section');
const outliersTbody = document.getElementById('outliers-tbody');

let trendChart = null;
let scoreDistChart = null;
let metricsChart = null;
const perTopicCharts = {};

async function api(url) {
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

async function loadSetNames() {
  try {
    const { set_names } = await api('/deep-analysis/set-names');
    setNameSelect.innerHTML = '<option value="">Select a set…</option>' +
      set_names.map(name => `<option value="${escHtml(name)}">${escHtml(name)}</option>`).join('');
  } catch (err) {
    selectorError.textContent = err.message;
    selectorError.classList.remove('hidden');
  }
}
loadSetNames();

setNameSelect.addEventListener('change', () => {
  runDateInput.value = '';
  runDateInput.disabled = !setNameSelect.value;
  runSelect.innerHTML = '<option value="">—</option>';
  runSelect.disabled = true;
  dashboardArea.classList.add('hidden');
});

runDateInput.addEventListener('change', async () => {
  if (!setNameSelect.value || !runDateInput.value) return;
  selectorError.classList.add('hidden');
  try {
    const { runs } = await api(`/deep-analysis/runs?set_name=${encodeURIComponent(setNameSelect.value)}&date=${runDateInput.value}`);
    if (runs.length === 0) {
      runSelect.innerHTML = '<option value="">No runs on this date</option>';
      runSelect.disabled = true;
      return;
    }
    runSelect.innerHTML = runs.map(r =>
      `<option value="${r.run_id}">#${r.run_id} — ${escHtml(r.analysis_type)} — avg ${r.avg_score ?? 'NA'} (${r.total_count} runs)</option>`
    ).join('');
    runSelect.disabled = false;
  } catch (err) {
    selectorError.textContent = err.message;
    selectorError.classList.remove('hidden');
  }
});

runSelect.addEventListener('change', async () => {
  if (!runSelect.value) return;
  selectorError.classList.add('hidden');
  try {
    const dashboard = await api(`/deep-analysis/${runSelect.value}`);
    renderDashboard(dashboard);
  } catch (err) {
    selectorError.textContent = err.message;
    selectorError.classList.remove('hidden');
  }
});

function renderDashboard(d) {
  dashboardArea.classList.remove('hidden');
  renderRunHeader(d.run);
  renderKpis(d.summary, d.run);
  significanceContent.innerHTML = renderSignificance(d.significance?.overall);
  renderTrendChart(d.trend, d.trend_significance);
  renderScoreDistChart(d.summary.score_distribution, d.previous_score_distribution);
  renderMetricsChart(d.metric_averages, d.previous_metric_averages);
  renderPerTopic(d.topic_stats);
  renderOutliers(d.outliers);
  renderDanger(d.danger);
  renderResultsTable(d.results);
}

function renderRunHeader(run) {
  document.getElementById('run-set-name').textContent = run.set_name;
  document.getElementById('run-type').textContent = run.analysis_type;
  document.getElementById('run-date').textContent = run.run_date;
  document.getElementById('run-replicas').textContent = run.replicas;
  document.getElementById('run-threads').textContent = run.threads ?? '1';
  document.getElementById('run-version').textContent = run.chat_version_basis || '—';
  document.getElementById('run-feature').textContent = run.feature_name || '—';
}

function renderKpis(summary, run) {
  document.getElementById('kpi-count').textContent = String(summary.count || 0);
  document.getElementById('kpi-avg-score').textContent = summary.avg_score ?? '—';
  document.getElementById('kpi-avg-time').textContent = summary.avg_time ?? formatMs(run.avg_time_ms || 0);
  const invalidCount = summary.invalid_count ?? 0;
  document.getElementById('kpi-invalid').textContent = String(invalidCount);
}

function renderTrendChart(trend, trendSignificance) {
  const datasets = [{
    label: 'Avg score',
    data: trend.map(t => t.avg_score),
    borderColor: ACCENT,
    backgroundColor: ACCENT,
    tension: 0.25,
    pointRadius: 3,
  }];

  if (trendSignificance) {
    const { slope, intercept } = trendSignificance;
    datasets.push({
      label: 'Trend',
      data: trend.map((_, i) => intercept + slope * i),
      borderColor: MUTED,
      borderDash: [6, 4],
      pointRadius: 0,
      fill: false,
    });
  }

  if (trendChart) trendChart.destroy();
  trendChart = new Chart(document.getElementById('trend-chart'), {
    type: 'line',
    data: { labels: trend.map(t => t.run_date.slice(0, 10)), datasets },
    options: {
      plugins: { legend: { display: !!trendSignificance, position: 'bottom' } },
      scales: { y: { min: 0, max: 5, grid: { display: false } }, x: { grid: { display: false } } },
    },
  });

  if (!trendSignificance) {
    trendSignificanceCaption.textContent = trend.length < 3
      ? 'Not enough historical runs to test the trend (need at least 3).'
      : '';
  } else {
    const dir = trendSignificance.slope > 0 ? 'upward' : trendSignificance.slope < 0 ? 'downward' : 'flat';
    const verdict = trendSignificance.significant ? 'statistically significant' : 'not statistically significant';
    trendSignificanceCaption.textContent =
      `Trend: ${dir} (slope ${trendSignificance.slope.toFixed(3)}/run, r=${trendSignificance.r_value.toFixed(2)}, p=${trendSignificance.p_value.toFixed(3)}) — ${verdict}.`;
  }
}

function renderScoreDistChart(scoreDistribution, previousScoreDistribution) {
  const dist = scoreDistribution || {};
  const prevDist = previousScoreDistribution || {};
  const hasPrevious = Object.keys(prevDist).length > 0;

  const datasets = [{
    label: 'Current',
    data: [1,2,3,4,5].map(s => dist[s] || 0),
    backgroundColor: hasPrevious ? ACCENT : SCORE_COLORS.slice(1),
    borderRadius: 4,
  }];
  if (hasPrevious) {
    datasets.push({
      label: 'Previous',
      data: [1,2,3,4,5].map(s => prevDist[s] || 0),
      backgroundColor: MUTED,
      borderRadius: 4,
    });
  }

  if (scoreDistChart) scoreDistChart.destroy();
  scoreDistChart = new Chart(document.getElementById('score-dist-chart'), {
    type: 'bar',
    data: { labels: ['1','2','3','4','5'], datasets },
    options: {
      plugins: { legend: { display: hasPrevious, position: 'bottom' } },
      scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });
}

function renderMetricsChart(current, previous) {
  const fields = Object.keys(METRIC_LABELS).filter(f => current?.[f] != null || previous?.[f] != null);
  if (fields.length === 0) {
    metricsChartCard.classList.add('hidden');
    return;
  }
  metricsChartCard.classList.remove('hidden');
  if (metricsChart) metricsChart.destroy();
  metricsChart = new Chart(document.getElementById('metrics-chart'), {
    type: 'bar',
    data: {
      labels: fields.map(f => METRIC_LABELS[f]),
      datasets: [
        { label: 'Current', data: fields.map(f => current?.[f] ?? null), backgroundColor: ACCENT, borderRadius: 4 },
        { label: 'Previous', data: fields.map(f => previous?.[f] ?? null), backgroundColor: 'hsl(var(--muted-foreground))', borderRadius: 4 },
      ],
    },
    options: {
      indexAxis: 'y',
      plugins: { legend: { display: true, position: 'bottom' } },
      scales: { x: { min: 0, max: 1, grid: { display: false } }, y: { grid: { display: false } } },
    },
  });
}

function renderPerTopic(topicStats) {
  perTopicGrid.innerHTML = '';
  if (!topicStats || topicStats.length === 0) return;
  topicStats.forEach((ts, i) => {
    const color = ts.color || TOPIC_PALETTE[i % TOPIC_PALETTE.length];
    const avgScoreColor = ts.avg_score >= 4 ? '#16a34a' : ts.avg_score >= 3 ? '#ca8a04' : '#dc2626';
    const card = document.createElement('div');
    card.className = 'chart-card';
    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.5rem;">
        <div style="display:flex;align-items:center;gap:0.5rem;min-width:0;">
          <span style="width:0.625rem;height:0.625rem;border-radius:50%;background:${color};flex-shrink:0;display:inline-block;"></span>
          <span class="text-sm font-medium" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escHtml(ts.topic)}">${escHtml(ts.topic)}</span>
        </div>
        <div style="text-align:right;font-size:0.7rem;color:hsl(var(--muted-foreground));flex-shrink:0;">
          <div>${ts.count} run${ts.count !== 1 ? 's' : ''}</div>
          <div>avg ${ts.avg_time}</div>
        </div>
      </div>
      <p class="text-xs text-muted">Avg score: <span style="font-weight:600;color:${avgScoreColor}">${ts.avg_score}</span></p>
      <canvas id="deep-topic-chart-${i}" height="130" style="margin-top:0.5rem;"></canvas>`;
    perTopicGrid.appendChild(card);

    const canvasId = `deep-topic-chart-${i}`;
    if (perTopicCharts[canvasId]) perTopicCharts[canvasId].destroy();
    const scoreData = [1,2,3,4,5].map(s => (ts.score_distribution || {})[s] || 0);
    perTopicCharts[canvasId] = new Chart(document.getElementById(canvasId), {
      type: 'bar',
      data: { labels: ['1','2','3','4','5'], datasets: [{ data: scoreData, backgroundColor: SCORE_COLORS.slice(1), borderRadius: 3 }] },
      options: {
        plugins: { legend: { display: false } },
        scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 } } },
      },
    });
  });
}

function renderOutliers(outliers) {
  if (!outliers || outliers.length === 0) {
    outliersSection.classList.add('hidden');
    return;
  }
  outliersTbody.innerHTML = outliers.map(o => `
    <tr>
      <td class="truncate-cell"><span title="${escHtml(o.question)}">${escHtml(o.question)}</span></td>
      <td>${escHtml(o.topic || '')}</td>
      <td class="center">${o.replica}</td>
      <td>${o.metric === 'response_time_ms' ? 'Response time' : (METRIC_LABELS[o.metric] || escHtml(o.metric))}</td>
      <td class="right">${o.metric === 'response_time_ms' ? formatMs(o.value) : o.value}</td>
      <td class="right">${o.z_score}</td>
    </tr>`).join('');
  outliersSection.classList.remove('hidden');
}

function renderDanger(danger) {
  if (!danger || danger.length === 0) {
    dangerSection.classList.add('hidden');
    return;
  }
  dangerTbody.innerHTML = renderDangerRows(danger, true);
  dangerSection.classList.remove('hidden');
}

function renderResultsTable(results) {
  resultsTbody.innerHTML = results.map(r => `
    <tr>
      <td class="truncate-cell"><span title="${escHtml(r.question)}">${escHtml(r.question)}</span></td>
      <td>${escHtml(r.topic || '')}</td>
      <td class="center">${r.replica}</td>
      <td class="center">${r.score ?? 'NA'}</td>
      <td class="right">${formatMs(r.response_time_ms || 0)}</td>
      <td class="truncate-cell"><span title="${escHtml(r.reason)}">${escHtml(r.reason || '')}</span></td>
      <td class="right">${formatMetric(r.context_precision)}</td>
      <td class="right">${formatMetric(r.context_recall)}</td>
      <td class="right">${formatMetric(r.context_entities_recall)}</td>
      <td class="right">${formatMetric(r.noise_sensitivity)}</td>
      <td class="right">${formatMetric(r.response_relavancy)}</td>
      <td class="right">${formatMetric(r.faithfulness)}</td>
    </tr>`).join('');
}
