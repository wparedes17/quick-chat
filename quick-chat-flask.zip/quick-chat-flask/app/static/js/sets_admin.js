// Sets/TestSets admin UI — handles both the list page and the detail page.

function escHtml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data;
}

if (typeof window.__SET_ID__ === 'undefined') {
  // --- List page ---
  const setsTbody = document.getElementById('sets-tbody');
  const newSetName = document.getElementById('new-set-name');
  const newSetType = document.getElementById('new-set-type');
  const createSetBtn = document.getElementById('create-set-btn');
  const createSetError = document.getElementById('create-set-error');

  async function loadSets() {
    const sets = await api('/sets/api');
    setsTbody.innerHTML = sets.map(s => `
      <tr>
        <td><a href="/sets/${s.set_id}">${escHtml(s.set_name)}</a></td>
        <td class="center">${escHtml(s.set_type)}</td>
        <td class="center">${s.question_count}</td>
        <td class="center"><a href="/sets/${s.set_id}" class="btn btn-ghost btn-icon" title="Open">→</a></td>
      </tr>`).join('');
  }

  createSetBtn.addEventListener('click', async () => {
    createSetError.classList.add('hidden');
    try {
      await api('/sets', {
        method: 'POST',
        body: JSON.stringify({ set_name: newSetName.value, set_type: newSetType.value }),
      });
      newSetName.value = '';
      await loadSets();
    } catch (err) {
      createSetError.textContent = err.message;
      createSetError.classList.remove('hidden');
    }
  });

  loadSets();
} else {
  // --- Detail page ---
  const setId = window.__SET_ID__;
  const setNameInput = document.getElementById('set-name');
  const setTypeInput = document.getElementById('set-type');
  const saveSetBtn = document.getElementById('save-set-btn');
  const deleteSetBtn = document.getElementById('delete-set-btn');
  const setError = document.getElementById('set-error');
  const questionsTbody = document.getElementById('questions-tbody');
  const newQuestion = document.getElementById('new-question');
  const newTopic = document.getElementById('new-topic');
  const newCriteria = document.getElementById('new-criteria');
  const newLocation = document.getElementById('new-location');
  const addQuestionBtn = document.getElementById('add-question-btn');
  const questionError = document.getElementById('question-error');

  async function loadDetail() {
    const detail = await api(`/sets/${setId}/api`);
    setNameInput.value = detail.set_name;
    setTypeInput.value = detail.set_type;
    questionsTbody.innerHTML = detail.questions.map(q => `
      <tr data-question-id="${q.question_id}">
        <td class="truncate-cell">${escHtml(q.question)}</td>
        <td>${escHtml(q.topic)}</td>
        <td class="truncate-cell">${escHtml(q.criteria)}</td>
        <td class="center">${escHtml(q.location)}</td>
        <td class="center"><button class="btn btn-ghost btn-icon delete-question-btn" title="Delete">✕</button></td>
      </tr>`).join('');
    questionsTbody.querySelectorAll('.delete-question-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const questionId = e.target.closest('tr').dataset.questionId;
        await api(`/sets/${setId}/questions/${questionId}`, { method: 'DELETE' });
        await loadDetail();
      });
    });
  }

  saveSetBtn.addEventListener('click', async () => {
    setError.classList.add('hidden');
    try {
      await api(`/sets/${setId}`, {
        method: 'PUT',
        body: JSON.stringify({ set_name: setNameInput.value, set_type: setTypeInput.value }),
      });
      await loadDetail();
    } catch (err) {
      setError.textContent = err.message;
      setError.classList.remove('hidden');
    }
  });

  deleteSetBtn.addEventListener('click', async () => {
    if (!confirm('Delete this set and all its questions?')) return;
    await api(`/sets/${setId}`, { method: 'DELETE' });
    window.location.href = '/sets';
  });

  addQuestionBtn.addEventListener('click', async () => {
    questionError.classList.add('hidden');
    try {
      await api(`/sets/${setId}/questions`, {
        method: 'POST',
        body: JSON.stringify({
          question: newQuestion.value,
          topic: newTopic.value || null,
          criteria: newCriteria.value,
          location: newLocation.value,
        }),
      });
      newQuestion.value = '';
      newTopic.value = '';
      newCriteria.value = '';
      await loadDetail();
    } catch (err) {
      questionError.textContent = err.message;
      questionError.classList.remove('hidden');
    }
  });

  loadDetail();
}
