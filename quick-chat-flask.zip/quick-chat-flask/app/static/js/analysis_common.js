// Shared helpers for Multiple Analysis / Topic Analysis pages.

export function scoreClass(s) {
  if (s >= 4) return 'score-green';
  if (s === 3) return 'score-yellow';
  return 'score-red';
}

export function formatMs(ms) {
  return ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${Math.round(ms)}ms`;
}

export function escHtml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

export function formatMetric(v) {
  if (v == null) return 'NA';
  return Number.isInteger(v) ? String(v) : v.toFixed(2);
}

// Colored +/- diff, paired with a ▲/▼ glyph so the signal isn't color-only.
export function delta(current, previous, higherIsBetter = true) {
  if (previous == null || current == null) return '';
  const diff = current - previous;
  if (diff === 0) return '<span style="color:hsl(var(--muted-foreground))">→ no change</span>';
  const good = higherIsBetter ? diff > 0 : diff < 0;
  const sign = diff > 0 ? '+' : '';
  const glyph = diff > 0 ? '▲' : '▼';
  const color = good ? '#16a34a' : '#dc2626';
  const formatted = typeof current === 'number' && !Number.isInteger(current) ? diff.toFixed(2) : diff;
  return `<span style="color:${color};font-weight:600;">${glyph} ${sign}${formatted}</span>`;
}

export const METRIC_LABELS = {
  score: 'Score',
  context_precision: 'Context precision',
  context_recall: 'Context recall',
  context_entities_recall: 'Context entities recall',
  noise_sensitivity: 'Noise sensitivity',
  response_relavancy: 'Response relevancy',
  faithfulness: 'Faithfulness',
};

// Renders the "questions in danger" table body. `danger` is the list returned
// by build_danger_list: [{question, topic, regressions: {field: {previous, current, delta}}}].
// `includeTopicColumn` controls whether a Topic <td> is emitted (topic.html has one, multiple.html doesn't).
export function renderDangerRows(danger, includeTopicColumn) {
  const rows = [];
  for (const item of danger) {
    for (const [field, { previous, current }] of Object.entries(item.regressions)) {
      rows.push(`
        <tr>
          <td class="truncate-cell"><span title="${escHtml(item.question)}">${escHtml(item.question)}</span></td>
          ${includeTopicColumn ? `<td>${escHtml(item.topic || '')}</td>` : ''}
          <td>${METRIC_LABELS[field] || escHtml(field)}</td>
          <td class="right">${formatMetric(previous)}</td>
          <td class="right">${formatMetric(current)}</td>
          <td class="right">${delta(current, previous, true)}</td>
        </tr>`);
    }
  }
  return rows.join('');
}

// Renders the expandable per-row detail card. `entry` is one item from the
// `comparison` SSE event's `question_comparison` list (build_question_comparison):
// {question, topic, in_danger, metrics: {field: {current, previous, delta?}}}.
// Only metrics with a current or previous value are shown.
export function renderComparisonCard(entry) {
  const badge = entry.in_danger
    ? '<span style="color:#dc2626;font-weight:600;">⚠ In danger</span>'
    : '<span style="color:#16a34a;font-weight:600;">Stable or improved</span>';

  const tiles = Object.entries(entry.metrics)
    .filter(([, m]) => m.current != null || m.previous != null)
    .map(([field, m]) => `
      <div style="min-width:8rem;">
        <p class="text-xs text-muted" style="margin-bottom:0.125rem;">${METRIC_LABELS[field] || escHtml(field)}</p>
        <p class="text-sm">${formatMetric(m.previous)} &rarr; ${formatMetric(m.current)}
          ${'delta' in m ? delta(m.current, m.previous, true) : ''}</p>
      </div>`)
    .join('');

  return `
    <div class="card" style="padding:0.75rem 1rem;">
      <p style="margin-bottom:0.5rem;">${badge}</p>
      <div style="display:flex;flex-wrap:wrap;gap:1rem;">${tiles}</div>
    </div>`;
}

// Renders a compute_gain_significance() result (or null) as a compact inline badge.
export function renderSignificance(sig, label = 'Avg score gain') {
  if (!sig) {
    return `<span class="text-xs text-muted">${escHtml(label)}: not enough matched questions to test</span>`;
  }
  const sign = sig.mean_gain > 0 ? '+' : '';
  const color = sig.significant ? (sig.mean_gain > 0 ? '#16a34a' : '#dc2626') : 'hsl(var(--muted-foreground))';
  const verdict = sig.significant ? 'significant' : 'not significant';
  return `<span style="font-size:0.8rem;">
    <span class="text-xs text-muted">${escHtml(label)}:</span>
    <span style="color:${color};font-weight:600;">${sign}${sig.mean_gain.toFixed(2)}</span>
    <span class="text-xs text-muted">(95% CI [${sig.ci_low.toFixed(2)}, ${sig.ci_high.toFixed(2)}], p=${sig.p_value.toFixed(3)}, n=${sig.n}) — ${verdict}</span>
  </span>`;
}
