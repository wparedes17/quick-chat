// Shared helpers for Multiple Analysis / Topic Analysis pages.

export function scoreClass(s) {
  if (s >= 4) return 'score-green';
  if (s === 3) return 'score-yellow';
  return 'score-red';
}

export function formatMs(ms) {
  return ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${Math.round(ms)}ms`;
}

export function escHtml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

export function formatMetric(v) {
  if (v == null) return 'NA';
  return Number.isInteger(v) ? String(v) : v.toFixed(2);
}

// Colored +/- diff, paired with a ▲/▼ glyph so the signal isn't color-only.
export function delta(current, previous, higherIsBetter = true) {
  if (previous == null || current == null) return '';
  const diff = current - previous;
  if (diff === 0) return '<span style="color:hsl(var(--muted-foreground))">→ no change</span>';
  const good = higherIsBetter ? diff > 0 : diff < 0;
  const sign = diff > 0 ? '+' : '';
  const glyph = diff > 0 ? '▲' : '▼';
  const color = good ? '#16a34a' : '#dc2626';
  const formatted = typeof current === 'number' && !Number.isInteger(current) ? diff.toFixed(2) : diff;
  return `<span style="color:${color};font-weight:600;">${glyph} ${sign}${formatted}</span>`;
}

const METRIC_LABELS = {
  score: 'Score',
  context_precision: 'Context precision',
  context_recall: 'Context recall',
  context_entities_recall: 'Context entities recall',
  noise_sensitivity: 'Noise sensitivity',
  response_relavancy: 'Response relevancy',
  faithfulness: 'Faithfulness',
};

// Renders the "questions in danger" table body. `danger` is the list returned
// by build_danger_list: [{question, topic, regressions: {field: {previous, current, delta}}}].
// `includeTopicColumn` controls whether a Topic <td> is emitted (topic.html has one, multiple.html doesn't).
export function renderDangerRows(danger, includeTopicColumn) {
  const rows = [];
  for (const item of danger) {
    for (const [field, { previous, current }] of Object.entries(item.regressions)) {
      rows.push(`
        <tr>
          <td class="truncate-cell"><span title="${escHtml(item.question)}">${escHtml(item.question)}</span></td>
          ${includeTopicColumn ? `<td>${escHtml(item.topic || '')}</td>` : ''}
          <td>${METRIC_LABELS[field] || escHtml(field)}</td>
          <td class="right">${formatMetric(previous)}</td>
          <td class="right">${formatMetric(current)}</td>
          <td class="right">${delta(current, previous, true)}</td>
        </tr>`);
    }
  }
  return rows.join('');
}
