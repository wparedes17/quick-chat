// Multiple Analysis tab

import { scoreClass, formatMs, escHtml, formatMetric, delta, renderDangerRows } from './analysis_common.js';

const SCORE_COLORS = ['', '#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e'];

const setSelect = document.getElementById('set-select');
const parseError = document.getElementById('parse-error');
const replicasInput = document.getElementById('replicas');
const threadsInput = document.getElementById('threads');
const totalRunsLabel = document.getElementById('total-runs-label');
const runBtn = document.getElementById('run-btn');
const stopBtn = document.getElementById('stop-btn');
const progressArea = document.getElementById('progress-area');
const progressFill = document.getElementById('progress-fill');
const progressStatus = document.getElementById('progress-status');
const progressCount = document.getElementById('progress-count');
const resultsArea = document.getElementById('results-area');
const statCount = document.getElementById('stat-count');
const statAvgScore = document.getElementById('stat-avg-score');
const statAvgTime = document.getElementById('stat-avg-time');
const statInvalidCount = document.getElementById('stat-invalid-count');
const resultsTbody = document.getElementById('results-tbody');
const intentSection = document.getElementById('intent-section');
const dbComparisonSection = document.getElementById('db-comparison-section');
const dbComparisonContent = document.getElementById('db-comparison-content');
const dangerSection = document.getElementById('danger-section');
const dangerTbody = document.getElementById('danger-tbody');

let scoreChart = null;
let timeChart = null;
let intentChart = null;
let abortController = null;

async function loadSets() {
  try {
    const res = await fetch('/sets/api?type=multiple');
    const sets = await res.json();
    if (!res.ok) throw new Error(sets.error || 'Failed to load sets');
    setSelect.innerHTML = sets.map(s =>
      `<option value="${s.set_id}">${escHtml(s.set_name)} (${s.question_count})</option>`
    ).join('');
    runBtn.disabled = sets.length === 0;
    if (sets.length === 0) {
      parseError.textContent = 'No sets available. Create one under Manage sets.';
      parseError.classList.remove('hidden');
    }
    updateTotalRuns();
  } catch (err) {
    parseError.textContent = err.message;
    parseError.classList.remove('hidden');
  }
}

replicasInput.addEventListener('input', updateTotalRuns);

function updateTotalRuns() {
  const selectedOption = setSelect.options[setSelect.selectedIndex];
  if (!selectedOption) return;
  const questionCount = parseInt(selectedOption.textContent.match(/\((\d+)\)$/)?.[1] ?? '0');
  const replicas = Math.max(1, parseInt(replicasInput.value) || 1);
  totalRunsLabel.textContent = `= ${questionCount * replicas} total run${questionCount * replicas !== 1 ? 's' : ''}`;
  totalRunsLabel.classList.remove('hidden');
}

loadSets();

stopBtn.addEventListener('click', () => {
  abortController?.abort();
});

runBtn.addEventListener('click', async () => {
  if (!setSelect.value) return;

  const location = document.getElementById('location-select').value;
  const replicas = Math.max(1, Math.min(20, parseInt(replicasInput.value) || 1));

  runBtn.classList.add('hidden');
  stopBtn.classList.remove('hidden');
  progressArea.classList.remove('hidden');
  progressFill.style.width = '0%';
  progressStatus.textContent = 'Running…';
  resultsTbody.innerHTML = '';
  resultsArea.classList.add('hidden');
  intentSection.classList.add('hidden');
  dbComparisonSection.classList.add('hidden');
  dangerSection.classList.add('hidden');

  const threads = Math.max(1, Math.min(10, parseInt(threadsInput.value) || 1));

  const formData = new FormData();
  formData.append('set_id', setSelect.value);
  formData.append('location', location);
  formData.append('replicas', String(replicas));
  formData.append('threads', String(threads));
  formData.append('feature_name', document.getElementById('feature-name').value.trim());
  formData.append('base_url', document.getElementById('scoring-url-input').value.trim());

  abortController = new AbortController();
  const results = [];
  let completed = 0;
  let totalCount = 0;
  let statsData = null;
  let comparisonData = null;

  try {
    const res = await fetch('/evaluation/multiple/run', {
      method: 'POST',
      body: formData,
      signal: abortController.signal,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || `Failed: ${res.status}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop() ?? '';
      for (const line of lines) {
        const dataPart = line.replace(/^data: /, '').trim();
        if (!dataPart || dataPart === '[DONE]') continue;
        try {
          const ev = JSON.parse(dataPart);
          if (ev.type === 'meta') {
            totalCount = ev.data.total_count;
          } else if (ev.type === 'result') {
            results.push(ev.data);
            completed++;
            appendRow(ev.data);
            progressCount.textContent = totalCount ? `${completed} / ${totalCount}` : `${completed} / ?`;
            progressFill.style.width = totalCount ? `${Math.round((completed / totalCount) * 100)}%` : '100%';
          } else if (ev.type === 'stats') {
            statsData = ev.data;
          } else if (ev.type === 'comparison') {
            comparisonData = ev.data;
          }
        } catch {}
      }
    }
  } catch (err) {
    if (err.name !== 'AbortError') {
      parseError.textContent = err.message;
      parseError.classList.remove('hidden');
    }
    progressStatus.textContent = 'Stopped';
  } finally {
    abortController = null;
    stopBtn.classList.add('hidden');
    runBtn.classList.remove('hidden');
  }

  if (results.length > 0) {
    progressStatus.textContent = 'Completed';
    progressCount.textContent = `${results.length} / ${results.length}`;
    progressFill.style.width = '100%';
    showResults(results, statsData);
    if (comparisonData) renderComparison(comparisonData, statsData);
  }
});

function appendRow(r) {
  const cls = scoreClass(r.score);
  const tr = document.createElement('tr');
  if (r.is_invalid) tr.style.opacity = '0.75';
  tr.innerHTML = `
    <td class="truncate-cell"><span title="${escHtml(r.question)}">${escHtml(r.question)}</span></td>
    <td class="center">${r.replica}</td>
    <td class="center"><span class="score-badge ${cls}">${r.is_invalid ? '⚠' : r.score}</span></td>
    <td class="right">${formatMs(r.response_time_ms)}</td>
    <td class="truncate-cell"><span title="${escHtml(r.reason)}">${escHtml(r.is_invalid ? '[INVALID_INPUT] ' + r.reason : r.reason)}</span></td>
    <td class="right">${formatMetric(r.context_precision)}</td>
    <td class="right">${formatMetric(r.context_recall)}</td>
    <td class="right">${formatMetric(r.context_entities_recall)}</td>
    <td class="right">${formatMetric(r.noise_sensitivity)}</td>
    <td class="right">${formatMetric(r.response_relavancy)}</td>
    <td class="right">${formatMetric(r.faithfulness)}</td>`;
  resultsTbody.appendChild(tr);
  resultsArea.classList.remove('hidden');
}

function showResults(results, stats) {
  statCount.textContent = String(results.length);
  statAvgScore.textContent = stats?.avg_score ?? '—';
  statAvgTime.textContent = stats?.avg_time ?? '—';

  const invalidCount = stats?.invalid_count ?? 0;
  const invalidRate = stats?.invalid_rate ?? 0;
  statInvalidCount.textContent = invalidCount > 0
    ? `${invalidCount} (${(invalidRate * 100).toFixed(1)}%)`
    : '0';

  const scoreData = [1,2,3,4,5].map(s => results.filter(r => r.score === s).length);
  if (scoreChart) scoreChart.destroy();
  scoreChart = new Chart(document.getElementById('score-chart'), {
    type: 'bar',
    data: {
      labels: ['1','2','3','4','5'],
      datasets: [{ data: scoreData, backgroundColor: SCORE_COLORS.slice(1), borderRadius: 4 }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });

  const times = results.map(r => r.response_time_ms);
  const hist = buildHistogram(times);
  if (timeChart) timeChart.destroy();
  timeChart = new Chart(document.getElementById('time-chart'), {
    type: 'bar',
    data: {
      labels: hist.map(b => b.label),
      datasets: [{ data: hist.map(b => b.count), backgroundColor: '#6366f1', borderRadius: 4 }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });

  const intentStats = stats?.intent_stats ?? {};
  const intentEntries = Object.entries(intentStats);
  if (intentEntries.length > 0) {
    intentSection.classList.remove('hidden');
    const labels = intentEntries.map(([k]) => k);
    const counts = intentEntries.map(([, v]) => v);
    if (intentChart) intentChart.destroy();
    intentChart = new Chart(document.getElementById('intent-chart'), {
      type: 'bar',
      data: {
        labels,
        datasets: [{ data: counts, backgroundColor: '#6366f1', borderRadius: 4 }],
      },
      options: {
        indexAxis: 'y',
        plugins: { legend: { display: false } },
        scales: {
          x: { beginAtZero: true, ticks: { precision: 0 }, grid: { display: false } },
          y: { grid: { display: false } },
        },
      },
    });
  }
}

function renderComparison(prev, current) {
  if (!prev) return;
  const currentAvgScore = current?.avg_score ?? null;
  const currentInvalid = current?.invalid_count ?? null;

  dbComparisonContent.innerHTML = `
    <div>
      <span class="text-xs text-muted">Run date</span>
      <div class="text-sm" style="font-weight:500;">${escHtml(prev.run_date)}</div>
    </div>
    <div>
      <span class="text-xs text-muted">Avg score</span>
      <div class="text-sm">${prev.avg_score ?? '—'} ${delta(currentAvgScore, prev.avg_score, true)}</div>
    </div>
    <div>
      <span class="text-xs text-muted">INVALID responses</span>
      <div class="text-sm">${prev.invalid_count} ${delta(currentInvalid, prev.invalid_count, false)}</div>
    </div>
    <div>
      <span class="text-xs text-muted">Total runs</span>
      <div class="text-sm">${prev.total_count}</div>
    </div>`;
  dbComparisonSection.classList.remove('hidden');

  const danger = prev.danger || [];
  if (danger.length > 0) {
    dangerTbody.innerHTML = renderDangerRows(danger, false);
    dangerSection.classList.remove('hidden');
  }
}

function buildHistogram(times, numBuckets = 8) {
  if (!times.length) return [];
  const lo = Math.min(...times), hi = Math.max(...times);
  if (lo === hi) return [{ label: formatMs(lo), count: times.length }];
  const w = (hi - lo) / numBuckets;
  return Array.from({ length: numBuckets }, (_, i) => {
    const blo = lo + i * w, bhi = blo + w;
    return {
      label: formatMs(blo),
      count: times.filter(t => i === numBuckets - 1 ? t <= bhi : t >= blo && t < bhi).length,
    };
  });
}
