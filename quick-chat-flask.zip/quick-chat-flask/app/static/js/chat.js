// Chat tab — streaming and non-streaming modes

const randomId = () => crypto.randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now().toString(36);
const escHtml = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const parseIntents = s => (!s || typeof s !== 'string') ? [] : s.split(',').map(x=>x.trim()).filter(Boolean);

// Module-level state
let loading = false;
let abortController = null;
let messageCount = 0;
let sessionId = sessionStorage.getItem('session_id') || randomId();
let userId = randomId();

const messagesArea = document.getElementById('messages-area');
const messagesList = document.getElementById('messages-list');
const emptyState = document.getElementById('empty-state');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');
const clearBtn = document.getElementById('clear-chat-btn');

// Auto-resize textarea
chatInput.addEventListener('input', function() {
  this.style.height = 'auto';
  this.style.height = Math.min(this.scrollHeight, 160) + 'px';
  sendBtn.disabled = !this.value.trim() || loading;
});

chatInput.addEventListener('keydown', function(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!sendBtn.disabled) send();
  }
});

sendBtn.addEventListener('click', send);

clearBtn.addEventListener('click', () => {
  abortController?.abort();
  abortController = null;
  loading = false;
  messagesList.innerHTML = '';
  messageCount = 0;
  messagesList.classList.add('hidden');
  emptyState.classList.remove('hidden');
  clearBtn.disabled = true;
  sessionId = randomId();
  userId = randomId();
  sessionStorage.setItem('session_id', sessionId);
  document.getElementById('session-display').textContent = 'session: ' + sessionId.slice(0, 8);
});

function scoreBubbleClass(score) {
  if (score >= 4) return 'score-green';
  if (score === 3) return 'score-yellow';
  return 'score-red';
}

function appendMessage(role, content, pending) {
  const id = 'msg-' + randomId();
  const isUser = role === 'user';
  const avatarClass = isUser ? 'user' : 'bot';
  const bubbleClass = isUser ? 'user' : 'bot';
  const avatarSvg = isUser
    ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>'
    : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>';

  const bubbleContent = pending
    ? '<span class="typing-dots"><span class="dot"></span><span class="dot"></span><span class="dot"></span></span>'
    : (isUser ? `<p style="white-space:pre-wrap;word-break:break-words;">${escHtml(content)}</p>` : marked.parse(content));

  const el = document.createElement('div');
  el.className = 'msg-row' + (isUser ? ' user' : '');
  el.id = id;
  el.innerHTML = `
    <div class="msg-avatar ${avatarClass}">${avatarSvg}</div>
    <div class="msg-body">
      <div class="msg-bubble ${bubbleClass}" data-bubble>${bubbleContent}</div>
      <div class="intent-tags" data-intents></div>
      <div class="rewritten-question" data-rewritten></div>
    </div>`;

  if (messagesList.classList.contains('hidden')) {
    emptyState.classList.add('hidden');
    messagesList.classList.remove('hidden');
  }
  messagesList.appendChild(el);
  messageCount++;
  clearBtn.disabled = false;
  scrollToBottom();
  return id;
}

function updateMessage(id, { content, intents, rewrittenQuestion, pending }) {
  const el = document.getElementById(id);
  if (!el) return;
  const bubble = el.querySelector('[data-bubble]');
  const intentContainer = el.querySelector('[data-intents]');
  const rewrittenContainer = el.querySelector('[data-rewritten]');

  if (content !== undefined) {
    bubble.innerHTML = marked.parse(content);
  }
  if (pending === false && !content && bubble.querySelector('.typing-dots')) {
    bubble.innerHTML = '';
  }
  if (intents && intents.length > 0) {
    intentContainer.innerHTML = intents.map(t =>
      `<span class="intent-tag">${escHtml(t)}</span>`
    ).join('');
  }
  if (rewrittenQuestion) {
    rewrittenContainer.innerHTML = `<span class="rewritten-tag"><span class="rewritten-label">Rewritten:</span> ${escHtml(rewrittenQuestion)}</span>`;
  }
  scrollToBottom();
}

function scrollToBottom() {
  messagesArea.scrollTop = messagesArea.scrollHeight;
}

async function send() {
  const question = chatInput.value.trim();
  if (!question || loading) return;

  const streaming = document.getElementById('stream-toggle').checked;
  const location = document.getElementById('location-select').value;

  appendMessage('user', question, false);
  const assistantId = appendMessage('assistant', '', true);

  chatInput.value = '';
  chatInput.style.height = 'auto';
  sendBtn.disabled = true;
  loading = true;

  const controller = new AbortController();
  abortController = controller;

  const baseUrl = document.getElementById('scoring-url-input').value.trim();
  const body = { question, location, session_id: sessionId, user_id: userId, base_url: baseUrl };

  try {
    if (streaming) {
      await sendStream(body, assistantId, controller.signal);
    } else {
      const res = await fetch('/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      if (!res.ok) throw new Error(`Request failed: ${res.status}`);
      const data = await res.json();
      updateMessage(assistantId, { content: data.answer, intents: data.intents, rewrittenQuestion: data.rewritten_question, pending: false });
    }
  } catch (err) {
    if (err.name !== 'AbortError') {
      updateMessage(assistantId, { content: `⚠️ ${err.message}`, pending: false });
    }
  } finally {
    loading = false;
    abortController = null;
    sendBtn.disabled = !chatInput.value.trim();
  }
}

async function sendStream(body, assistantId, signal) {
  const res = await fetch('/ask/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal,
  });
  if (!res.ok || !res.body) throw new Error(`Stream failed: ${res.status}`);

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let fullContent = '';

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n\n');
    buffer = lines.pop() ?? '';
    for (const line of lines) {
      const dataPart = line.replace(/^data: /, '').trim();
      if (!dataPart || dataPart === '[DONE]') continue;
      try {
        const parsed = JSON.parse(dataPart);
        if (parsed.chunk) {
          fullContent += parsed.chunk;
          updateMessage(assistantId, { content: fullContent });
        } else if (parsed.intents) {
          updateMessage(assistantId, { intents: parsed.intents });
        }
      } catch {}
    }
  }
}
