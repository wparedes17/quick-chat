// Topic Analysis tab

import { scoreClass, formatMs, escHtml, formatMetric, delta, renderDangerRows } from './analysis_common.js';

const SCORE_COLORS = ['', '#ef4444', '#f97316', '#eab308', '#84cc16', '#22c55e'];
const TOPIC_PALETTE = ['#6366f1','#f59e0b','#10b981','#ef4444','#3b82f6','#8b5cf6','#f97316','#06b6d4','#ec4899','#14b8a6'];

const setSelect = document.getElementById('set-select');
const parseError = document.getElementById('parse-error');
const replicasInput = document.getElementById('replicas');
const threadsInput = document.getElementById('threads');
const totalRunsLabel = document.getElementById('total-runs-label');
const runBtn = document.getElementById('run-btn');
const stopBtn = document.getElementById('stop-btn');
const progressArea = document.getElementById('progress-area');
const progressFill = document.getElementById('progress-fill');
const progressStatus = document.getElementById('progress-status');
const progressCount = document.getElementById('progress-count');
const resultsArea = document.getElementById('results-area');
const statCount = document.getElementById('stat-count');
const statAvgScore = document.getElementById('stat-avg-score');
const statAvgTime = document.getElementById('stat-avg-time');
const statInvalidCount = document.getElementById('stat-invalid-count');
const resultsTbody = document.getElementById('results-tbody');
const comparisonCharts = document.getElementById('comparison-charts');
const perTopicGrid = document.getElementById('per-topic-grid');
const intentSection = document.getElementById('intent-section');
const dbComparisonSection = document.getElementById('db-comparison-section');
const dbComparisonContent = document.getElementById('db-comparison-content');
const dangerSection = document.getElementById('danger-section');
const dangerTbody = document.getElementById('danger-tbody');

let abortController = null;
let topicScoreChart = null;
let topicTimeChart = null;
let intentChart = null;
const perTopicCharts = {};

async function loadSets() {
  try {
    const res = await fetch('/sets/api?type=topic');
    const sets = await res.json();
    if (!res.ok) throw new Error(sets.error || 'Failed to load sets');
    setSelect.innerHTML = sets.map(s =>
      `<option value="${s.set_id}">${escHtml(s.set_name)} (${s.question_count})</option>`
    ).join('');
    runBtn.disabled = sets.length === 0;
    if (sets.length === 0) {
      parseError.textContent = 'No sets available. Create one under Manage sets.';
      parseError.classList.remove('hidden');
    }
    updateTotalRuns();
  } catch (err) {
    parseError.textContent = err.message;
    parseError.classList.remove('hidden');
  }
}

replicasInput.addEventListener('input', updateTotalRuns);
function updateTotalRuns() {
  const selectedOption = setSelect.options[setSelect.selectedIndex];
  if (!selectedOption) return;
  const questionCount = parseInt(selectedOption.textContent.match(/\((\d+)\)$/)?.[1] ?? '0');
  const r = Math.max(1, parseInt(replicasInput.value) || 1);
  totalRunsLabel.textContent = `= ${questionCount * r} total run${questionCount * r !== 1 ? 's' : ''}`;
  totalRunsLabel.classList.remove('hidden');
}

loadSets();

stopBtn.addEventListener('click', () => abortController?.abort());

runBtn.addEventListener('click', async () => {
  if (!setSelect.value) return;
  const location = document.getElementById('location-select').value;
  const replicas = Math.max(1, Math.min(20, parseInt(replicasInput.value) || 1));

  runBtn.classList.add('hidden');
  stopBtn.classList.remove('hidden');
  progressArea.classList.remove('hidden');
  progressFill.style.width = '0%';
  progressStatus.textContent = 'Running…';
  resultsTbody.innerHTML = '';
  resultsArea.classList.add('hidden');
  comparisonCharts.classList.add('hidden');
  intentSection.classList.add('hidden');
  dbComparisonSection.classList.add('hidden');
  dangerSection.classList.add('hidden');
  perTopicGrid.innerHTML = '';

  const threads = Math.max(1, Math.min(10, parseInt(threadsInput.value) || 1));

  const formData = new FormData();
  formData.append('set_id', setSelect.value);
  formData.append('location', location);
  formData.append('replicas', String(replicas));
  formData.append('threads', String(threads));
  formData.append('feature_name', document.getElementById('feature-name').value.trim());
  formData.append('base_url', document.getElementById('scoring-url-input').value.trim());

  abortController = new AbortController();
  const results = [];
  let totalCount = 0;
  let topicStats = null;
  let summaryData = null;
  let comparisonData = null;

  try {
    const res = await fetch('/evaluation/topic/run', {
      method: 'POST',
      body: formData,
      signal: abortController.signal,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || `Failed: ${res.status}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop() ?? '';
      for (const line of lines) {
        const dataPart = line.replace(/^data: /, '').trim();
        if (!dataPart || dataPart === '[DONE]') continue;
        try {
          const ev = JSON.parse(dataPart);
          if (ev.type === 'meta') {
            totalCount = ev.data.total_count;
          } else if (ev.type === 'result') {
            results.push(ev.data);
            appendRow(ev.data);
            progressCount.textContent = totalCount ? `${results.length} / ${totalCount}` : `${results.length} / ?`;
            progressFill.style.width = totalCount ? `${Math.round((results.length / totalCount) * 100)}%` : '100%';
          } else if (ev.type === 'stats') {
            topicStats = ev.topic_stats;
            summaryData = ev.data;
            showSummary(ev.data);
          } else if (ev.type === 'comparison') {
            comparisonData = ev.data;
          }
        } catch {}
      }
    }
  } catch (err) {
    if (err.name !== 'AbortError') {
      parseError.textContent = err.message;
      parseError.classList.remove('hidden');
    }
    progressStatus.textContent = 'Stopped';
  } finally {
    abortController = null;
    stopBtn.classList.add('hidden');
    runBtn.classList.remove('hidden');
  }

  if (results.length > 0) {
    progressStatus.textContent = 'Completed';
    progressCount.textContent = `${results.length} / ${results.length}`;
    progressFill.style.width = '100%';
    resultsArea.classList.remove('hidden');
    if (topicStats && topicStats.length > 1) renderComparisonCharts(topicStats);
    if (topicStats) renderPerTopicCharts(topicStats);
    renderIntentChart(summaryData?.intent_stats ?? {});
    if (comparisonData) renderDbComparison(comparisonData, summaryData);
  }
});

function appendRow(r) {
  const cls = scoreClass(r.score);
  const tr = document.createElement('tr');
  if (r.is_invalid) tr.style.opacity = '0.75';
  tr.innerHTML = `
    <td class="truncate-cell"><span title="${escHtml(r.question)}">${escHtml(r.question)}</span></td>
    <td class="truncate-cell">
      <span style="display:flex;align-items:center;gap:0.375rem;" title="${escHtml(r.topic||'')}">
        <span class="topic-dot" data-topic="${escHtml(r.topic||'')}"></span>${escHtml(r.topic||'')}
      </span>
    </td>
    <td class="center">${r.replica}</td>
    <td class="center"><span class="score-badge ${cls}">${r.is_invalid ? '⚠' : r.score}</span></td>
    <td class="right">${formatMs(r.response_time_ms)}</td>
    <td class="truncate-cell"><span title="${escHtml(r.reason)}">${escHtml(r.is_invalid ? '[INVALID_INPUT] ' + r.reason : r.reason)}</span></td>
    <td class="right">${formatMetric(r.context_precision)}</td>
    <td class="right">${formatMetric(r.context_recall)}</td>
    <td class="right">${formatMetric(r.context_entities_recall)}</td>
    <td class="right">${formatMetric(r.noise_sensitivity)}</td>
    <td class="right">${formatMetric(r.response_relavancy)}</td>
    <td class="right">${formatMetric(r.faithfulness)}</td>`;
  resultsTbody.appendChild(tr);
  resultsArea.classList.remove('hidden');
}

function showSummary(stats) {
  statCount.textContent = String(stats.count || 0);
  statAvgScore.textContent = stats.avg_score ?? '—';
  statAvgTime.textContent = stats.avg_time ?? '—';
  const invalidCount = stats.invalid_count ?? 0;
  const invalidRate = stats.invalid_rate ?? 0;
  statInvalidCount.textContent = invalidCount > 0
    ? `${invalidCount} (${(invalidRate * 100).toFixed(1)}%)`
    : '0';
}

function renderIntentChart(intentStats) {
  const entries = Object.entries(intentStats);
  if (!entries.length) return;
  intentSection.classList.remove('hidden');
  const labels = entries.map(([k]) => k);
  const counts = entries.map(([, v]) => v);
  if (intentChart) intentChart.destroy();
  intentChart = new Chart(document.getElementById('intent-chart'), {
    type: 'bar',
    data: {
      labels,
      datasets: [{ data: counts, backgroundColor: '#6366f1', borderRadius: 4 }],
    },
    options: {
      indexAxis: 'y',
      plugins: { legend: { display: false } },
      scales: {
        x: { beginAtZero: true, ticks: { precision: 0 }, grid: { display: false } },
        y: { grid: { display: false } },
      },
    },
  });
}

function renderDbComparison(prev, current) {
  if (!prev) return;
  dbComparisonContent.innerHTML = `
    <div>
      <span class="text-xs text-muted">Run date</span>
      <div class="text-sm" style="font-weight:500;">${escHtml(prev.run_date)}</div>
    </div>
    <div>
      <span class="text-xs text-muted">Avg score</span>
      <div class="text-sm">${prev.avg_score ?? '—'} ${delta(current?.avg_score ?? null, prev.avg_score, true)}</div>
    </div>
    <div>
      <span class="text-xs text-muted">INVALID responses</span>
      <div class="text-sm">${prev.invalid_count} ${delta(current?.invalid_count ?? null, prev.invalid_count, false)}</div>
    </div>
    <div>
      <span class="text-xs text-muted">Total runs</span>
      <div class="text-sm">${prev.total_count}</div>
    </div>`;
  dbComparisonSection.classList.remove('hidden');

  const danger = prev.danger || [];
  if (danger.length > 0) {
    dangerTbody.innerHTML = renderDangerRows(danger, true);
    dangerSection.classList.remove('hidden');
  }
}

function renderComparisonCharts(topicStats) {
  comparisonCharts.classList.remove('hidden');

  const labels = topicStats.map(t => t.topic.length > 18 ? t.topic.slice(0,16) + '…' : t.topic);
  const colors = topicStats.map(t => t.color);

  if (topicScoreChart) topicScoreChart.destroy();
  topicScoreChart = new Chart(document.getElementById('topic-score-chart'), {
    type: 'bar',
    data: {
      labels,
      datasets: [{ data: topicStats.map(t => t.avg_score), backgroundColor: colors, borderRadius: [0,4,4,0] }],
    },
    options: {
      indexAxis: 'y',
      plugins: { legend: { display: false } },
      scales: { x: { max: 5, grid: { display: false } }, y: { grid: { display: false } } },
    },
  });

  if (topicTimeChart) topicTimeChart.destroy();
  topicTimeChart = new Chart(document.getElementById('topic-time-chart'), {
    type: 'bar',
    data: {
      labels,
      datasets: [{ data: topicStats.map(t => t.avg_time_ms), backgroundColor: colors, borderRadius: [0,4,4,0] }],
    },
    options: {
      indexAxis: 'y',
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false }, ticks: { callback: v => formatMs(v) } },
        y: { grid: { display: false } },
      },
    },
  });

  // Color the topic dots in the table
  document.querySelectorAll('[data-topic]').forEach(dot => {
    const topic = dot.dataset.topic;
    const idx = topicStats.findIndex(t => t.topic === topic);
    if (idx >= 0) dot.style.backgroundColor = topicStats[idx].color;
  });
}

function renderPerTopicCharts(topicStats) {
  perTopicGrid.innerHTML = '';
  topicStats.forEach(ts => {
    const avgScoreColor = ts.avg_score >= 4 ? '#16a34a' : ts.avg_score >= 3 ? '#ca8a04' : '#dc2626';
    const intentEntries = Object.entries(ts.intent_stats || {}).slice(0, 5);
    const intentHtml = intentEntries.length
      ? `<div style="margin-top:0.5rem;">
           <p class="text-xs text-muted" style="margin-bottom:0.25rem;">Top intents</p>
           <ol style="margin:0;padding-left:1rem;font-size:0.72rem;color:hsl(var(--foreground));">
             ${intentEntries.map(([k, v]) => `<li>${escHtml(k)} <span style="color:hsl(var(--muted-foreground));">(${v})</span></li>`).join('')}
           </ol>
         </div>`
      : '';
    const invalidLine = ts.invalid_count > 0
      ? `<p class="text-xs" style="color:#ef4444;margin-top:0.25rem;">INVALID: ${ts.invalid_count}</p>`
      : '';
    const card = document.createElement('div');
    card.className = 'chart-card';
    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:0.5rem;">
        <div style="display:flex;align-items:center;gap:0.5rem;min-width:0;">
          <span style="width:0.625rem;height:0.625rem;border-radius:50%;background:${ts.color};flex-shrink:0;display:inline-block;"></span>
          <span class="text-sm font-medium" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escHtml(ts.topic)}">${escHtml(ts.topic)}</span>
        </div>
        <div style="text-align:right;font-size:0.7rem;color:hsl(var(--muted-foreground));flex-shrink:0;">
          <div>${ts.count} run${ts.count !== 1 ? 's' : ''}</div>
          <div>avg ${ts.avg_time}</div>
        </div>
      </div>
      <p class="text-xs text-muted">Avg score: <span style="font-weight:600;color:${avgScoreColor}">${ts.avg_score}</span></p>
      ${invalidLine}
      <canvas id="chart-${escHtml(ts.topic.replace(/\s+/g,'_'))}" height="130" style="margin-top:0.5rem;"></canvas>
      ${intentHtml}`;
    perTopicGrid.appendChild(card);

    const canvasId = `chart-${ts.topic.replace(/\s+/g,'_')}`;
    if (perTopicCharts[canvasId]) perTopicCharts[canvasId].destroy();
    const scoreData = [1,2,3,4,5].map(s => (ts.score_distribution || {})[s] || 0);
    perTopicCharts[canvasId] = new Chart(document.getElementById(canvasId), {
      type: 'bar',
      data: {
        labels: ['1','2','3','4','5'],
        datasets: [{ data: scoreData, backgroundColor: SCORE_COLORS.slice(1), borderRadius: 3 }],
      },
      options: {
        plugins: { legend: { display: false } },
        scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 } } },
      },
    });
  });
}
