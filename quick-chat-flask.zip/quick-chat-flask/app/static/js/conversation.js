// Conversation Evaluation tab

const initialQuestion = document.getElementById('initial-question');
const numTurnsInput = document.getElementById('num-turns');
const turnsHint = document.getElementById('turns-hint');
const startBtn = document.getElementById('start-btn');
const stopBtn = document.getElementById('stop-btn');
const progressArea = document.getElementById('progress-area');
const progressFill = document.getElementById('progress-fill');
const progressStatus = document.getElementById('progress-status');
const progressCount = document.getElementById('progress-count');
const errorBanner = document.getElementById('error-banner');
const transcriptArea = document.getElementById('transcript-area');
const transcript = document.getElementById('transcript');
const postRunActions = document.getElementById('post-run-actions');
const copyBtn = document.getElementById('copy-btn');
const evalCriteria = document.getElementById('eval-criteria');
const evalBtn = document.getElementById('eval-btn');
const evalResult = document.getElementById('eval-result');
const evalScoreBadge = document.getElementById('eval-score-badge');
const evalReason = document.getElementById('eval-reason');

let abortController = null;
let turns = [];   // accumulated turn objects

function scoreClass(s) { return s >= 4 ? 'score-green' : s === 3 ? 'score-yellow' : 'score-red'; }
function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

numTurnsInput.addEventListener('input', () => {
  const n = Math.max(1, Math.min(10, parseInt(numTurnsInput.value) || 1));
  const followUps = Math.max(0, n - 1);
  turnsHint.textContent = `1 initial + ${followUps} follow-up${n > 2 ? 's' : ''}`;
});

stopBtn.addEventListener('click', () => abortController?.abort());

startBtn.addEventListener('click', async () => {
  const question = initialQuestion.value.trim();
  if (!question) return;

  const location = document.getElementById('location-select').value;
  const numTurns = Math.max(1, Math.min(10, parseInt(numTurnsInput.value) || 2));

  startBtn.classList.add('hidden');
  stopBtn.classList.remove('hidden');
  progressArea.classList.remove('hidden');
  progressFill.style.width = '0%';
  progressStatus.textContent = '';
  progressCount.textContent = `0 / ${numTurns}`;
  errorBanner.classList.add('hidden');
  transcriptArea.classList.add('hidden');
  transcript.innerHTML = '';
  postRunActions.classList.add('hidden');
  evalResult.style.display = 'none';
  turns = [];

  abortController = new AbortController();

  try {
    const res = await fetch('/conversation/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ initial_question: question, num_turns: numTurns, location }),
      signal: abortController.signal,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || `Failed: ${res.status}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop() ?? '';
      for (const line of lines) {
        const dataPart = line.replace(/^data: /, '').trim();
        if (!dataPart || dataPart === '[DONE]') continue;
        try {
          const ev = JSON.parse(dataPart);
          if (ev.type === 'turn') {
            turns.push(ev.data);
            appendTurn(ev.data);
            progressFill.style.width = `${(turns.length / numTurns) * 100}%`;
            progressCount.textContent = `${turns.length} / ${numTurns}`;
          } else if (ev.type === 'status') {
            progressStatus.textContent = ev.message;
          } else if (ev.type === 'error') {
            throw new Error(ev.message);
          }
        } catch (parseErr) {
          if (parseErr.message && parseErr.message !== 'Unexpected token') {
            throw parseErr;
          }
        }
      }
    }
    progressStatus.textContent = 'Completed';
  } catch (err) {
    if (err.name === 'AbortError') {
      progressStatus.textContent = 'Stopped';
    } else {
      errorBanner.textContent = err.message;
      errorBanner.classList.remove('hidden');
    }
  } finally {
    abortController = null;
    stopBtn.classList.add('hidden');
    startBtn.classList.remove('hidden');
    if (turns.length > 0) postRunActions.classList.remove('hidden');
  }
});

function appendTurn(turn) {
  const userDiv = document.createElement('div');
  userDiv.className = 'turn-user';
  userDiv.innerHTML = `<span class="turn-label-user">User</span><p class="turn-text">${escHtml(turn.user_message)}</p>`;

  const botDiv = document.createElement('div');
  botDiv.className = 'turn-bot';
  botDiv.innerHTML = `<span class="turn-label-bot">System</span><p class="turn-text">${escHtml(turn.system_response)}</p>`;

  transcript.appendChild(userDiv);
  transcript.appendChild(botDiv);
  transcriptArea.classList.remove('hidden');
  transcript.scrollTop = transcript.scrollHeight;
}

copyBtn.addEventListener('click', () => {
  const text = turns.flatMap(t => [`USER: ${t.user_message}`, `SYSTEM: ${t.system_response}`]).join('\n\n');
  navigator.clipboard.writeText(text).then(() => {
    copyBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#16a34a" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Copied!`;
    setTimeout(() => {
      copyBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy as Script`;
    }, 2000);
  });
});

evalBtn.addEventListener('click', async () => {
  if (!turns.length) return;
  const criteria = evalCriteria.value.trim();
  if (!criteria) return;

  evalBtn.disabled = true;
  evalBtn.innerHTML = '<span class="spinner"></span> Evaluating…';

  try {
    const res = await fetch('/conversation/evaluate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ turns, criteria }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || `Failed: ${res.status}`);
    }
    const data = await res.json();
    evalScoreBadge.textContent = data.score;
    evalScoreBadge.className = 'score-badge-lg ' + scoreClass(data.score);
    evalReason.textContent = data.reason;
    evalResult.style.display = 'flex';
  } catch (err) {
    errorBanner.textContent = err.message;
    errorBanner.classList.remove('hidden');
  } finally {
    evalBtn.disabled = false;
    evalBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18"/></svg> Evaluate`;
  }
});
