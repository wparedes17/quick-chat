// Single Analysis tab

const runBtn = document.getElementById('run-btn');
const questionEl = document.getElementById('analysis-question');
const criteriaEl = document.getElementById('analysis-criteria');
const errorBanner = document.getElementById('error-banner');
const resultArea = document.getElementById('result-area');
const answerContent = document.getElementById('answer-content');
const scoreBadge = document.getElementById('score-badge');
const reasonText = document.getElementById('reason-text');

function scoreClass(s) {
  if (s >= 4) return 'score-green';
  if (s === 3) return 'score-yellow';
  return 'score-red';
}

runBtn.addEventListener('click', async () => {
  const question = questionEl.value.trim();
  const criteria = criteriaEl.value.trim();
  if (!question || !criteria) return;

  const location = document.getElementById('location-select').value;
  const baseUrl = document.getElementById('scoring-url-input').value.trim();

  runBtn.disabled = true;
  runBtn.innerHTML = '<span class="spinner"></span> Analyzing…';
  errorBanner.classList.add('hidden');
  resultArea.classList.add('hidden');

  try {
    const res = await fetch('/evaluation/single/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, criteria, location, base_url: baseUrl }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || `Request failed: ${res.status}`);
    }
    const data = await res.json();

    answerContent.innerHTML = marked.parse(data.answer || '');
    scoreBadge.textContent = data.score;
    scoreBadge.className = 'score-badge-lg ' + scoreClass(data.score);
    reasonText.textContent = data.reason;
    resultArea.classList.remove('hidden');
  } catch (err) {
    errorBanner.textContent = err.message;
    errorBanner.classList.remove('hidden');
  } finally {
    runBtn.disabled = false;
    runBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18"/></svg> Run Analysis`;
  }
});
