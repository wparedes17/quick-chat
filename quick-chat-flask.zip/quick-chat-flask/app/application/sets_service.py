from app.domain.shared import SetType
from app.infrastructure.sets_repository import SetsRepository

_VALID_TYPES = {SetType.MULTIPLE.value, SetType.TOPIC.value}
_VALID_LOCATIONS = {"eu", "us"}


class SetsService:
    def __init__(self, repo: SetsRepository) -> None:
        self._repo = repo

    def list_sets(self, set_type: str | None = None) -> list[dict]:
        return self._repo.list_sets(set_type)

    def get_set_detail(self, set_id: int) -> dict | None:
        set_row = self._repo.get_set(set_id)
        if not set_row:
            return None
        set_row["questions"] = self._repo.list_test_sets(set_id)
        return set_row

    def create_set(self, set_name: str, set_type: str) -> dict:
        set_name = (set_name or "").strip()
        if not set_name:
            raise ValueError("set_name is required")
        if set_type not in _VALID_TYPES:
            raise ValueError("set_type must be 'multiple' or 'topic'")
        return self._repo.create_set(set_name, set_type)

    def update_set(self, set_id: int, set_name: str, set_type: str) -> None:
        set_name = (set_name or "").strip()
        if not set_name:
            raise ValueError("set_name is required")
        if set_type not in _VALID_TYPES:
            raise ValueError("set_type must be 'multiple' or 'topic'")
        self._repo.update_set(set_id, set_name, set_type)

    def delete_set(self, set_id: int) -> None:
        self._repo.delete_set(set_id)

    def create_question(
        self, set_id: int, question: str, criteria: str, location: str, topic: str | None = None
    ) -> dict:
        set_row = self._repo.get_set(set_id)
        if not set_row:
            raise ValueError("set not found")
        question = (question or "").strip()
        criteria = (criteria or "").strip()
        topic = (topic or "").strip() or None
        if not question or not criteria:
            raise ValueError("question and criteria are required")
        if location not in _VALID_LOCATIONS:
            raise ValueError("location must be 'eu' or 'us'")
        if set_row["set_type"] == SetType.TOPIC.value and not topic:
            raise ValueError("topic is required for topic sets")
        return self._repo.create_test_set(set_id, question, criteria, location, topic)

    def update_question(
        self,
        set_id: int,
        question_id: int,
        question: str,
        criteria: str,
        location: str,
        topic: str | None = None,
    ) -> None:
        set_row = self._repo.get_set(set_id)
        if not set_row:
            raise ValueError("set not found")
        question = (question or "").strip()
        criteria = (criteria or "").strip()
        topic = (topic or "").strip() or None
        if not question or not criteria:
            raise ValueError("question and criteria are required")
        if location not in _VALID_LOCATIONS:
            raise ValueError("location must be 'eu' or 'us'")
        if set_row["set_type"] == SetType.TOPIC.value and not topic:
            raise ValueError("topic is required for topic sets")
        self._repo.update_test_set(question_id, question, criteria, location, topic)

    def delete_question(self, question_id: int) -> None:
        self._repo.delete_test_set(question_id)
