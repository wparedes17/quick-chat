import concurrent.futures
import time
import uuid
from dataclasses import dataclass
from typing import Generator

from app.domain.evaluation.entities import RunResult
from app.domain.evaluation.value_objects import EvaluationRow
from app.domain.shared import EvaluationResult, Location
from app.infrastructure.evaluator_gateway import EvaluatorGateway
from app.infrastructure.scoring_gateway import ScoringGateway


@dataclass
class SingleAnalysisResult:
    answer: str
    evaluation: EvaluationResult


class EvaluationService:
    def __init__(self, scoring_gateway: ScoringGateway, evaluator_gateway: EvaluatorGateway) -> None:
        self._scoring = scoring_gateway
        self._evaluator = evaluator_gateway

    def health(self, base_url: str | None = None) -> dict:
        return self._scoring.health(base_url)

    def run_single(
        self, question: str, criteria: str, location: Location, base_url: str | None = None
    ) -> SingleAnalysisResult:
        from app.domain.chat.entities import ChatRequest
        req = ChatRequest(
            request_id=str(uuid.uuid4()),
            question=question,
            location=location,
            session_id=str(uuid.uuid4()),
            user_id=str(uuid.uuid4()),
        )
        answer_obj = self._scoring.score(req, base_url)
        eval_result = self._evaluator.evaluate(question, answer_obj.answer, criteria, answer_obj.metadata)
        return SingleAnalysisResult(answer=answer_obj.answer, evaluation=eval_result)

    def run_batch(
        self,
        rows: list[EvaluationRow],
        replicas: int,
        location: Location,
        stop_flag: list[bool] | None = None,
        threads: int = 1,
        base_url: str | None = None,
    ) -> Generator[RunResult, None, None]:
        from app.domain.chat.entities import ChatRequest
        user_id = str(uuid.uuid4())

        def run_one(row: EvaluationRow, rep: int) -> RunResult | None:
            t0 = time.monotonic()
            try:
                row_location = Location(row.location) if row.location else location
                req = ChatRequest(
                    request_id=str(uuid.uuid4()),
                    question=row.question,
                    location=row_location,
                    session_id=str(uuid.uuid4()),
                    user_id=user_id,
                )
                answer_obj = self._scoring.score(req, base_url)
                response_time_ms = (time.monotonic() - t0) * 1000
                eval_result = self._evaluator.evaluate(
                    row.question, answer_obj.answer, row.criteria, answer_obj.metadata
                )
                return RunResult(
                    result_id=str(uuid.uuid4()),
                    question=row.question,
                    replica=rep,
                    evaluation=eval_result,
                    response_time_ms=response_time_ms,
                    topic=row.topic,
                    answer=answer_obj.answer,
                    intents=answer_obj.intents,
                    rewritten_question=answer_obj.rewritten_question,
                    question_id=row.question_id,
                    set_id=row.set_id,
                    location=row_location.value,
                )
            except Exception:
                return None  # skip failed runs

        tasks = iter((row, rep) for row in rows for rep in range(1, replicas + 1))
        max_workers = max(1, min(threads, 10))

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            in_flight: dict[concurrent.futures.Future, None] = {}

            def submit_next() -> bool:
                if stop_flag and stop_flag[0]:
                    return False
                row_rep = next(tasks, None)
                if row_rep is None:
                    return False
                in_flight[executor.submit(run_one, *row_rep)] = None
                return True

            for _ in range(max_workers):
                if not submit_next():
                    break

            while in_flight:
                done, _ = concurrent.futures.wait(
                    in_flight, return_when=concurrent.futures.FIRST_COMPLETED
                )
                for future in done:
                    del in_flight[future]
                    result = future.result()
                    if result is not None:
                        yield result
                    submit_next()
