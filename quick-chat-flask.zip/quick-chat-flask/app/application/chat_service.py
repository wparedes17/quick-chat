import uuid
from typing import Generator

from app.domain.chat.entities import ChatAnswer, ChatRequest, StreamEvent
from app.domain.shared import Location
from app.infrastructure.scoring_gateway import ScoringGateway


class ChatApplicationService:
    def __init__(self, scoring_gateway: ScoringGateway) -> None:
        self._scoring = scoring_gateway

    def ask(
        self,
        question: str,
        location: Location,
        session_id: str,
        user_id: str,
        base_url: str | None = None,
    ) -> ChatAnswer:
        req = ChatRequest(
            request_id=str(uuid.uuid4()),
            question=question,
            location=location,
            session_id=session_id,
            user_id=user_id,
        )
        return self._scoring.score(req, base_url)

    def ask_stream(
        self,
        question: str,
        location: Location,
        session_id: str,
        user_id: str,
        base_url: str | None = None,
    ) -> Generator[StreamEvent, None, None]:
        req = ChatRequest(
            request_id=str(uuid.uuid4()),
            question=question,
            location=location,
            session_id=session_id,
            user_id=user_id,
        )
        yield from self._scoring.score_stream(req, base_url)
