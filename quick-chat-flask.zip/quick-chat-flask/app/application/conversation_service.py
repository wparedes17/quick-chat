import uuid
from typing import Generator

from app.domain.conversation.entities import Conversation, ConversationEvent, Turn
from app.domain.conversation.transcript import TranscriptFormatter
from app.domain.shared import EvaluationResult, Location
from app.infrastructure.evaluator_gateway import EvaluatorGateway
from app.infrastructure.follow_gateway import FollowGateway
from app.infrastructure.scoring_gateway import ScoringGateway

DEFAULT_CRITERIA = (
    "The conversation feels natural and coherent. The SYSTEM maintains context across all turns, "
    "provides relevant and helpful responses, and does not break the conversation flow."
)


class ConversationService:
    def __init__(
        self,
        scoring_gateway: ScoringGateway,
        evaluator_gateway: EvaluatorGateway,
        follow_gateway: FollowGateway,
    ) -> None:
        self._scoring = scoring_gateway
        self._evaluator = evaluator_gateway
        self._follow = follow_gateway
        self._formatter = TranscriptFormatter()

    def run_conversation(
        self,
        initial_question: str,
        num_turns: int,
        location: Location,
        stop_flag: list[bool] | None = None,
    ) -> Generator[ConversationEvent, None, None]:
        from app.domain.chat.entities import ChatRequest

        session_id = str(uuid.uuid4())
        user_id = str(uuid.uuid4())
        last_user_msg = initial_question.strip()

        for t in range(num_turns):
            if stop_flag and stop_flag[0]:
                break
            yield ConversationEvent(kind="status", message=f"Turn {t + 1} of {num_turns}: waiting for chatbot…")
            try:
                req = ChatRequest(
                    request_id=str(uuid.uuid4()),
                    question=last_user_msg,
                    location=location,
                    session_id=session_id,
                    user_id=user_id,
                )
                answer_obj = self._scoring.score(req)
                turn = Turn(turn_number=t + 1, user_message=last_user_msg, system_response=answer_obj.answer)
                yield ConversationEvent(kind="turn_complete", turn=turn)

                if t < num_turns - 1 and not (stop_flag and stop_flag[0]):
                    yield ConversationEvent(kind="status", message=f"Turn {t + 1} of {num_turns}: generating follow-up…")
                    last_user_msg = self._follow.follow(last_user_msg, answer_obj.answer)
            except Exception as e:
                yield ConversationEvent(kind="error", message=str(e))
                return

    def evaluate_conversation(self, turns: list[dict], criteria: str) -> EvaluationResult:
        turn_objects = [Turn(t["turn_number"], t["user_message"], t["system_response"]) for t in turns]
        conv = Conversation(
            conversation_id=str(uuid.uuid4()),
            session_id="",
            user_id="",
            location=Location.EU,
            turns=turn_objects,
        )
        transcript = self._formatter.format(conv)
        return self._evaluator.evaluate(transcript.text, transcript.last_response, criteria)
