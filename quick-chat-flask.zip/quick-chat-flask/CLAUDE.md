# CLAUDE.md — Agent context for quick-chat-flask

## What this repo is

A Flask + DDD rewrite of a chatbot evaluation tool. It serves seven pages (Chat, Single Analysis, Multiple Analysis, Topic Analysis, Conversation Evaluation, Sets, Deep Analysis) and proxies all AI logic to three external backends at ports 8080, 8081, 8082.

**There is no AI model code in this repo.** All intelligence is in the external backends.

**Multiple/Topic Analysis run against Postgres-backed question Sets, not CSV upload.** CSV upload has been removed. Questions live in the `sets`/`test_sets` tables (`db/schema.sql`), managed via the `/sets` admin UI (`app/interfaces/sets/routes.py`, `app/application/sets_service.py`, `app/infrastructure/sets_repository.py`). This means `DATABASE_URL` is no longer purely optional — without it, Multiple/Topic Analysis have no questions to run and return a 400.

**The scoring backend URL is overridable per-request.** A header input (`#scoring-url-input` in `base.html`, persisted to `sessionStorage`) lets the user point Chat/Single/Multiple/Topic Analysis at a different `POST /score` instance than `SCORING_URL`. It threads through as an explicit `base_url` parameter — `routes → application service → ScoringGateway.score/score_stream/health(request, base_url=None)` — falling back to the gateway's constructor default when blank. It is *not* stored on the frozen `ChatRequest`, since that type represents the question being asked, not where it's sent.

**Deep Analysis (`/deep-analysis`) reads persisted runs, not live backends.** It's a read-only dashboard over `analysis_runs`/`analysis_results` (`app/interfaces/deep_analysis/routes.py`): pick a set name + date, pick a `run_id` from that day's pool, then view a full dashboard (trend, score distribution, RAGAS metric comparison vs. the previous run, per-topic breakdown, danger table, full results table). Its JSON endpoints are plain synchronous responses, not SSE — `CLAUDE.md`'s SSE convention is scoped to *live* evaluation runs, and this tab never calls the three external backends. It reuses the same aggregator functions as live runs by reconstructing `RunResult` objects from DB rows (`_rows_to_run_results` in that file) rather than duplicating `build_summary`/`build_topic_stats`/etc.

## How to run

```bash
conda activate fastapi-env   # Python 3.11, Flask + httpx installed
cd ~/github/quick-chat-flask
python run.py                # → http://localhost:5000
```

External backends must be running on ports 8080 / 8081 / 8082 before the Flask app can actually call them. The app itself starts fine without them — requests will fail at runtime.

If `DATABASE_URL` is set (optional — see below), apply the schema once before first run:

```bash
psql "$DATABASE_URL" -f db/schema.sql
```

## DDD layer structure — where to make changes

| What you want to change | Where to look |
|---|---|
| A data shape / business rule | `app/domain/` |
| How an external backend is called | `app/infrastructure/<name>_gateway.py` |
| A use case / batch loop | `app/application/<context>_service.py` |
| Sets/TestSets CRUD (question sets used by Multiple/Topic Analysis) | `app/infrastructure/sets_repository.py`, `app/application/sets_service.py`, `app/interfaces/sets/routes.py` |
| A Flask route or SSE event format | `app/interfaces/<context>/routes.py` |
| An HTML page layout | `app/templates/<context>/<name>.html` |
| Shared header / nav / CSS tokens | `app/templates/base.html`, `app/static/css/main.css` |
| JS behavior on a page | `app/static/js/<page>.js` |
| App wiring / blueprint registration | `app/__init__.py` |
| Backend URLs | `config.py` or `.env` |

## Critical files an agent should read before making changes

- `app/__init__.py` — dependency injection wiring; start here to understand how layers connect
- `app/interfaces/<context>/routes.py` — all HTTP routes for a given feature
- `app/application/evaluation_service.py` — batch loop (most complex application code)
- `app/infrastructure/scoring_gateway.py` — NDJSON stream parsing (most complex infrastructure code)
- `app/domain/evaluation/aggregator.py` — chart data builders (score distribution, time histogram, topic stats), `build_danger_list`/`build_metric_averages` (per-question/topic regression detection and metric averaging vs. the previous run — both operate on plain dicts, shared by live SSE routes and the read-only Deep Analysis dashboard via `run_results_to_metric_rows`)
- `app/static/js/analysis_common.js` — shared JS helpers (`scoreClass`, `formatMs`, `escHtml`, `formatMetric`, `delta`, `renderDangerRows`) imported by `multiple_analysis.js`/`topic_analysis.js` as ES modules

## Coding conventions

- **No ORM.** The optional Postgres analytics store (`DATABASE_URL`, schema in `db/schema.sql`) is accessed via raw `psycopg` SQL only — see `app/infrastructure/analysis_repository.py`. All *other* state is per-request or in the browser (`sessionStorage`).
- **No async.** Flask + httpx run synchronously. Do not introduce `asyncio`.
- **Domain layer has no I/O.** `app/domain/` must never import `httpx`, `flask`, `requests`, or `os`.
- **Gateways own wire format.** NDJSON parsing belongs in `scoring_gateway.py`, not in the application layer.
- **Application layer owns business rules.** The batch loop, stop logic, and timing measurement live in `application/evaluation_service.py`. Set/TestSet validation (e.g. "topic sets require a topic per question") lives in `application/sets_service.py`.
- **SSE streaming:** All streaming routes use `stream_with_context(generate())` with `content_type="text/event-stream"` and the header `X-Accel-Buffering: no`.
- **Chart.js:** Always `chart.destroy()` before re-creating on the same canvas. Chart instances are stored in module-level JS variables.

## External backend wire formats

### POST :8080/score
Request: `{ id, question, location, sessionid, userid }`
Response: `{ answer: string, intent: string, metadata?: {...} }` (comma-separated intents in one string). `metadata` is optional — present only when the backend has it, and omitted (not `null`) otherwise: `{ intents: string[], modules: [{ module_name, module_type, text_response, raw_input_data: {}, raw_output_data: {} }] }`. When present, it's forwarded verbatim into the `/evaluate` request (see below); `score_stream` does not carry `metadata` (batch evaluation, the only metadata consumer, never streams).

### GET :8080/health
Response: `{ version: string, env: string }` — used once per batch run to populate `analysis_runs.chat_version_basis`/`feature_name`. Gateway call is best-effort: any failure returns `{version: None, env: None}` rather than raising.

### POST :8080/score/stream
Request: same as above
Response: NDJSON stream. Each line is one of:
- `{ "stage": "answer", "state": "streaming", "message": "{\"chunk\": \"...\"}" }` — double-encoded chunk
- `{ "intent": "tag1,tag2" }` — intent tags (may appear on any line)
- `{ "stage": "[DONE]" }` — end of stream

### POST :8081/evaluate
Request: `{ question: string, answer: string, criteria: string, metadata?: {...} }` — `metadata` (see above) is included only when the scoring backend returned it, omitted otherwise.
Response: `{ score: number (1-5), reason: string, context_precision?, context_recall?, context_entities_recall?, noise_sensitivity?, response_relavancy?, faithfulness?: number }` — the six metric fields are each independently optional; missing/non-numeric values parse to `None`.

### POST :8082/follow
Request: `{ last_message_from_you: string, last_response_from_system: string }`
Response: `{ new_message: string }` — may contain literal `\n` escape sequences that need normalization

## Common tasks

### Add a new route to an existing page
1. Add the route function to `app/interfaces/<context>/routes.py`
2. Add any new use case method to `app/application/<context>_service.py`
3. Add the HTML form/section to the relevant template
4. Add the JS fetch call to the corresponding `static/js/<page>.js`

### Add a new page
1. Create `app/templates/<context>/<page>.html` extending `base.html`
2. Add route in `app/interfaces/<context>/routes.py`
3. Add nav tab button in `app/templates/base.html`
4. Create `app/static/js/<page>.js` if the page has interactivity

### Change how a backend is called
Edit `app/infrastructure/<name>_gateway.py` only. The domain and application layers must not change.

### Add a new TestSet question field
1. Add the column to `test_sets` in `db/schema.sql`
2. Add the field to `EvaluationRow` in `app/domain/evaluation/value_objects.py`
3. Update `SetsRepository`/`SetsService` (`app/infrastructure/sets_repository.py`, `app/application/sets_service.py`) to read/write/validate it
4. Update the Sets admin UI (`app/templates/sets/detail.html`, `app/static/js/sets_admin.js`) to expose it
5. Update the SSE route in `app/interfaces/evaluation/routes.py` to include it in emitted events, and the JS table rendering to show it

## Testing the app

A `tests/` directory holds targeted `pytest` coverage for the Postgres-backed pieces (schema round-trips, gateway wire-format parsing) — these `pytest.mark.skipif` themselves out when `DATABASE_URL` isn't set, so `pytest` is safe to run without a live Postgres instance:

```bash
conda run -n fastapi-env python -m pytest
```

Everything else is still manual verification:

```bash
# Verify Flask starts and all pages load
conda run -n fastapi-env python -c "
from app import create_app
app = create_app()
client = app.test_client()
for url in ['/', '/evaluation/single', '/evaluation/multiple', '/evaluation/topic', '/conversation/', '/sets', '/deep-analysis']:
    r = client.get(url)
    print(url, r.status_code)
"
```

End-to-end testing requires the three external backends to be running.
