# Architecture — quick-chat-flask

This document describes the internal design of the application for developers and AI agents working on the codebase.

---

## High-level overview

The application follows **Domain-Driven Design (DDD)** with four layers. Dependencies flow strictly inward — outer layers depend on inner layers, never the reverse.

```
┌─────────────────────────────────────────────────────────┐
│  Interfaces (Flask blueprints, Jinja2 templates, JS)    │  ← HTTP in/out
├─────────────────────────────────────────────────────────┤
│  Application (use cases, CSV parsing, batch loop)       │  ← orchestration
├─────────────────────────────────────────────────────────┤
│  Domain (entities, value objects, domain services)      │  ← pure logic
├──────────────────────────┬──────────────────────────────┤
│  Infrastructure          │  (injected into application) │  ← HTTP out
│  (gateway adapters)      │                              │
└──────────────────────────┴──────────────────────────────┘
                           ↕
           External backends (:8080, :8081, :8082)
```

---

## Bounded contexts

The domain is divided into three bounded contexts that map 1-to-1 to Flask blueprints.

### 1. Chat (`app/domain/chat/`)
Handles interactive question-answering. Knows about sessions, user IDs, streaming, and intent tags. Calls only the **scoring backend** (`:8080`).

### 2. Evaluation (`app/domain/evaluation/`)
Handles batch testing of the chatbot against criteria. Owns:
- The CSV row schema (`EvaluationRow` — columns: `question`, `criteria`, optionally `topic`)
- The batch run loop (sequential: score → evaluate → accumulate)
- Result aggregation (score distributions, histograms, topic groupings)

Calls the **scoring backend** (`:8080`) and the **evaluator backend** (`:8081`).

### 3. Conversation (`app/domain/conversation/`)
Handles multi-turn conversations. Owns:
- The `Conversation` aggregate (ordered list of `Turn` objects)
- The `TranscriptFormatter` — builds the text string sent to `/evaluate` as the "question"
- The turn loop (score → follow → score → … → evaluate)

Calls all three backends.

---

## Layer-by-layer reference

### Domain layer (`app/domain/`)

Pure Python — no I/O, no Flask imports, no httpx. Everything here is tested without running a server.

**`domain/shared.py`**
- `Location(str, Enum)` — `"us"` or `"eu"`, passed to every scoring request
- `EvaluationResult(score: int, reason: str)` — frozen dataclass, used across all bounded contexts

**`domain/chat/entities.py`**
- `ChatRequest` — value object carrying the fields required by `/score`: `request_id`, `question`, `location`, `session_id`, `user_id`
- `ChatAnswer` — value object: `answer: str`, `intents: list[str]`
- `StreamEvent` — value object emitted by the gateway during streaming: `kind` is `"chunk"`, `"intents"`, or `"done"`; `payload` is the text or intent list

**`domain/evaluation/entities.py`**
- `RunResult` — one completed evaluation run: `question`, `replica` number, `EvaluationResult`, `response_time_ms`, optional `topic`

**`domain/evaluation/value_objects.py`**
- `EvaluationRow` — one parsed CSV row: `question`, `criteria`, optional `topic`

**`domain/evaluation/aggregator.py`**
- `build_summary(results)` — computes count, avg score, avg time, score distribution dict, time histogram
- `build_topic_stats(results)` — groups results by topic, computes per-topic stats + color from `TOPIC_PALETTE`
- `build_time_histogram(times, num_buckets=8)` — identical logic to the TypeScript `buildTimeHistogram` in the original React code

**`domain/conversation/entities.py`**
- `Conversation` — aggregate: `turns: list[Turn]`, optional `evaluation: EvaluationResult`
- `Turn` — `turn_number`, `user_message`, `system_response`
- `ConversationEvent` — emitted by the service generator: `kind` is `"turn_complete"`, `"status"`, or `"error"`

**`domain/conversation/transcript.py`**
- `TranscriptFormatter.format(conversation)` — returns `ConversationTranscript` with `.text` (full formatted transcript) and `.last_response` (last system turn). The `.text` is sent as the `question` parameter to `/evaluate`, matching the original React behavior.

---

### Infrastructure layer (`app/infrastructure/`)

Adapters that talk to the three external HTTP backends. Each gateway owns the wire-format concerns for its backend.

**`infrastructure/ports.py`**
Protocol interfaces (`typing.Protocol`) for all three gateways. Application services depend on these protocols, not concrete classes — enables testing with fakes.

**`infrastructure/scoring_gateway.py` — most complex**

Handles two endpoints:
- `score(request)` → `ChatAnswer` — simple POST, parse JSON response
- `score_stream(request)` → `Generator[StreamEvent]` — httpx streaming, NDJSON line-by-line parsing

NDJSON parsing logic (`_parse_line`) is a direct port of `handlePayload` from the original `chatApi.ts`:
1. Parse JSON line
2. If `intent` field present → yield `StreamEvent(kind="intents", payload=[...])`
3. If `stage == "answer"` and `state == "streaming"` → parse the double-encoded `message` field → extract `chunk` → yield `StreamEvent(kind="chunk", payload=chunk)`

The double-encoding exists because the backend wraps the chunk in a JSON string inside the outer JSON object.

Uses `httpx.stream()` (sync context manager) rather than `requests` for cleaner streaming iteration.

**`infrastructure/follow_gateway.py`**

After calling `/follow`, applies the same whitespace normalization as the original TypeScript:
1. Replace literal escape sequences (`\n`, `\r`, `\t` as text) with space
2. Replace actual control characters with space  
3. Collapse multiple spaces, strip

**`infrastructure/evaluator_gateway.py`**

Simple POST to `/evaluate`, returns `EvaluationResult`.

---

### Application layer (`app/application/`)

Use cases that orchestrate domain objects and infrastructure. This is where the batch loop lives — it is business logic (run N times, measure, aggregate), not infrastructure.

**`application/chat_service.py`**
- `ask(question, location, session_id, user_id)` → `ChatAnswer` — for non-streaming mode
- `ask_stream(question, location, session_id, user_id)` → `Generator[StreamEvent]` — for streaming mode; passes the generator from the gateway straight through

**`application/evaluation_service.py`**

`parse_csv(file_content, require_topic)` → `list[EvaluationRow]`
- Splits lines, finds column indices for `question`, `criteria`, `topic`
- Returns a `ValueError` with a human-readable message on bad input
- Owned here (not in the domain) because it knows about column names — an input-format concern

`run_single(question, criteria, location)` → `SingleAnalysisResult`
- Score the question, then evaluate the answer

`run_batch(rows, replicas, location, stop_flag)` → `Generator[RunResult]`
- The main batch loop: for each row, for each replica, call score + evaluate
- `stop_flag` is a `list[bool]` — caller sets `stop_flag[0] = True` to halt the loop
- Measures `response_time_ms` with `time.monotonic()` (wall clock, monotonic)
- Silently skips failed requests (increments nothing — the SSE layer counts)
- Used for both Multiple Analysis and Topic Analysis (topic is just an optional field on `EvaluationRow`)

**`application/conversation_service.py`**

`run_conversation(initial_question, num_turns, location, stop_flag)` → `Generator[ConversationEvent]`
- Alternates between scoring and follow-up generation
- Emits `status` events so the UI can show progress text
- Emits `turn_complete` events carrying the `Turn` object

`evaluate_conversation(turns, criteria)` → `EvaluationResult`
- Reconstructs a `Conversation` from the raw turn dicts (sent by the browser as JSON)
- Uses `TranscriptFormatter` to produce the transcript
- Calls the evaluator gateway

---

### Interface layer (`app/interfaces/`)

Flask blueprints. Each blueprint corresponds to one bounded context.

**Blueprint registration (`app/__init__.py` — `create_app`)**
```
chat_bp          → prefix: /
evaluation_bp    → prefix: /evaluation
conversation_bp  → prefix: /conversation
```

**Dependency injection:** Gateways and services are instantiated once in `create_app()` and stored in `app.config`. Blueprint routes access them via `current_app.config["CHAT_SERVICE"]` etc.

**Streaming pattern (used in all three blueprints):**
```python
def generate():
    for event in service.ask_stream(...):
        yield f"data: {json.dumps({...})}\n\n"
    yield "data: [DONE]\n\n"

return Response(
    stream_with_context(generate()),
    content_type="text/event-stream",
    headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
)
```
`stream_with_context` keeps the Flask application context alive during generator iteration. `X-Accel-Buffering: no` disables nginx buffering if the app runs behind a reverse proxy.

**CSV upload (Multiple and Topic Analysis):**
- Method: `POST` with `multipart/form-data`
- Fields: `file` (the CSV), `location` (us/eu), `replicas` (int)
- The route reads the file bytes, calls `parse_csv()`, returns 400 on `ValueError`

---

### Templates (`app/templates/`)

Jinja2 templates using Jinja2 template inheritance.

**`base.html`** — the parent template. Includes:
- Tailwind CSS CDN (play CDN — supports arbitrary values and custom config)
- Chart.js CDN (v4)
- marked.js CDN (v9) — Markdown parsing in JS
- Site header with bot icon, session display, location selector, streaming toggle, clear button
- Navigation tabs (each tab is a page link, not a JS tab — navigates to a different URL)
- A small inline `<script>` that restores `location` and `streaming` preferences from `sessionStorage` on every page load

Child templates extend `base.html` and set `{% set active_tab = "chat" %}` (or similar) to highlight the correct tab.

**Session state:** The `session_id` is stored in `sessionStorage` (survives page navigation within the tab, cleared on tab close). The location selector and streaming toggle preferences are also persisted in `sessionStorage`.

---

### Static files (`app/static/`)

**`css/main.css`**
- CSS custom properties (`:root { --primary: ...; --border: ...; }`) — design tokens copied from the original `src/index.css`
- All component classes (`.card`, `.btn`, `.score-badge`, `.progress-bar`, `.msg-bubble`, etc.)
- No build step — plain CSS, loaded directly

**JavaScript modules** (`type="module"` — native ES modules, no bundler)

Each JS file is scoped to one page. They run after the DOM is ready (module scripts are deferred by default).

| File | Responsibility |
|---|---|
| `chat.js` | Auto-resize textarea, streaming via `fetch` + `ReadableStream`, message bubble DOM append, abort via `AbortController`, `marked.parse()` for assistant responses |
| `single_analysis.js` | POST form, render score card with badge color |
| `multiple_analysis.js` | File drop zone, SSE `fetch` streaming, live row append, Chart.js score + time charts |
| `topic_analysis.js` | Same as multiple, plus comparison horizontal bar charts and per-topic histograms |
| `conversation.js` | SSE turn streaming, transcript append, copy-to-clipboard, evaluate step |

**SSE consumption pattern (all JS files):**
```js
const res = await fetch('/ask/stream', { method: 'POST', body: JSON.stringify(body), ... });
const reader = res.body.getReader();
const decoder = new TextDecoder();
let buffer = '';
while (true) {
  const { value, done } = await reader.read();
  if (done) break;
  buffer += decoder.decode(value, { stream: true });
  const lines = buffer.split('\n\n');
  buffer = lines.pop() ?? '';
  for (const line of lines) {
    const dataPart = line.replace(/^data: /, '').trim();
    if (!dataPart || dataPart === '[DONE]') continue;
    const ev = JSON.parse(dataPart);
    // handle ev.type ...
  }
}
```

**Chart.js conventions:**
- Always call `chart.destroy()` before creating a new chart on the same canvas — otherwise Chart.js throws "Canvas already in use"
- Score distribution: `type: 'bar'`, `backgroundColor` as an array of 5 colors (one per score 1–5)
- Time histogram: `type: 'bar'`, single primary color (`#6366f1`)
- Topic horizontal bars: `indexAxis: 'y'`, one color per topic from `TOPIC_PALETTE`

---

## Data flow diagrams

### Chat (streaming)
```
Browser                  Flask /ask/stream        ScoringGateway        :8080/score/stream
  │                             │                       │                       │
  │── POST /ask/stream ────────►│                       │                       │
  │   (JSON body)               │── httpx.stream ──────►│                       │
  │                             │   POST /score/stream  │──── HTTP POST ────────►│
  │                             │                       │                       │
  │◄── SSE chunks ─────────────│◄── StreamEvent gen ───│◄──── NDJSON lines ────│
  │   data: {"chunk":"..."}     │   kind="chunk"        │   parse → yield       │
  │   data: {"intents":[...]}   │   kind="intents"      │                       │
  │   data: [DONE]              │                       │                       │
```

### Multiple Analysis (batch SSE)
```
Browser                  Flask /evaluation/multiple/run     EvaluationService
  │                             │                                  │
  │── POST (multipart CSV) ────►│                                  │
  │                             │── parse_csv() ──────────────────►│
  │                             │── run_batch() [generator] ──────►│
  │                             │                                  │
  │                             │   for each (row, replica):       │
  │                             │     score → evaluate → yield RunResult
  │◄── SSE result events ───────│◄── RunResult ────────────────────│
  │   data: {"type":"result",...}│                                  │
  │                             │   after all rows:                │
  │◄── SSE stats event ─────────│◄── build_summary() ─────────────│
  │   data: {"type":"stats",...} │                                  │
  │   data: [DONE]              │                                  │
```

### Conversation run
```
Browser               Flask /conversation/run      ConversationService
  │                         │                            │
  │── POST (JSON) ─────────►│                            │
  │                         │── run_conversation() ─────►│
  │                         │                            │
  │                         │   turn 1:                  │
  │                         │   score(question) → Turn   │
  │◄── SSE turn event ──────│◄── ConversationEvent ──────│
  │   {"type":"turn", ...}  │   kind="turn_complete"     │
  │                         │                            │
  │                         │   turn 2 (if n>1):         │
  │                         │   follow(q, a) → new_q     │
  │                         │   score(new_q) → Turn      │
  │◄── SSE turn event ──────│◄── ConversationEvent ──────│
  │   ...                   │                            │
  │   data: [DONE]          │                            │
  │                         │                            │
  │── POST /conversation/evaluate ──────────────────────►│
  │   (turns[] + criteria)  │   TranscriptFormatter      │
  │                         │   → evaluator.evaluate()   │
  │◄── JSON {score, reason} │◄── EvaluationResult ───────│
```

---

## Key design decisions

### Why httpx instead of requests?
`httpx.stream()` provides a clean context manager for streaming HTTP responses. The `with httpx.stream(...) as response: for chunk in response.iter_text()` pattern is more explicit about resource lifetime than `requests`' `stream=True`. Both are synchronous — no async needed since Flask runs synchronously.

### Why the batch loop is in the application layer, not the interface layer
The rules "run each question N times", "measure response time", "skip failed runs", and "stop when flag is set" are **business rules** — they express what the evaluation domain does, not how HTTP works. Putting them in a Flask route would mix concerns and make testing harder.

### Why `stop_flag` is a `list[bool]` and not a `threading.Event`
The batch generator runs synchronously in the same thread as the Flask SSE response. The generator's `yield` transfers control back to the Flask route, which writes to the socket. There is no true concurrency — the stop flag is checked at the top of each inner loop iteration. A mutable list `[False]` works because Python closures capture the list reference, not the value.

### Why session IDs are managed in sessionStorage (browser), not Flask sessions
The original React app generated session IDs client-side with `crypto.randomUUID()`. The Flask version preserves this: `sessionStorage` in `base.html` generates and persists the `session_id` for the duration of the browser tab. Flask has no session state — the `session_id` is sent in the POST body by the JavaScript on each request.

### Why tabs are separate pages (URLs), not JS-toggled sections
The original React app used client-side routing (React Router + shadcn Tabs). In the Flask version, each tab is a distinct URL and Jinja2 template. This is simpler, requires no client-side router, and makes it possible to link directly to a specific analysis page. The trade-off is a full page load on tab switch, which is acceptable for this tool.

---

## Adding a new feature

1. **New domain object** → add to the appropriate `domain/<context>/` module (no I/O)
2. **New backend call** → add a method to the relevant gateway in `infrastructure/`
3. **New use case** → add a method to the relevant `application/<context>_service.py`
4. **New page** → add a Jinja2 template, a route in `interfaces/<context>/routes.py`, and register in `create_app()` if it's a new blueprint
5. **New JS behavior** → add to the corresponding `static/js/<page>.js` file

The dependency injection is done in `app/__init__.py`. If a new use case needs a new gateway, inject it there.
