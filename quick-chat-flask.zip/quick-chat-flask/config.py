import os
from dotenv import load_dotenv

load_dotenv()

SCORING_URL   = os.getenv("SCORING_URL",   "http://localhost:8080")
EVALUATOR_URL = os.getenv("EVALUATOR_URL", "http://localhost:8081")
FOLLOW_URL    = os.getenv("FOLLOW_URL",    "http://localhost:8082")
DATABASE_URL  = os.getenv("DATABASE_URL",  "")
