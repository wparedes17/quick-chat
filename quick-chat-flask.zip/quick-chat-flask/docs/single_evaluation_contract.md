# Single Evaluation Contract

This document specifies the wire contract for a **single evaluation call**: one `(question, answer, criteria)` unit sent to the external evaluator backend and scored back. It is the authoritative reference for anyone implementing or changing the evaluator backend at `EVALUATOR_URL` (default `http://localhost:8081`), and for anyone changing `app/infrastructure/evaluator_gateway.py` in this repo, which is the only code that speaks this contract.

## Scope

- **Endpoint:** `POST {EVALUATOR_URL}/evaluate`
- **Called from:** `EvaluationService.run_single()` (Single Analysis page, one call) and `EvaluationService.run_batch()` (Multiple/Topic Analysis, one call per question × replica) — both in `app/application/evaluation_service.py`. Every call in this repo goes through `EvaluatorGateway.evaluate()` in `app/infrastructure/evaluator_gateway.py`, which owns all wire-format parsing per this repo's DDD conventions.
- **Not covered here:** the `/score` and `/score/stream` contracts (see `CLAUDE.md`'s "External backend wire formats" section). This document only covers `/evaluate`; the `metadata` field below *originates* from `/score`'s response and is forwarded here verbatim, but its production is out of scope.

## Transport

| | |
|---|---|
| Method | `POST` |
| Path | `/evaluate` |
| Headers | `Content-Type: application/json`, `Accept-Language: en` |
| Timeout | 60s (client-side, `httpx.Client(timeout=60.0)`) |
| Auth | None currently implemented |

## Request

### Body schema

| Field | Type | Required | Description |
|---|---|---|---|
| `question` | `string` | Yes | The question that was asked. |
| `answer` | `string` | Yes | The chatbot's answer to `question`, as returned by `/score`. |
| `criteria` | `string` | Yes | Free-text grading criteria the evaluator should judge the answer against. |
| `metadata` | `object` | No | **Omitted from the request body entirely when unavailable** (never sent as `"metadata": null`) — see [`metadata` object](#metadata-object) below. |

### `metadata` object

Present only when the scoring backend (`/score`) returned it. Forwarded byte-for-byte from `/score`'s response into this request — this repo does not transform it.

| Field | Type | Required | Description |
|---|---|---|---|
| `intents` | `string[]` | Yes | Intent tags associated with the scoring turn. |
| `modules` | `array<Module>` | Yes | Pipeline modules involved in producing the answer (e.g. retrievers). May be empty. |

**`Module` object** (each entry in `modules`):

| Field | Type | Required | Description |
|---|---|---|---|
| `module_name` | `string` | Yes | Identifier for the module (e.g. `"retriever"`). |
| `module_type` | `string` | Yes | Category of module (e.g. `"rag"`). |
| `text_response` | `string` | Yes | The module's textual output. |
| `raw_input_data` | `object` | Yes | Free-form dict of the module's raw input. Shape is module-specific and not validated by this repo. |
| `raw_output_data` | `object` | Yes | Free-form dict of the module's raw output. Shape is module-specific and not validated by this repo. |

### Request examples

With metadata:

```json
{
  "question": "What's your refund policy?",
  "answer": "Refunds are available within 30 days of purchase.",
  "criteria": "The answer must correctly state the refund window and cite a source.",
  "metadata": {
    "intents": ["billing", "refund"],
    "modules": [
      {
        "module_name": "retriever",
        "module_type": "rag",
        "text_response": "Refund policy: 30-day window, original payment method.",
        "raw_input_data": { "query": "refund policy" },
        "raw_output_data": { "doc_ids": ["kb-042"], "score": 0.91 }
      }
    ]
  }
}
```

Without metadata (key omitted entirely, not `null`):

```json
{
  "question": "What's your refund policy?",
  "answer": "Refunds are available within 30 days of purchase.",
  "criteria": "The answer must correctly state the refund window and cite a source."
}
```

## Response

### Body schema

| Field | Type | Required | Range / notes |
|---|---|---|---|
| `score` | `number` | Yes | Coerced to `int`. Non-numeric or missing values are treated as `0` by the client. Conventionally `1`–`5`. |
| `reason` | `string` | Yes | Human-readable justification for the score. Missing/non-string values are treated as `""` by the client. |
| `context_precision` | `number` | No | Independently optional. Missing or non-numeric → parsed as `null`/`None`. |
| `context_recall` | `number` | No | Independently optional. Missing or non-numeric → parsed as `null`/`None`. |
| `context_entities_recall` | `number` | No | Independently optional. Missing or non-numeric → parsed as `null`/`None`. |
| `noise_sensitivity` | `number` | No | Independently optional. Missing or non-numeric → parsed as `null`/`None`. |
| `response_relavancy` | `number` | No | Independently optional. **Spelling is intentional** — matches the field name used throughout this repo's schema/domain/UI; do not "fix" to `response_relevancy` without updating all of them together. |
| `faithfulness` | `number` | No | Independently optional. Missing or non-numeric → parsed as `null`/`None`. |

Each of the six optional metrics is evaluated independently — a response may include any subset of them (including none). There is no requirement that they all be present together.

> **Metric directionality note:** this repo's regression-detection logic (`build_danger_list` in `app/domain/evaluation/aggregator.py`) flags **any decrease** in any of these seven fields (score + the six metrics) between two runs as "in danger," without per-metric awareness of which direction is actually better. This is a known simplification carried over from the original requirements. If a future metric here is conventionally "lower is better" (e.g. some interpretations of `noise_sensitivity`), a decrease will still be flagged as a regression by this repo's UI — evaluator implementers should be aware their scale's "better direction" is not currently honored downstream.

### Response examples

Full response (all metrics present):

```json
{
  "score": 4,
  "reason": "Correctly states the 30-day window; does not explicitly cite a source document.",
  "context_precision": 0.83,
  "context_recall": 0.91,
  "context_entities_recall": 0.77,
  "noise_sensitivity": 0.12,
  "response_relavancy": 0.88,
  "faithfulness": 0.95
}
```

Minimal response (no `metadata` was sent in the request, so no retrieval-grounded metrics are computable):

```json
{
  "score": 3,
  "reason": "Answer is directionally correct but vague."
}
```

## Error handling

- Any non-2xx HTTP status causes `httpx.Client.raise_for_status()` to raise `httpx.HTTPStatusError`.
- In `run_single` (Single Analysis), this propagates up to the route and is returned to the browser as `{"error": str(e)}` with HTTP `502`.
- In `run_batch` (Multiple/Topic Analysis), each `(question, replica)` unit is wrapped in its own `try/except Exception: pass` — a failed evaluation call silently drops that one unit from the results stream rather than aborting the whole batch. Malformed JSON, connection errors, and timeouts are handled the same way as HTTP error statuses.
- There is currently no retry logic on either side.

## Versioning & compatibility

- This contract has no version header or number. Changes must be backward-compatible in practice: new fields should be added as optional (request and response), and existing field names/types should not change without updating `app/infrastructure/evaluator_gateway.py`, `app/domain/shared.py` (`EvaluationResult`), `app/domain/chat/entities.py` (`ChatMetadata`/`ChatModule`), `db/schema.sql`, and this document together.
- If a new optional metric is added, it should follow the same "independently optional, `null`/absent when not computed" pattern as the six existing ones, and the corresponding column should be added to `analysis_results` in `db/schema.sql`.
