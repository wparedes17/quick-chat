
# Add metadata support
I want to mutate multiple and topic analysis. Currently: question and criteria (and topic for topic analysis) run over a simple beahavior. Scoring provide answer. I would like to consider a extra field:

- metadata (not always available). Metadata will include two fields: intents and filed "modules" with a list of JSON objects module_name, module_type, text_response, raw_input_data (free dict) and raw_output_dat (free_dict)

when metadata is not available, metadata will be not send in evaluate object.

# Deprecate CSV approach
CSV approach will have to be deprecated.
## New postgres database model
TestSets
question_id, set_id, question, topic, criteria, location

Sets
set_id, set_name, set_type

Update current tables:

CREATE TABLE analysis_runs (
    id                 SERIAL PRIMARY KEY,
    csv_filename       TEXT, //Replace for set_id, adjust type
    analysis_type      TEXT,       -- "multiple" or "topic"
    location           TEXT,
    replicas           INTEGER,
    total_count        INTEGER,
    avg_score          NUMERIC,
    avg_time_ms        NUMERIC,
    invalid_count      INTEGER,
    score_distribution JSONB,
    intent_stats       JSONB,
    run_date           TIMESTAMP DEFAULT now(),
    created_at         TIMESTAMP DEFAULT now(),
    chat_version_basis       TEXT, // New field optional,
    feature_name       TEXT, // New field optional,
);

CREATE TABLE analysis_results (
    run_id             INTEGER REFERENCES analysis_runs(id),
    question_id        INTEGER, // Foreign key to TestSets (add new field)
    set_id             INTEGER, // Foreign key to Sets (add new field)
    question           TEXT,
    topic              TEXT, // Optional
    replica            INTEGER,
    score              NUMERIC,
    reason             TEXT,
    context_precision NUMERIC, // New field optional,
    context_recall    NUMERIC, // New field optional,
    context_entities_recall NUMERIC, // New field optional,
    noise_sensitivity  NUMERIC, // New field optional,
    response_relavancy NUMERIC, // New field optional,
    faithfulness       NUMERIC, // New field optional,
    response_time_ms   NUMERIC,
    answer             TEXT,
    intents            TEXT,    
    rewritten_question TEXT, // Removed field,
    is_invalid         BOOLEAN, // Removed field,
);

So, we have to update postgress analysis_run to use: set_id instead of csv_filename. Location has to be at question level son instead of be in analysis_runs be have to be in analysis results. 

/health endpoint for chat/scoring expose a "version" and "env" (environment) to identify the running instance. That data can be used to monitor the running instance and to identify the version of the running code.

## Default set
set_id 1 is default to show in UI for multiple analysis and topic analysis.

## New UI

- Across all the tabs, chat model has to be an input. SCORING_URL   = os.getenv("SCORING_URL",   "http://localhost:8080")

So, endpoint for scoring: POST /score and STREAM POST /score/stream hast to be also provided by user as default these values.

We have to show:

- Plots first
- Find questions in danger. I mean questions and topics (topics only in topic analysis) that got a decrease in score with the particular scores when they are available (context precision, recall, entities recall, noise sensitivity, response relavancy, faithfulness)
- Table of results as follow with current at first instance and the change over the time:

- question
- topic
- score
- reason
Optional (we show as NA when not available):
- context_precision
- context_recall
- context_entities_recall
- noise_sensitivity
- response_relavancy
- faithfulness

# Parallel calls
Currently, request to the services are sequantially. Enable to the user set a number of threads to parallelize the calls (maximum 10)

# Add new tab for a deep analysis of a run
Add a new tab to the UI to show a deep analysis of a run.

Be free to propose a good dashboard.

User has to select only by set_name and date. We can have several runs with these features. User has to select the right set run_id from the pool and we provide the analysis for it.
