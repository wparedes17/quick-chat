# Proposal: An "Evaluation Core" Independent of the Flask UI

**Status:** proposal / architecture note. No code change is implied by this
document — see [Non-goals](#non-goals).

## Framing

This repo is usually described as "a Flask UI for evaluating a chatbot."
That's accurate for what a user sees, but it understates what's actually
valuable here. Three things carry the real substance of the system, and none
of them are Flask-specific:

1. **The evaluation contract** — a RAGAS-style metrics wire format
   (`score` + `context_precision`, `context_recall`,
   `context_entities_recall`, `noise_sensitivity`, `response_relavancy`,
   `faithfulness`), documented in
   [`single_evaluation_contract.md`](single_evaluation_contract.md).
2. **The SQL data model** — a Postgres schema (`db/schema.sql`) for question
   sets and evaluation run history.
3. **The aggregation & regression-detection approach** — how per-question
   metrics roll up into run summaries, topic breakdowns, and "did this get
   worse since last time" comparisons.

The Flask app (Chat, Single/Multiple/Topic Analysis, Sets, Deep Analysis) is
one **tool** built on top of these three things — a dashboard and batch
orchestrator. Nothing about the contract, the schema, or the aggregation
logic requires Flask, HTTP sessions, or server-rendered templates. A CLI
runner, a CI/CD quality gate, or a notebook could produce and consume the
exact same data without touching this repo's UI layer at all.

This document proposes treating that separation as an explicit design
principle — an **Evaluation Core** (contract + schema + aggregation) that
tools, plural, sit on top of — rather than something that's merely true by
accident of how the code happens to be organized today.

## Current state: already mostly tool-agnostic, not yet named as such

Checking each piece against the actual code:

| Piece | File(s) | Tool-agnostic today? |
|---|---|---|
| Evaluation contract | [`single_evaluation_contract.md`](single_evaluation_contract.md), `app/infrastructure/evaluator_gateway.py` | Yes — plain JSON over HTTP, owned by the external `:8081` backend, not this repo. |
| Metric value shape | `app/domain/shared.py` (`EvaluationResult`) | Yes — a frozen dataclass, no imports outside the standard library. |
| SQL schema | `db/schema.sql` | Yes — raw DDL, no ORM, no Flask concepts (sessions, request context) anywhere in it. |
| Aggregation logic | `app/domain/evaluation/aggregator.py` (`build_summary`, `build_topic_stats`, `build_metric_averages`, `build_danger_list`) | Yes — pure functions over dataclasses/dicts. Per this repo's own convention, `app/domain/` "has no I/O" (no `httpx`, `flask`, `requests`, `os`), which is exactly the constraint that keeps this layer reusable. |
| Persistence access | `app/infrastructure/analysis_repository.py` | Mostly — raw `psycopg` SQL, no ORM. Its only Flask-shaped dependency is reading `DATABASE_URL` from `config.py`. |
| Everything above this line | `app/interfaces/*/routes.py`, `app/templates/`, `app/static/js/` | No — and it shouldn't be. This is "the tool." |

The honest summary: the *code* is already well-factored for this separation
(that's what the DDD layering in `CLAUDE.md` buys you). What's missing is
that nobody has said out loud "this boundary is deliberate and load-bearing,
not incidental" — so there's nothing stopping future changes from quietly
blurring it (e.g. a Flask-specific assumption creeping into the aggregator,
or a schema column added only because one UI screen wants it).

## Proposed layering

```
L0  External AI backends   — the actual intelligence; already external
L1  Evaluation Contract    — the /evaluate wire format (RAGAS-style metrics)
L2  Persistence            — Postgres schema: runs, results, question sets
L3  Aggregation            — pure functions: summaries, topic stats, regressions
L4  Tools                  — Flask UI (today), and whatever else wants in
```

L1–L3 together are the **Evaluation Core**. Anything that can speak the L1
contract and read/write the L2 schema gets L3's aggregation and regression
detection "for free," without adopting Flask, this repo's templates, or its
routing.

### Mermaid diagram

```mermaid
flowchart TB
    subgraph L0["External AI Backends (already tool-agnostic)"]
        score[":8080 /score\nchat responses"]
        evaluator[":8081 /evaluate\nRAGAS-style scoring"]
        follow[":8082 /follow\nconversation follow-ups"]
    end

    subgraph CORE["Evaluation Core"]
        contract["L1 — Evaluation Contract\nscore + context_precision + context_recall +\ncontext_entities_recall + noise_sensitivity +\nresponse_relavancy + faithfulness"]
        schema[("L2 — Postgres schema\nsets / test_sets /\nanalysis_runs / analysis_results")]
        agg["L3 — Aggregation & regression logic\nbuild_summary, build_topic_stats,\nbuild_metric_averages, build_danger_list\n(pure functions, no I/O)"]

        contract --> schema
        schema --> agg
    end

    subgraph TOOLS["L4 — Tools (consumers)"]
        flaskui["Flask UI (this repo)\nChat / Single / Multiple / Topic /\nSets / Deep Analysis"]
        cli["CLI batch runner\n(hypothetical)"]
        cigate["CI/CD quality gate\n(hypothetical)"]
        notebook["Notebook / BI dashboard\n(hypothetical)"]
    end

    evaluator -->|"per-answer metrics"| contract
    score -.->|"answers to be scored"| evaluator
    follow -.->|"multi-turn probing"| score

    agg --> flaskui
    agg --> cli
    agg --> cigate
    agg --> notebook

    flaskui -->|"writes runs via SQL"| schema
    cli -.->|"writes runs via SQL"| schema
    cigate -.->|"writes runs via SQL"| schema
```

Solid arrows are the path this repo exercises today. Dashed arrows mark
either upstream call chains that are internal to the L0 backends, or paths a
hypothetical future tool would exercise — nothing dashed exists in this repo
right now.

## Recommendations

These are meant to be cheap and mostly already-true; the point is to make
them explicit so they survive future changes, not to launch a rewrite.

1. **Keep `app/domain/` I/O-free.** This is already a stated convention in
   `CLAUDE.md`. Treat it as the actual enforcement mechanism for L1/L3
   staying reusable — a domain-layer function that imports `flask` or
   `httpx` is the concrete signal that the core/tool boundary has been
   crossed.
2. **Keep the SQL schema free of UI-specific concepts.** `db/schema.sql`
   has no Flask-shaped columns today (no session ids, no UI state). New
   columns should be justified by the evaluation domain (a new metric, a new
   run attribute), not by "screen X needs a place to stash Y."
3. **Version the `/evaluate` contract if it gets a second independent
   implementer.** `single_evaluation_contract.md`'s own "Versioning &
   compatibility" section notes there's currently no version header — that's
   fine with one implementer and one consumer, but is the first thing to fix
   if a second tool starts depending on this contract independently.
4. **Don't extract L1–L3 into a standalone package yet.** There is currently
   exactly one tool (this Flask app). Extraction is speculative work against
   a requirement that doesn't exist. The reason to write this document now,
   rather than when a second tool shows up, is that the boundary is already
   clean — `aggregator.py` and `db/schema.sql` could be lifted into a
   separate package largely as-is if that day comes. The proposal is to
   preserve that property, not to act on it preemptively.

## Non-goals

- No code, schema, or contract changes are proposed here.
- No new service, package, or repository split is proposed here.
- This document does not change anything about how the Flask app currently
  works; it only names an architectural property that already holds and
  recommends keeping it true.
