from app.domain.evaluation.aggregator import build_danger_list, run_results_to_metric_rows
from app.domain.evaluation.entities import RunResult
from app.domain.shared import EvaluationResult


def _current(question, score, topic=None, **metrics):
    """Builds a RunResult and immediately flattens it, mirroring how the live
    evaluation routes call build_danger_list via run_results_to_metric_rows."""
    result = RunResult(
        result_id="r1",
        question=question,
        replica=1,
        evaluation=EvaluationResult(score=score, reason="", **metrics),
        response_time_ms=100.0,
        topic=topic,
    )
    return run_results_to_metric_rows([result])[0]


def _previous(question, score, topic=None, **metrics):
    row = {"question": question, "topic": topic, "score": score}
    for field in (
        "context_precision", "context_recall", "context_entities_recall",
        "noise_sensitivity", "response_relavancy", "faithfulness",
    ):
        row[field] = metrics.get(field)
    return row


def test_flags_score_regression():
    current = [_current("Q1", score=3)]
    previous = [_previous("Q1", score=5)]
    danger = build_danger_list(current, previous)
    assert len(danger) == 1
    assert danger[0]["question"] == "Q1"
    assert danger[0]["regressions"]["score"] == {"previous": 5.0, "current": 3.0, "delta": -2.0}


def test_no_flag_when_score_improved():
    current = [_current("Q1", score=5)]
    previous = [_previous("Q1", score=3)]
    assert build_danger_list(current, previous) == []


def test_metric_present_both_sides_and_regressed():
    current = [_current("Q1", score=4, faithfulness=0.5)]
    previous = [_previous("Q1", score=4, faithfulness=0.9)]
    danger = build_danger_list(current, previous)
    assert danger[0]["regressions"]["faithfulness"]["previous"] == 0.9
    assert danger[0]["regressions"]["faithfulness"]["current"] == 0.5
    assert "score" not in danger[0]["regressions"]


def test_metric_present_only_on_one_side_is_excluded():
    current = [_current("Q1", score=4, faithfulness=0.5)]
    previous = [_previous("Q1", score=4, faithfulness=None)]
    danger = build_danger_list(current, previous)
    assert danger == []


def test_metric_absent_both_sides_is_excluded():
    current = [_current("Q1", score=4)]
    previous = [_previous("Q1", score=4)]
    assert build_danger_list(current, previous) == []


def test_question_only_in_current_is_ignored():
    current = [_current("New question", score=1)]
    previous = [_previous("Old question", score=5)]
    assert build_danger_list(current, previous) == []


def test_averages_across_replicas_before_comparing():
    current = [_current("Q1", score=2), _current("Q1", score=4)]  # avg 3
    previous = [_previous("Q1", score=5), _previous("Q1", score=5)]  # avg 5
    danger = build_danger_list(current, previous)
    assert danger[0]["regressions"]["score"]["current"] == 3.0
    assert danger[0]["regressions"]["score"]["previous"] == 5.0


def test_topic_distinguishes_same_question_text():
    current = [_current("Q1", score=1, topic="billing")]
    previous = [_previous("Q1", score=5, topic="refunds")]
    assert build_danger_list(current, previous) == []


def test_run_results_to_metric_rows_flattens_evaluation_fields():
    result = RunResult(
        result_id="r1",
        question="Q1",
        replica=1,
        evaluation=EvaluationResult(score=4, reason="ok", faithfulness=0.8),
        response_time_ms=100.0,
        topic="billing",
    )
    rows = run_results_to_metric_rows([result])
    assert rows == [{
        "question": "Q1",
        "topic": "billing",
        "score": 4,
        "context_precision": None,
        "context_recall": None,
        "context_entities_recall": None,
        "noise_sensitivity": None,
        "response_relavancy": None,
        "faithfulness": 0.8,
    }]
