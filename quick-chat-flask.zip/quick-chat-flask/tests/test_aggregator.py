import pytest

from app.domain.evaluation.aggregator import (
    build_danger_list,
    build_question_comparison,
    build_score_distribution_from_rows,
    build_score_gain_significance,
    build_summary,
    compute_gain_significance,
    compute_trend_significance,
    find_outliers,
    run_results_to_metric_rows,
)
from app.domain.evaluation.entities import RunResult
from app.domain.shared import EvaluationResult


def _current(question, score, topic=None, **metrics):
    """Builds a RunResult and immediately flattens it, mirroring how the live
    evaluation routes call build_danger_list via run_results_to_metric_rows."""
    result = RunResult(
        result_id="r1",
        question=question,
        replica=1,
        evaluation=EvaluationResult(score=score, reason="", **metrics),
        response_time_ms=100.0,
        topic=topic,
    )
    return run_results_to_metric_rows([result])[0]


def _previous(question, score, topic=None, **metrics):
    row = {"question": question, "topic": topic, "score": score}
    for field in (
        "context_precision", "context_recall", "context_entities_recall",
        "noise_sensitivity", "response_relavancy", "faithfulness",
    ):
        row[field] = metrics.get(field)
    return row


def test_flags_score_regression():
    current = [_current("Q1", score=3)]
    previous = [_previous("Q1", score=5)]
    danger = build_danger_list(current, previous)
    assert len(danger) == 1
    assert danger[0]["question"] == "Q1"
    assert danger[0]["regressions"]["score"] == {"previous": 5.0, "current": 3.0, "delta": -2.0}


def test_no_flag_when_score_improved():
    current = [_current("Q1", score=5)]
    previous = [_previous("Q1", score=3)]
    assert build_danger_list(current, previous) == []


def test_metric_present_both_sides_and_regressed():
    current = [_current("Q1", score=4, faithfulness=0.5)]
    previous = [_previous("Q1", score=4, faithfulness=0.9)]
    danger = build_danger_list(current, previous)
    assert danger[0]["regressions"]["faithfulness"]["previous"] == 0.9
    assert danger[0]["regressions"]["faithfulness"]["current"] == 0.5
    assert "score" not in danger[0]["regressions"]


def test_metric_present_only_on_one_side_is_excluded():
    current = [_current("Q1", score=4, faithfulness=0.5)]
    previous = [_previous("Q1", score=4, faithfulness=None)]
    danger = build_danger_list(current, previous)
    assert danger == []


def test_metric_absent_both_sides_is_excluded():
    current = [_current("Q1", score=4)]
    previous = [_previous("Q1", score=4)]
    assert build_danger_list(current, previous) == []


def test_question_only_in_current_is_ignored():
    current = [_current("New question", score=1)]
    previous = [_previous("Old question", score=5)]
    assert build_danger_list(current, previous) == []


def test_averages_across_replicas_before_comparing():
    current = [_current("Q1", score=2), _current("Q1", score=4)]  # avg 3
    previous = [_previous("Q1", score=5), _previous("Q1", score=5)]  # avg 5
    danger = build_danger_list(current, previous)
    assert danger[0]["regressions"]["score"]["current"] == 3.0
    assert danger[0]["regressions"]["score"]["previous"] == 5.0


def test_topic_distinguishes_same_question_text():
    current = [_current("Q1", score=1, topic="billing")]
    previous = [_previous("Q1", score=5, topic="refunds")]
    assert build_danger_list(current, previous) == []


def test_build_summary_empty_results_matches_populated_key_set():
    empty = build_summary([])
    populated = build_summary([
        RunResult(
            result_id="r1", question="Q1", replica=1,
            evaluation=EvaluationResult(score=4, reason="ok"),
            response_time_ms=100.0,
        )
    ])
    assert set(empty.keys()) == set(populated.keys())
    assert empty == {
        "count": 0,
        "avg_score": None,
        "avg_time": None,
        "score_distribution": {},
        "time_histogram": [],
    }


def test_build_question_comparison_reports_all_metrics_regardless_of_regression():
    current = [_current("Q1", score=5, faithfulness=0.9)]
    previous = [_previous("Q1", score=3, faithfulness=0.5)]
    comparison = build_question_comparison(current, previous)
    assert len(comparison) == 1
    entry = comparison[0]
    assert entry["question"] == "Q1"
    assert entry["in_danger"] is False
    assert entry["metrics"]["score"] == {"current": 5, "previous": 3.0, "delta": 2.0}
    assert entry["metrics"]["faithfulness"] == {"current": 0.9, "previous": 0.5, "delta": 0.4}
    assert entry["metrics"]["context_precision"] == {"current": None, "previous": None}


def test_build_question_comparison_flags_in_danger_and_includes_new_questions():
    current = [_current("Q1", score=2), _current("Q2", score=4)]
    previous = [_previous("Q1", score=5)]
    comparison = {c["question"]: c for c in build_question_comparison(current, previous)}
    assert comparison["Q1"]["in_danger"] is True
    assert comparison["Q1"]["metrics"]["score"]["delta"] == -3.0
    # Q2 has no previous-run match at all — present, not in danger, no deltas.
    assert comparison["Q2"]["in_danger"] is False
    assert "delta" not in comparison["Q2"]["metrics"]["score"]


def test_build_danger_list_still_matches_build_question_comparison_semantics():
    current = [_current("Q1", score=3, faithfulness=0.5), _current("Q2", score=5)]
    previous = [_previous("Q1", score=5, faithfulness=0.9), _previous("Q2", score=1)]
    danger = build_danger_list(current, previous)
    assert len(danger) == 1
    assert danger[0]["question"] == "Q1"
    assert set(danger[0]["regressions"]) == {"score", "faithfulness"}


def test_compute_gain_significance_detects_clear_positive_shift():
    gains = [2.0, 2.1, 1.9, 2.2, 1.8, 2.0]
    result = compute_gain_significance(gains)
    assert result is not None
    assert result["n"] == 6
    assert result["mean_gain"] == pytest.approx(2.0, abs=0.1)
    assert result["significant"] is True
    assert result["p_value"] < 0.05
    assert result["ci_low"] > 0


def test_compute_gain_significance_not_significant_for_noisy_near_zero_mean():
    gains = [0.5, -0.6, 0.4, -0.3, 0.2, -0.4, 0.1]
    result = compute_gain_significance(gains)
    assert result is not None
    assert result["significant"] is False
    assert result["p_value"] >= 0.05


def test_compute_gain_significance_returns_none_below_two_samples():
    assert compute_gain_significance([]) is None
    assert compute_gain_significance([1.0]) is None


def test_build_score_gain_significance_overall_and_by_topic():
    current = [
        _current("Q1", score=5, topic="billing"),
        _current("Q2", score=3, topic="billing"),
        _current("Q3", score=2, topic="refunds"),
    ]
    previous = [
        _previous("Q1", score=3, topic="billing"),
        _previous("Q2", score=2, topic="billing"),
        _previous("Q3", score=2, topic="refunds"),
    ]
    result = build_score_gain_significance(current, previous)
    assert result["overall"] is not None
    assert result["overall"]["n"] == 3
    # Only "billing" has >=2 matched questions; "refunds" has 1, so it's excluded
    # from by_topic (compute_gain_significance returns None below n=2).
    assert "billing" in result["by_topic"]
    assert "refunds" not in result["by_topic"]


def test_run_results_to_metric_rows_flattens_evaluation_fields():
    result = RunResult(
        result_id="r1",
        question="Q1",
        replica=1,
        evaluation=EvaluationResult(score=4, reason="ok", faithfulness=0.8),
        response_time_ms=100.0,
        topic="billing",
    )
    rows = run_results_to_metric_rows([result])
    assert rows == [{
        "question": "Q1",
        "topic": "billing",
        "score": 4,
        "context_precision": None,
        "context_recall": None,
        "context_entities_recall": None,
        "noise_sensitivity": None,
        "response_relavancy": None,
        "faithfulness": 0.8,
    }]


def _result(question, score, response_time_ms=100.0, topic=None, replica=1):
    return RunResult(
        result_id="r", question=question, replica=replica,
        evaluation=EvaluationResult(score=score, reason=""),
        response_time_ms=response_time_ms, topic=topic,
    )


def test_build_score_distribution_from_rows():
    rows = [
        {"question": "Q1", "score": 5}, {"question": "Q2", "score": 5},
        {"question": "Q3", "score": 3}, {"question": "Q4", "score": None},
    ]
    dist = build_score_distribution_from_rows(rows)
    assert dist == {1: 0, 2: 0, 3: 1, 4: 0, 5: 2}


def test_compute_trend_significance_clear_upward_trend():
    trend = [{"avg_score": v} for v in [2.0, 2.5, 3.0, 3.5, 4.0]]
    result = compute_trend_significance(trend)
    assert result is not None
    assert result["slope"] > 0
    assert result["significant"] is True


def test_compute_trend_significance_flat_noisy_not_significant():
    trend = [{"avg_score": v} for v in [3.0, 2.9, 3.1, 3.0, 2.95, 3.05]]
    result = compute_trend_significance(trend)
    assert result is not None
    assert result["significant"] is False


def test_compute_trend_significance_returns_none_below_three_points():
    assert compute_trend_significance([]) is None
    assert compute_trend_significance([{"avg_score": 3.0}, {"avg_score": 4.0}]) is None
    assert compute_trend_significance([{"avg_score": None}, {"avg_score": None}, {"avg_score": None}]) is None


def test_find_outliers_flags_planted_extreme_response_time():
    results = [_result(f"Q{i}", score=4, response_time_ms=100.0) for i in range(9)]
    results.append(_result("Q_outlier", score=4, response_time_ms=5000.0))
    outliers = find_outliers(results)
    assert any(o["question"] == "Q_outlier" and o["metric"] == "response_time_ms" for o in outliers)
    assert all(o["question"] != f"Q{i}" for o in outliers for i in range(9))


def test_find_outliers_uniform_run_flags_nothing():
    results = [_result(f"Q{i}", score=4, response_time_ms=100.0) for i in range(5)]
    assert find_outliers(results) == []
