import httpx

from app.domain.chat.entities import ChatMetadata, ChatModule
from app.infrastructure.evaluator_gateway import EvaluatorGateway


class _FakeResponse:
    def __init__(self, json_data, status_code=200):
        self._json_data = json_data
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("error", request=None, response=self)

    def json(self):
        return self._json_data


class _FakeClient:
    def __init__(self, response):
        self._response = response
        self.last_payload = None

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def post(self, _url, json=None, headers=None):
        self.last_payload = json
        return self._response


def test_evaluate_without_metadata_omits_key(monkeypatch):
    fake_client = _FakeClient(_FakeResponse({"score": 4, "reason": "good"}))
    monkeypatch.setattr(
        "app.infrastructure.evaluator_gateway.httpx.Client", lambda **_kw: fake_client
    )
    gw = EvaluatorGateway("http://evaluator")
    result = gw.evaluate("q", "a", "criteria")

    assert "metadata" not in fake_client.last_payload
    assert result.score == 4
    assert result.reason == "good"
    assert result.context_precision is None
    assert result.faithfulness is None


def test_evaluate_with_metadata_includes_key(monkeypatch):
    fake_client = _FakeClient(_FakeResponse({"score": 5, "reason": "great"}))
    monkeypatch.setattr(
        "app.infrastructure.evaluator_gateway.httpx.Client", lambda **_kw: fake_client
    )
    gw = EvaluatorGateway("http://evaluator")
    metadata = ChatMetadata(
        intents=["billing"],
        modules=[ChatModule("retriever", "rag", "text", {}, {})],
    )
    gw.evaluate("q", "a", "criteria", metadata)

    assert fake_client.last_payload["metadata"]["intents"] == ["billing"]
    assert fake_client.last_payload["metadata"]["modules"][0]["module_name"] == "retriever"


def test_evaluate_parses_optional_metrics_when_present(monkeypatch):
    fake_client = _FakeClient(_FakeResponse({
        "score": 3, "reason": "ok",
        "context_precision": 0.8, "context_recall": 0.9,
        "context_entities_recall": 0.7, "noise_sensitivity": 0.1,
        "response_relavancy": 0.85, "faithfulness": 0.95,
    }))
    monkeypatch.setattr(
        "app.infrastructure.evaluator_gateway.httpx.Client", lambda **_kw: fake_client
    )
    gw = EvaluatorGateway("http://evaluator")
    result = gw.evaluate("q", "a", "criteria")

    assert result.context_precision == 0.8
    assert result.context_recall == 0.9
    assert result.context_entities_recall == 0.7
    assert result.noise_sensitivity == 0.1
    assert result.response_relavancy == 0.85
    assert result.faithfulness == 0.95
