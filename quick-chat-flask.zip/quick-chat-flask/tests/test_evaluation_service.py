import time

from app.application.evaluation_service import EvaluationService
from app.domain.chat.entities import ChatAnswer
from app.domain.evaluation.value_objects import EvaluationRow
from app.domain.shared import EvaluationResult, Location


class _SlowScoringGateway:
    def __init__(self, delay=0.05, fail_questions=None):
        self.delay = delay
        self.fail_questions = fail_questions or set()

    def score(self, request, base_url=None):
        time.sleep(self.delay)
        if request.question in self.fail_questions:
            raise RuntimeError("simulated failure")
        return ChatAnswer(answer=f"answer to {request.question}", intents=[])

    def health(self, base_url=None):
        return {"version": None, "env": None}


class _FastEvaluatorGateway:
    def evaluate(self, question, answer, criteria, metadata=None):
        return EvaluationResult(score=4, reason="ok")


def _rows(n):
    return [EvaluationRow(question=f"q{i}", criteria="c") for i in range(n)]


def test_run_batch_threads_speed_up_wall_clock():
    service = EvaluationService(_SlowScoringGateway(delay=0.05), _FastEvaluatorGateway())
    rows = _rows(10)

    t0 = time.monotonic()
    sequential = list(service.run_batch(rows, replicas=1, location=Location.EU, threads=1))
    sequential_time = time.monotonic() - t0

    t0 = time.monotonic()
    parallel = list(service.run_batch(rows, replicas=1, location=Location.EU, threads=5))
    parallel_time = time.monotonic() - t0

    assert len(sequential) == 10
    assert len(parallel) == 10
    assert parallel_time < sequential_time * 0.6


def test_run_batch_clamps_threads_above_ten():
    service = EvaluationService(_SlowScoringGateway(delay=0.01), _FastEvaluatorGateway())
    results = list(service.run_batch(_rows(3), replicas=1, location=Location.EU, threads=999))
    assert len(results) == 3


def test_run_batch_stop_flag_halts_new_submissions():
    service = EvaluationService(_SlowScoringGateway(delay=0.05), _FastEvaluatorGateway())
    rows = _rows(20)
    stop_flag = [False]

    results = []
    for i, result in enumerate(
        service.run_batch(rows, replicas=1, location=Location.EU, stop_flag=stop_flag, threads=2)
    ):
        results.append(result)
        if i == 2:
            stop_flag[0] = True

    assert 0 < len(results) < 20


def test_run_batch_isolates_failing_units_under_threads():
    service = EvaluationService(
        _SlowScoringGateway(delay=0.01, fail_questions={"q3"}), _FastEvaluatorGateway()
    )
    results = list(service.run_batch(_rows(6), replicas=1, location=Location.EU, threads=3))

    assert len(results) == 5
    assert all(r.question != "q3" for r in results)


def test_run_batch_threads_one_preserves_input_order():
    service = EvaluationService(_SlowScoringGateway(delay=0.0), _FastEvaluatorGateway())
    results = list(service.run_batch(_rows(8), replicas=1, location=Location.EU, threads=1))
    assert [r.question for r in results] == [f"q{i}" for i in range(8)]
