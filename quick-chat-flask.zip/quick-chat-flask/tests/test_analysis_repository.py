import os
from pathlib import Path

import psycopg
import pytest

from app.domain.evaluation.entities import RunResult
from app.domain.shared import EvaluationResult
from app.infrastructure.analysis_repository import AnalysisRepository

DATABASE_URL = os.getenv("DATABASE_URL", "")
SCHEMA_PATH = Path(__file__).resolve().parent.parent / "db" / "schema.sql"

pytestmark = pytest.mark.skipif(
    not DATABASE_URL,
    reason="DATABASE_URL not set — integration test requires a real Postgres instance",
)


@pytest.fixture
def repo():
    with psycopg.connect(DATABASE_URL) as conn:
        conn.execute(SCHEMA_PATH.read_text())
        conn.commit()
    return AnalysisRepository(DATABASE_URL)


def _make_result(question: str, score: int) -> RunResult:
    return RunResult(
        result_id="r1",
        question=question,
        replica=1,
        evaluation=EvaluationResult(score=score, reason="ok"),
        response_time_ms=120.0,
        topic=None,
        answer="the answer",
        intents=["billing"],
        question_id=None,
        set_id=1,
        location="eu",
    )


def test_save_run_and_get_previous_run_round_trip(repo):
    results = [_make_result("What is X?", 4), _make_result("What is Y?", 5)]

    first_run_id = repo.save_run(
        set_id=1,
        analysis_type="multiple",
        replicas=1,
        threads=1,
        results=results,
        chat_version_basis="1.0.0",
        feature_name="staging",
    )
    assert isinstance(first_run_id, int)

    assert repo.get_previous_run(set_id=1, analysis_type="multiple", exclude_run_id=first_run_id) is None

    second_run_id = repo.save_run(
        set_id=1,
        analysis_type="multiple",
        replicas=1,
        threads=1,
        results=results,
        chat_version_basis="1.0.1",
        feature_name="staging",
    )

    prev = repo.get_previous_run(set_id=1, analysis_type="multiple", exclude_run_id=second_run_id)
    assert prev is not None
    assert prev["run_id"] == first_run_id
    assert prev["total_count"] == 2
    assert prev["avg_score"] == pytest.approx(4.5)


def test_save_run_stores_optional_metrics_as_null_when_absent(repo):
    run_id = repo.save_run(
        set_id=2,
        analysis_type="topic",
        replicas=1,
        threads=1,
        results=[_make_result("Topic question?", 3)],
    )

    with psycopg.connect(DATABASE_URL) as conn:
        row = conn.execute(
            "SELECT context_precision, faithfulness FROM analysis_results WHERE run_id = %s",
            (run_id,),
        ).fetchone()

    assert row == (None, None)
