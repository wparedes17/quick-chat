import pytest

from app.application.sets_service import SetsService


class _FakeRepo:
    def __init__(self, sets: dict[int, dict]):
        self._sets = sets
        self.created = []
        self.updated = []

    def get_set(self, set_id):
        return self._sets.get(set_id)

    def create_test_set(self, set_id, question, criteria, location, topic=None):
        row = {
            "question_id": 1, "set_id": set_id, "question": question,
            "criteria": criteria, "location": location, "topic": topic,
        }
        self.created.append(row)
        return row

    def update_test_set(self, question_id, question, criteria, location, topic=None):
        self.updated.append((question_id, question, criteria, location, topic))


@pytest.fixture
def multiple_repo():
    return _FakeRepo({1: {"set_id": 1, "set_name": "Default", "set_type": "multiple"}})


@pytest.fixture
def topic_repo():
    return _FakeRepo({2: {"set_id": 2, "set_name": "Default", "set_type": "topic"}})


def test_create_question_allows_missing_topic_for_multiple_set(multiple_repo):
    service = SetsService(multiple_repo)
    result = service.create_question(1, "What is X?", "must be correct", "eu")
    assert result["topic"] is None
    assert len(multiple_repo.created) == 1


def test_create_question_requires_topic_for_topic_set(topic_repo):
    service = SetsService(topic_repo)
    with pytest.raises(ValueError, match="topic is required"):
        service.create_question(2, "What is X?", "must be correct", "eu")


def test_create_question_accepts_topic_for_topic_set(topic_repo):
    service = SetsService(topic_repo)
    result = service.create_question(2, "What is X?", "must be correct", "eu", topic="billing")
    assert result["topic"] == "billing"


def test_create_question_rejects_empty_question_or_criteria(multiple_repo):
    service = SetsService(multiple_repo)
    with pytest.raises(ValueError, match="question and criteria"):
        service.create_question(1, "", "criteria", "eu")
    with pytest.raises(ValueError, match="question and criteria"):
        service.create_question(1, "question", "  ", "eu")


def test_create_question_rejects_invalid_location(multiple_repo):
    service = SetsService(multiple_repo)
    with pytest.raises(ValueError, match="location"):
        service.create_question(1, "q", "c", "mars")


def test_create_question_rejects_unknown_set(multiple_repo):
    service = SetsService(multiple_repo)
    with pytest.raises(ValueError, match="set not found"):
        service.create_question(999, "q", "c", "eu")


def test_create_set_rejects_empty_name():
    service = SetsService(_FakeRepo({}))
    with pytest.raises(ValueError, match="set_name"):
        service.create_set("", "multiple")


def test_create_set_rejects_invalid_type():
    service = SetsService(_FakeRepo({}))
    with pytest.raises(ValueError, match="set_type"):
        service.create_set("My Set", "banana")


def test_update_question_requires_topic_for_topic_set(topic_repo):
    service = SetsService(topic_repo)
    with pytest.raises(ValueError, match="topic is required"):
        service.update_question(2, 1, "q", "c", "eu")
    service.update_question(2, 1, "q", "c", "eu", topic="refund")
    assert topic_repo.updated == [(1, "q", "c", "eu", "refund")]
