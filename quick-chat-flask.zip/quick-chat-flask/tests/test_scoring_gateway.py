import httpx

from app.domain.chat.entities import ChatRequest
from app.domain.shared import Location
from app.infrastructure.scoring_gateway import ScoringGateway


class _FakeResponse:
    def __init__(self, json_data, status_code=200):
        self._json_data = json_data
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("error", request=None, response=self)

    def json(self):
        return self._json_data


class _FakeClient:
    def __init__(self, response=None, exc=None):
        self._response = response
        self._exc = exc

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def post(self, *_args, **_kwargs):
        if self._exc:
            raise self._exc
        return self._response

    def get(self, *_args, **_kwargs):
        if self._exc:
            raise self._exc
        return self._response


def _request() -> ChatRequest:
    return ChatRequest(
        request_id="r1", question="hi?", location=Location.EU,
        session_id="s1", user_id="u1",
    )


def test_score_without_metadata_yields_none(monkeypatch):
    monkeypatch.setattr(
        "app.infrastructure.scoring_gateway.httpx.Client",
        lambda **_kw: _FakeClient(_FakeResponse({"answer": "hello", "intent": "billing"})),
    )
    gw = ScoringGateway("http://scoring")
    answer = gw.score(_request())
    assert answer.answer == "hello"
    assert answer.intents == ["billing"]
    assert answer.metadata is None


def test_score_with_metadata_parses_modules(monkeypatch):
    monkeypatch.setattr(
        "app.infrastructure.scoring_gateway.httpx.Client",
        lambda **_kw: _FakeClient(_FakeResponse({
            "answer": "hello",
            "intent": "billing,refund",
            "metadata": {
                "intents": ["billing", "refund"],
                "modules": [{
                    "module_name": "retriever",
                    "module_type": "rag",
                    "text_response": "chunk text",
                    "raw_input_data": {"q": "hi"},
                    "raw_output_data": {"docs": []},
                }],
            },
        })),
    )
    gw = ScoringGateway("http://scoring")
    answer = gw.score(_request())
    assert answer.metadata is not None
    assert answer.metadata.intents == ["billing", "refund"]
    assert len(answer.metadata.modules) == 1
    assert answer.metadata.modules[0].module_name == "retriever"
    assert answer.metadata.modules[0].raw_input_data == {"q": "hi"}


def test_health_returns_version_and_env(monkeypatch):
    monkeypatch.setattr(
        "app.infrastructure.scoring_gateway.httpx.Client",
        lambda **_kw: _FakeClient(_FakeResponse({"version": "1.2.3", "env": "staging"})),
    )
    gw = ScoringGateway("http://scoring")
    assert gw.health() == {"version": "1.2.3", "env": "staging"}


def test_health_never_raises_on_failure(monkeypatch):
    monkeypatch.setattr(
        "app.infrastructure.scoring_gateway.httpx.Client",
        lambda **_kw: _FakeClient(exc=httpx.ConnectError("refused")),
    )
    gw = ScoringGateway("http://unreachable")
    assert gw.health() == {"version": None, "env": None}
