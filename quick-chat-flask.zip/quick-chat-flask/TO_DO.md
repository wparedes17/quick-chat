# TO DO
# Multiple analysis & Topic analysis
- Reason. Column is to short to show the complete reason. So, we requiere a button to expand a row. Like a card.
- Card has to show changes when the question is in danger or not and previous and current scores.
- Average score and topic score gains has to employ confidence intervals to evaluate the significance of the gains. You can employ empirical method such employs 2 sided t-tests to compare the gains to the null hypothesis of no change.
- When you change of tab, evaluation has to continue in order when you go back to the tab you can see the current status of the run

# Deep Analysis
  - Deep analysis load fine previous runs. However don't show anything. Here I require you think as data scientist to elaborate a dashboard that shows the results of the deep analysis. Has to be significant and deeper than plots in analysis tab.
