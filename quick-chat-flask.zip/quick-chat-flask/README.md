# quick-chat-flask

A **Flask + Python** rewrite of the quick-chat chatbot testing and evaluation tool, structured with **Domain-Driven Design (DDD)**. It replaces the original React/TypeScript/Vite frontend with server-rendered Jinja2 templates and vanilla JavaScript — no npm, no build step.

## What this project does

This is an internal tool for testing and evaluating a chatbot system. It provides five features:

| Page | Description |
|---|---|
| **Chat** | Send questions to the chatbot, receive answers (streaming or non-streaming), see detected intents |
| **Single Analysis** | Ask one question, get the answer evaluated against custom criteria (score 1–5 + reason) |
| **Multiple Analysis** | Upload a CSV of questions/criteria, run each N times, view score distributions and timing charts |
| **Topic Analysis** | Same as multiple analysis but with a `topic` column — groups results and charts by topic |
| **Conversation Evaluation** | Run a multi-turn conversation (auto follow-ups), then evaluate the full transcript |

The Flask app acts as the **UI layer only** — it does not implement the AI logic. All intelligence comes from three external backend services that must be running separately.

---

## External backends (required)

| Service | Default URL | Endpoints used |
|---|---|---|
| Scoring / Chat | `http://localhost:8080` | `POST /score`, `POST /score/stream` |
| Evaluation | `http://localhost:8081` | `POST /evaluate` |
| Follow-up generation | `http://localhost:8082` | `POST /follow` |

These backends are **not part of this repository**. Start them before running the Flask app.

---

## Database (optional)

Setting `DATABASE_URL` (in `config.py` / `.env`) enables an **optional run-history feature** for **Multiple Analysis** and **Topic Analysis** only. When a run finishes, the results are saved to Postgres and, if a previous run exists for the same CSV filename + analysis type, a `comparison` SSE event is sent to the UI showing score/invalid-count deltas vs. that previous run. Chat, Single Analysis, and Conversation Evaluation never use the database.

If `DATABASE_URL` is unset (the default, `""`), the feature is disabled entirely — `ANALYSIS_REPO` is `None` and the app runs with no database. If it's set but the database is unreachable or the query fails, the error is swallowed and the run simply proceeds without a comparison event (see `app/interfaces/evaluation/routes.py`).

```bash
# .env (optional)
DATABASE_URL=postgresql://user:pass@host:5432/dbname
```

**Driver:** `AnalysisRepository` (`app/infrastructure/analysis_repository.py`) uses `psycopg` (v3) directly with raw SQL — no ORM. `psycopg` is **not** in `requirements.txt`; install it yourself if you use this feature:

```bash
pip install "psycopg[binary]"
```

**Schema contract:** no migration is shipped in this repo. The target database must already have these two tables before `DATABASE_URL` is set:

```sql
CREATE TABLE analysis_runs (
    id                 SERIAL PRIMARY KEY,
    csv_filename       TEXT,
    analysis_type      TEXT,       -- "multiple" or "topic"
    location           TEXT,
    replicas           INTEGER,
    total_count        INTEGER,
    avg_score          NUMERIC,
    avg_time_ms        NUMERIC,
    invalid_count      INTEGER,
    score_distribution JSONB,
    intent_stats       JSONB,
    run_date           TIMESTAMP DEFAULT now(),
    created_at         TIMESTAMP DEFAULT now()
);

CREATE TABLE analysis_results (
    run_id             INTEGER REFERENCES analysis_runs(id),
    question           TEXT,
    topic              TEXT,
    replica            INTEGER,
    score              NUMERIC,
    reason             TEXT,
    response_time_ms   NUMERIC,
    answer             TEXT,
    intents            TEXT,
    rewritten_question TEXT,
    is_invalid         BOOLEAN
);
```

---

## Quick start

### Prerequisites
- Python 3.11+
- The three external backends running (see above)
- Recommended: use the `fastapi-env` conda environment

### Install dependencies

```bash
conda activate fastapi-env
cd ~/github/quick-chat-flask
pip install -r requirements.txt
```

### Configure (optional)

Backend URLs default to `localhost:8080/8081/8082`. Override via a `.env` file:

```bash
# .env (optional)
SCORING_URL=http://localhost:8080
EVALUATOR_URL=http://localhost:8081
FOLLOW_URL=http://localhost:8082
```

### Run

```bash
conda activate fastapi-env
cd ~/github/quick-chat-flask
python run.py
```

App is available at **http://localhost:5000**.

---

## Project structure

```
quick-chat-flask/
├── run.py                              # Entry point — calls create_app().run()
├── config.py                           # Reads SCORING_URL, EVALUATOR_URL, FOLLOW_URL from env
├── requirements.txt                    # flask, httpx, python-dotenv
│
└── app/
    ├── __init__.py                     # create_app() factory — wires all layers together
    │
    ├── domain/                         # Pure business logic — no I/O, no Flask
    │   ├── shared.py                   # Location enum (us/eu), EvaluationResult value object
    │   ├── chat/entities.py            # ChatRequest, ChatAnswer, Message, StreamEvent
    │   ├── evaluation/
    │   │   ├── entities.py             # RunResult entity
    │   │   ├── value_objects.py        # EvaluationRow (CSV row), BatchStats, TopicStats
    │   │   └── aggregator.py           # EvaluationAggregator — stats/histogram computation
    │   └── conversation/
    │       ├── entities.py             # Conversation, Turn, ConversationEvent
    │       └── transcript.py           # TranscriptFormatter domain service
    │
    ├── application/                    # Use cases — orchestrate domain + infrastructure
    │   ├── chat_service.py             # ask(), ask_stream()
    │   ├── evaluation_service.py       # run_single(), run_batch(), parse_csv()
    │   └── conversation_service.py     # run_conversation(), evaluate_conversation()
    │
    ├── infrastructure/                 # Adapters to external HTTP backends
    │   ├── ports.py                    # Protocol interfaces for the three gateways
    │   ├── scoring_gateway.py          # Calls :8080 — owns NDJSON stream parsing
    │   ├── evaluator_gateway.py        # Calls :8081
    │   └── follow_gateway.py           # Calls :8082 — owns whitespace normalization
    │
    ├── interfaces/                     # Flask blueprints (one per bounded context)
    │   ├── chat/routes.py              # GET /, POST /ask, POST /ask/stream
    │   ├── evaluation/routes.py        # /evaluation/single|multiple|topic + /run endpoints
    │   └── conversation/routes.py      # /conversation/ + /run + /evaluate
    │
    ├── templates/                      # Jinja2 HTML templates
    │   ├── base.html                   # Shared layout, header, nav tabs, CDN scripts
    │   ├── chat/chat.html
    │   ├── evaluation/single.html
    │   ├── evaluation/multiple.html
    │   ├── evaluation/topic.html
    │   └── conversation/conversation.html
    │
    └── static/
        ├── css/main.css                # All styles — design tokens, components
        └── js/
            ├── chat.js                 # Chat streaming, message rendering, abort
            ├── single_analysis.js      # Single analysis form + result display
            ├── multiple_analysis.js    # SSE progress, Chart.js, CSV upload
            ├── topic_analysis.js       # SSE progress, per-topic charts, comparison charts
            └── conversation.js         # SSE turn streaming, evaluate step
```

---

## URL routes

| Method | URL | Description |
|---|---|---|
| `GET` | `/` | Chat page |
| `POST` | `/ask` | Non-streaming chat (JSON) |
| `POST` | `/ask/stream` | Streaming chat (SSE) |
| `GET` | `/evaluation/single` | Single Analysis page |
| `POST` | `/evaluation/single/run` | Run single analysis (JSON) |
| `GET` | `/evaluation/multiple` | Multiple Analysis page |
| `POST` | `/evaluation/multiple/run` | Run batch analysis (SSE) |
| `GET` | `/evaluation/topic` | Topic Analysis page |
| `POST` | `/evaluation/topic/run` | Run topic analysis (SSE) |
| `GET` | `/conversation/` | Conversation Evaluation page |
| `POST` | `/conversation/run` | Run conversation (SSE) |
| `POST` | `/conversation/evaluate` | Evaluate a completed conversation (JSON) |

---

## Technology choices

| Concern | Choice | Replaces (React version) |
|---|---|---|
| Web framework | Flask 3 | Vite dev server |
| Templates | Jinja2 | React components |
| Styling | Custom CSS (`main.css`) | Tailwind CSS (compiled) |
| Charts | Chart.js (CDN) | Recharts |
| Markdown | marked.js (CDN) | Custom `Markdown.tsx` component |
| HTTP client | httpx (sync) | fetch API |
| Streaming | SSE via `stream_with_context` | NDJSON + ReadableStream |
| CSV parsing | Pure Python in `evaluation_service.py` | Component-local TS functions |
| State management | Module-level JS variables | React `useState` / `useRef` |

---

## Architecture overview

See [ARCHITECTURE.md](ARCHITECTURE.md) for the full DDD design, data flow diagrams, and layer-by-layer explanation.
