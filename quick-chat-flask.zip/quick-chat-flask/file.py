similarity_results = []
for competitor in competitor_list:
    similarity = self._metric.similarity(product, competitor)
    similarity_results.append((competitor, similarity))
similarity_results.sort(key=lambda x: x[1], reverse=True)
return similarity_results[:top_k]


we have a current index:

index_name -- has to be a env variable
endpoint -- has to be a env variable

client = SearchClient(
endpoint=os.environ.get("SEARCH_ENDPOINT"),
    index_name=os.environ.get("SEARCH_INDEX_NAME"),
    credential=AzureKeyCredential(os.environ.get("SEARCH_API_KEY"))
)

vector_query = VectorizedQuery(
    vector=vector,
    k=top_vector_k,
    fields="embedding",
)

results = client.search(
    search_text="*",  # Use a wildcard to match all documents
    vector_query=vector_query,
    top_k=top_search_k,
    query_type="semantic",  # Use semantic search
    semantic_configuration_name="default",  # Use the default semantic configuration
)


sourcefile_url = r.get("sourcefile_url")
sourcefile =  r.get("sourcefile") if sourcefile_url else sourcefile_url
category = sourcefile.split("/")[0] if sourcefile else None

content = format_content(r.get("content"), collection, category)
sourcefile_name, ext = os.path.splitext(os.path.basename(sourcefile)) if sourcefile else None
fetch = ext != ".md" if ext else True

SearchResultItem(
    text=content,
    metadata=SearchResultMetadata(
        id=r.get("id"),
        category=category,
        rerank_score=r.get("@search.reranker_score"),    
        filter_type=collection,
        sourcefile=SourceFile(
            name=sourcefile_name,
            link=sourcefile_url,
            fetch=fetch,
            doctype=ext
        )
    )
)
