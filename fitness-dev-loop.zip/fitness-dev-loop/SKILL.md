---
name: fitness-dev-loop
description: Evaluator-driven development workflow for AI/ML services. Use when picking up an Azure DevOps work item or a local task, drafting a solution, diagnosing a bug with tracing, planning a feature or fix, executing it with an A/B evaluation (base branch vs work branch) through the evaluator MCP, writing or reading a run report, or handing off to the next phase/session.
---

# Fitness Dev Loop

The core rule is that **no change is done without A/B evidence from the evaluator.**
A change counts as finished only when the evaluator has measured it against the base branch
on the same request set, under the same settings, and the report states a verdict.

The workflow has seven modes. The user normally names the mode ("explore", "draft",
"plan", "execute", "report", "handoff"). If the user doesn't name one, infer it from the
task folder state (see "Resuming" below) and say which mode you picked.

---

## 0. Setup (run once per session, before any mode)

1. Read `.fitness/config.yaml` from the target repo root. If it is missing, stop. Tell the
   user to copy `config.example.yaml` from this skill folder and fill in the paths. Do not
   guess repo locations.
2. Check every MCP listed in the config:
   - For each one, list its tools and make one cheap read call.
   - Print a status table: `name | required | status | note`.
   - If a `required: true` MCP fails, stop and report the failure.
   - If an optional MCP fails (ADO, extras), mark the features that need it as unavailable
     and continue.
3. Load the memory source:
   - `memory.type: solr_mcp`: query it for the task's main keywords when a task is
     selected.
   - `memory.type: decisions_file`: read the file from `memory.file`.
4. If `fitness.tools` in the config maps evaluator tool names, use those names. If it
   doesn't, list the evaluator MCP's tools and ask the user which one runs an evaluation.
   Never guess.

## Task workspace

Each task gets its own folder at `<task_root>/<task-id>/`:

```
<task-id>/
  draft.md              # step 2: human-led exploration, plus diagnosis for bugs
  plan.md               # step 3: approved plan (templates/plan.md)
  ab/
    requests.jsonl      # request set used for the A/B (bugs: the repro set)
    baseline/           # raw evaluator output, base branch
    candidate/          # raw evaluator output, work branch
  report.md             # step 5 (templates/report.md)
  next-phase-plan.md    # handoff (templates/next-phase-plan.md)
  next-phase-prompt.md  # handoff (templates/next-phase-prompt.md)
```

- `task-id`: the ADO work item id (`ado-12345`). For local tasks, use
  `local-YYYYMMDD-short-slug`.
- Work branch: `feat/<task-id>` for features, `fix/<task-id>` for bugs. Create it from
  `repos.target.base_branch`.

### Resuming

When the user doesn't name a mode, infer it from the files present:

| Files present | Next mode |
|---|---|
| nothing | explore or draft |
| `draft.md` only | plan, or diagnose for a bug without a diagnosis |
| `plan.md` not marked `Status: APPROVED` | plan (wait for approval) |
| `plan.md` approved, no `report.md` | execute |
| `report.md` | report (read it back) or handoff |
| `next-phase-prompt.md` | start the next phase from that prompt |

---

## 1. explore (Azure DevOps)

Only run this mode if the ADO MCP passed setup. If it didn't, say so and offer `draft`
with a local task.

1. List work items in the project and area path from the config. Default filter: assigned
   to the user, state Active or New. Show `id | type | title | state | priority`.
2. When the user picks one, fetch its description, acceptance criteria, linked items and
   comments.
3. Search memory for related past decisions.
4. Create the task folder and fill the `## Context` section of `draft.md` with the work
   item summary, acceptance criteria and related decisions. Link each decision to its
   source.

Don't propose a solution in this mode.

## 2. draft

The user leads this step. Claude helps explore but does not write a plan yet.

1. Classify the task as **feature** or **bug**, and confirm with the user.
2. Fill `draft.md` with the user, using `templates/draft.md`.
   - **Feature:** problem, constraints, options considered, chosen direction, and success
     criteria expressed in fitness terms (which objective moves, by how much, and what
     must not regress).
   - **Bug:** observed vs expected behavior, and a **request set** that reproduces it.
     Save the request set to `ab/requests.jsonl` in the evaluator's input format.
3. Exploration is allowed: read code, query memory, run single requests against the
   service. Code changes are not allowed.

## 3. diagnose (bugs only)

1. Start the target service with tracing (`repos.target.run_with_tracing`) and wait for
   `repos.target.health` to respond.
2. Run the request set from `ab/requests.jsonl` and collect traces and logs.
3. Add a `## Diagnosis` section to `draft.md` with: the failing path, the evidence (trace
   excerpts with span names and timings), the root-cause hypothesis and your confidence in
   it.
4. If confidence is low, propose more requests to add to the set, or go back to `draft`.
   Don't move to `plan` on a guess unless the user says so.
5. Stop the service when you're done.

## 4. plan

1. Turn `draft.md` into `plan.md` using `templates/plan.md`. Every section is mandatory.
   A plan without the A/B section is invalid.
2. Split the work into phases when either condition holds:
   - more than `phases.max_steps_per_phase` implementation steps, or
   - changes span more than one repo.

   Each phase must have its own A/B evaluation that can run on its own. Plan only the
   current phase in detail; list later phases as one line each.
3. Set `Status: DRAFT` at the top, present the plan, and stop. Apply the user's comments
   and changes.
4. Change it to `Status: APPROVED` only when the user explicitly approves. Execution
   requires an approved plan.

## 5. execute

1. Make sure the working tree is clean, then create the work branch from the base branch.
2. Implement the plan steps in order. After each step, run the target's tests if
   `repos.target.test` is configured. If the plan turns out to be wrong, stop and say how
   it deviates. Don't silently redesign.
3. **A/B evaluation** (the exact protocol is under Guardrails):
   - **Baseline:** check out the base branch, start the service, wait for health, run the
     evaluator on the dev dataset plus `ab/requests.jsonl` if it exists. Save raw output
     to `ab/baseline/`.
   - **Candidate:** do the same on the work branch and save to `ab/candidate/`.
   - Use the same dataset, the same evaluator settings, the same machine, and run them
     back to back.
4. Compare the results against `fitness.acceptance` and decide the verdict (rules below).
5. Commit on the work branch. Don't push or open a PR unless the plan or the user says
   to.
6. Go straight to `report`.

## 6. report

1. Fill `report.md` using `templates/report.md`:
   - the A/B table: per objective, baseline, candidate, delta, spread and n;
   - per-case regressions: every case whose quality dropped by more than
     `fitness.acceptance.case_regression_threshold`;
   - the verdict, with the rule that triggered it;
   - findings: what was learned, including surprises;
   - residuals: anything not done, known risks, suspected evaluator issues;
   - decisions worth keeping.
2. If `fitness.datasets.holdout` is configured and the verdict is PASS, run the holdout
   set **once** on both branches and add the result to its own section. Never use holdout
   results to change the code in the same task.
3. Ask the user before writing the "decisions" items to memory: through the Solr MCP, or
   appended to `DECISIONS.md` in the format `- YYYY-MM-DD [task-id] decision. Why: ...`.
4. If the plan has more phases, or the session is getting long, go to `handoff`.

## 7. handoff

1. Write `next-phase-plan.md` using `templates/next-phase-plan.md`: the state reached,
   the next phase in detail, and carried-over residuals.
2. Write `next-phase-prompt.md` using `templates/next-phase-prompt.md`: a self-contained
   prompt that a new session can run cold. It must name this skill, the task folder, the
   branch, and the first command to run.
3. Tell the user which file to paste or point the new session at.

---

## Guardrails

### Fitness integrity
- **Never modify the evaluator repo, its datasets, golden sets, judges or thresholds**
  in the same task as the change being evaluated. If the evaluator looks wrong, record it
  under Residuals and suggest a separate task.
- Treat dependency repos as read-only unless the approved plan says otherwise.
- Never present an improvement without numbers from `ab/`. If the A/B didn't run, the
  verdict is `NOT EVALUATED`.

### A/B protocol
- **Warmup:** send `fitness.warmup` requests before measuring, and discard them.
- **Repeats:** run `fitness.repeats` times per branch. For latency, report the median and
  the spread (IQR or min–max).
- **Noise rule:** if a latency delta is smaller than the baseline spread, report it as
  "no measurable change", not as an improvement or a regression.
- Report quality per case as well as the mean. A better mean that hides case regressions
  needs to be called out.
- If anything differs between the baseline and candidate runs (config, data, machine
  load), record it in the report.

### Verdict
- **PASS:** every acceptance threshold is met, and no case regressed past the threshold.
- **FAIL:** any threshold is missed.
- **INCONCLUSIVE:** deltas are inside the noise, or the run was disturbed. Propose more
  repeats or a larger set.
- **NOT EVALUATED:** the A/B could not run. Explain why.

### Scope
- One task per session folder. If new work shows up, add it to Residuals; don't take it
  on.
- Ask before destructive git operations: reset, force-push, deleting branches.
