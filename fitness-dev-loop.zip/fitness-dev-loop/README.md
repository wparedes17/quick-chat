# fitness-dev-loop

A skill for evaluator-driven development: explore, draft, diagnose, plan, execute
(with an A/B evaluation), report, and handoff.

## Install
- Claude Code: copy this folder to `<target-repo>/.claude/skills/fitness-dev-loop/`, or to
  `~/.claude/skills/` to use it in every repo.
- GitHub Copilot: copy it to `<target-repo>/.github/skills/fitness-dev-loop/`. Check that
  your Copilot version supports agent skills.

## Configure
1. Copy `config.example.yaml` to `<target-repo>/.fitness/config.yaml` and fill in the paths,
   commands and thresholds.
2. Make sure `.mcp.json` in the target repo declares the evaluator, memory and optional ADO
   servers, using the names given in the config.
3. Optionally add `.fitness/tasks/*/ab/` to `.gitignore` if the raw evaluator output is large.

## Use
- "explore ADO tasks" → pick a work item
- "draft <task>" → write draft.md together
- "diagnose" → bugs: run with tracing, write the diagnosis
- "plan" → plan.md, then wait for approval
- "execute" → implement, A/B, then report
- "handoff" → write next-phase-plan.md and next-phase-prompt.md
