Use the `fitness-dev-loop` skill.

Task: <task-id> — <title>
Task folder: <task_root>/<task-id>/
Work branch: <work branch> (check it out; do not recreate it)

Context in one paragraph:
<what the task is, what previous phases achieved, the last verdict and its numbers>

Do this:
1. Run Setup (config + MCP check).
2. Read, in order: next-phase-plan.md, report.md, plan.md. Read draft.md only if you need the background.
3. Present the next-phase plan as plan.md for phase <n+1> with Status: DRAFT, and wait for my approval.

Do not:
- touch the evaluator, its datasets or thresholds;
- start implementing before I approve the plan.
