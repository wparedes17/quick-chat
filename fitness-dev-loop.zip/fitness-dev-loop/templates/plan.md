# Plan — <task-id>: <title>

Status: DRAFT            <!-- DRAFT | APPROVED -->
Type: feature | bug
Branch: feat/<task-id> | fix/<task-id>  (from <base_branch>)
Phase: 1 of N

## Goal
<!-- One sentence linking back to draft.md success criteria -->

## Scope
- In: 
- Out: 

## Steps (this phase)
| # | Repo | Change | Files | Verification |
|---|---|---|---|---|
| 1 | target | | | |

## A/B evaluation (mandatory)
- Baseline: `<base_branch>` @ <commit>
- Candidate: `<work branch>`
- Datasets: dev = <id>; repro set = ab/requests.jsonl (yes/no); holdout = <id or none>
- Warmup / repeats: <w> / <r>
- Acceptance:
  - Quality: candidate mean − baseline mean ≥ <quality_min_delta>
  - No case drops by more than <case_regression_threshold>
  - Latency p50 regression ≤ <latency_max_regression_pct>%
- Expected outcome: <what we predict, so the report can confirm or refute it>

## Risks
| Risk | Likelihood | Mitigation |
|---|---|---|

## Rollback
<!-- How to undo: revert the branch, a feature flag, a config switch -->

## Later phases
- Phase 2: <one line>
