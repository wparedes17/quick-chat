# Draft — <task-id>: <title>

Type: feature | bug
Source: ADO <id> | local

## Context
<!-- Work item summary, acceptance criteria, related past decisions (with source) -->

## Problem
<!-- Feature: what is missing and why it matters. Bug: observed vs expected. -->

## Constraints
<!-- Latency budget, APIs that can't change, repos that can't change, deadlines -->

## Options considered
| Option | Pros | Cons | Expected effect on quality / latency |
|---|---|---|---|

## Chosen direction
<!-- One paragraph. Why this option. -->

## Success criteria (in fitness terms)
- Quality: <metric> <direction> by <amount> on <dataset>
- Latency: <metric> must not exceed <value / % regression>
- Must not regress: <cases / behaviors>

## Request set (bugs)
<!-- Saved to ab/requests.jsonl. Describe what each group of requests exercises. -->

## Diagnosis (bugs)
<!-- Filled in diagnose mode: failing path, trace evidence, root-cause hypothesis, confidence -->
