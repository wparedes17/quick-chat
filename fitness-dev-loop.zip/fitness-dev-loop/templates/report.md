# Report — <task-id>: <title> (phase <n>)

Verdict: PASS | FAIL | INCONCLUSIVE | NOT EVALUATED
Rule that decided it: <e.g. "latency p50 +7.2% > 5% allowed">
Baseline: `<base_branch>` @ <commit> · Candidate: `<work branch>` @ <commit>
Run date: <YYYY-MM-DD> · Warmup/repeats: <w>/<r> · Datasets: <ids>

## A/B results
| Objective | Baseline | Candidate | Δ | Spread (baseline) | n | Meets threshold |
|---|---|---|---|---|---|---|
| Quality (mean) | | | | | | |
| Latency p50 (ms) | | | | | | |
| Latency p95 (ms) | | | | | | |

Raw output: `ab/baseline/`, `ab/candidate/`

## Per-case regressions
<!-- Every case whose quality dropped by more than the threshold. "None" if empty. -->
| Case id | Baseline | Candidate | Δ | Likely cause |
|---|---|---|---|---|

## Holdout (only if run)
| Objective | Baseline | Candidate | Δ |
|---|---|---|---|

## Expected vs actual
<!-- Compare with the plan's "Expected outcome" -->

## Findings
- 

## Residuals
<!-- Not done, known risks, suspected evaluator problems, out-of-scope issues found -->
- 

## Run conditions
<!-- Anything that differed between runs, machine load, flaky requests -->

## Decisions to record
<!-- Proposed for memory, written only after user confirmation -->
- YYYY-MM-DD [<task-id>] <decision>. Why: <reason>.

## Next step
<!-- Merge / revise and rerun / next phase / separate task for an evaluator issue -->
