# Next phase — <task-id>: <title> (phase <n+1> of N)

## State reached
- Branch: `<work branch>` @ <commit> (pushed: yes/no)
- Last verdict: <verdict> (see report.md)
- Done in previous phases: 
  - 

## This phase
### Goal

### Steps
| # | Repo | Change | Files | Verification |
|---|---|---|---|---|

### A/B evaluation
- Baseline: `<base_branch>` or end of previous phase? <state which, and why>
- Datasets / warmup / repeats / acceptance: <same as plan.md unless changed; say what changed>

## Carried-over residuals
- 

## Open questions for the user
- 
